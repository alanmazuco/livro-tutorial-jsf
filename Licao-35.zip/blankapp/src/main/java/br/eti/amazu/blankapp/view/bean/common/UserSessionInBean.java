package br.eti.amazu.blankapp.view.bean.common;

import java.io.Serializable;
import java.util.List;
import java.util.Locale;

import br.eti.amazu.blankapp.domain.infra.Perfil;
import br.eti.amazu.util.FacesUtil;

import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named
@SessionScoped
public class UserSessionInBean implements Serializable {

	private static final long serialVersionUID = -2765013996497920460L;
	
	//Dados de usuario comum do sistema
	private String senhaAdmPostgreSQL;	
	private String pessoaLogged;
	private String userLogged;
	private List<Perfil> perfisLogado;
		
	private Locale locale;
	
	public UserSessionInBean(){
		
		/* Locale */
		this.setLocale(FacesUtil.getLocale()); //Obtem o idioma local (do Sistema Operacional).	
	}
   
	/* Um botao de acao de uma pagina qualquer pode mudar o idioma,
	 * mas tem de passar um parametro para qual idioma a ser mudado.
	 *------------------------------------------------------------*/
	public void mudarIdioma(){
		String localeStr = FacesUtil.getParam("locale");
		if(localeStr.length() == 2){
			locale = new Locale(localeStr);
			
		}else{			
			locale = new Locale(localeStr.substring(0,2), localeStr.substring(3));
		}
		FacesUtil.setLocale(locale);		
		System.out.println(FacesUtil.getMessage("MGL064",new String[]{localeStr}));
	}
	
	/* Utiliza o componente IdleMonitor do PrimeFaces
	 * para invalidar a sess�o. */
	public void idleListener() {				
		FacesUtil.redirect  ("/pages/errorpages/viewExpired");
		FacesUtil.sessionInvalidate();			
	}

	
	/*--------
	 * get/set
	 --------*/
			
	public void returnHomePage(){
		FacesUtil.redirect("/pages/home/homePage");
	}	
	public void reload(){		
		FacesUtil.redirect(FacesUtil.getUrlInView());
	}
	public String getSenhaAdmPostgreSQL() {
		return senhaAdmPostgreSQL;
	}
	public void setSenhaAdmPostgreSQL(String senhaAdmPostgreSQL) {
		this.senhaAdmPostgreSQL = senhaAdmPostgreSQL;
	}
	public String getPessoaLogged() {
		return pessoaLogged;
	}
	public void setPessoaLogged(String pessoaLogged) {
		this.pessoaLogged = pessoaLogged;
	}
	public String getUserLogged() {
		return userLogged;
	}
	public void setUserLogged(String userLogged) {
		this.userLogged = userLogged;
	}
	public Locale getLocale() {
		return locale;
	}
	public void setLocale(Locale locale) {
		this.locale = locale;
	}
	public List<Perfil> getPerfisLogado() {
		return perfisLogado;
	}
	public void setPerfisLogado(List<Perfil> perfisLogado) {
		this.perfisLogado = perfisLogado;
	}	
}
