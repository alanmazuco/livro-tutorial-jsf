package br.eti.amazu.blankapp.view.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.apache.log4j.Level;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import br.eti.amazu.component.dialog.DialogBean;
import br.eti.amazu.component.dialog.DialogType;
import br.eti.amazu.component.pworld.util.CompoundMenu;
import br.eti.amazu.component.upload.Upload;
import br.eti.amazu.component.upload.UploadMode;
import br.eti.amazu.blankapp.view.vo.Arquivo;
import br.eti.amazu.blankapp.view.vo.Path;
import br.eti.amazu.util.FacesUtil;
import br.eti.amazu.util.FileUtil;
import br.eti.amazu.util.log.Log;

@Named
@ViewScoped
public class ManterArquivosBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Inject
	DialogBean dialogBean;
	
	/* default eh o disco "C:/blankapp/files/"*/
	static final String RESOURCE = "C:/blankappFiles/"; //
	String visibilidade;
	private List<Path> paths = new ArrayList<Path>();
	private Path path;
	private Arquivo arquivo;
	private StreamedContent scArquivo;
	private Upload upload;
	private String fullPath;
	String directoryOldName;
	String fileOldName;
	private String nomeLocalizar;	
	private Integer index;
	
	@CompoundMenu //O metodo que executa o menu "Download" (publico externo).
	public void iniciarPaginaDownloads(){
		Log.setLogger(ManterArquivosBean.class, "modulo download - publico externo", Level.INFO, null);
		FacesUtil.resetBeans(null);
		visibilidade = "pubExterno"; //Visibilidade: Inicializa o UC para o publico externo (internauta comum).
		this.listarArquivos();
	}
	
	@CompoundMenu //Executa o menu "Administracao/Ferramentas/Manter Arquivos" (publico interno).
	public void iniciarManterArquivos(){
		Log.setLogger(ManterArquivosBean.class, "modulo download - publico interno", Level.INFO, null);			
		FacesUtil.resetBeans("manterArquivosBean"); //Reseta todos os beans, exceto manterArquivosBean.
		visibilidade = "pubInterno"; //Visibilidade: Inicializa o UC para o publico interno (usuario logado).
		this.listarArquivos();
	}
	
	
	public void listarArquivos(){
		String resourceFiles = RESOURCE;
		
		if(visibilidade.equals("pubInterno")){
			
			/* Verifica se o path existe no servidor, se nao existir, cria-o.
			 * path = O caminho relativo do aplicativo, onde possam estar os arquivos ("/resources/files").
			 * fullResourceFiles = "C:\meuServidor\meuAplicativo\...." 
			 * - O caminho completo do servidor onde possam estar os arquivos.*/
			if(!FileUtil.isExisteFileOrDir(resourceFiles)){
				FileUtil.criarDiretorio(resourceFiles);
			}
			
			/* O retorno eh condicional: 
			 * - Se a visibilidade for "pubInterno", apresenta a lista de arquivos para manipulacao.
			 * - Se a visibilidade for "pubExterno", apresenta a pagina de dowload publica. */			
			FacesUtil.redirect("/pages/adm/manterArquivos/listaArquivos");
			
		}else{
			FacesUtil.redirect("/pages/home/homeDownload");
		}		
	}
	
	List<Arquivo> getListaArquivos(String fullPathFile, List<Arquivo> listaArquivos) {
		File dir = new File(fullPathFile);
	    String lista[] = dir.list();        
	    
	    if(lista != null){	    
	    	Long l = 1L;
	        for(String strArq:lista){        	
	        	File file = new File(fullPathFile + "/" + strArq);
	        	Arquivo arquivo = new Arquivo();
	        	if(file.isFile()){
	        		arquivo.setId(l);
	        		arquivo.setName(file.getName());
	        		arquivo.setSize((double) file.length()/1000);	        		
	        		listaArquivos.add(arquivo);	        		
	        		l++;
	        	}
	        }
	    }
	    
	    Collections.sort(listaArquivos, new Comparator<Arquivo>() { 
		    @Override
			public int compare(Arquivo c1, Arquivo c2) { 
		          return (c1.getName().compareTo (c2.getName())); 
		      }  
	    });	    
		return listaArquivos;
	}	
	
	/*---------------------------------
	 * OPERACOES COM PASTAS
	 --------------------------------*/
	public void setarPasta(javax.faces.event.AjaxBehaviorEvent event){       
	    Map<String, Object> map = event.getComponent().getAttributes();         
	    path = (Path) map.get("value");
	    if(path == null){
	    	fullPath = null;
	    	
	    }else{
	    	fullPath = RESOURCE + path.getName();
	    }	    
	} 
	
	public void chamarIncluirOuAlterarPasta(String op){		
		/* op = "1" = new
		 * op = "2" = edit*/		
		if(op.equals("1" )) {
			path = new Path();
			
		}else{
			directoryOldName = path.getName();
		}		
		RequestContext context = RequestContext.getCurrentInstance();
		context.update("formFolder");
		context.execute("PF('dlgFolder').show()");
	}
	
	public void incluirOuAlterarPasta(){	
		try{						
			if(!FileUtil.isExisteFileOrDir(RESOURCE + path.getName())){				
				if(path.getId() == null){
					FileUtil.criarDiretorio(RESOURCE + path.getName());
					
					//Atualiza a lista de paths e mostra mensagem de sucesso.					
					path.setId(Long.valueOf(String.valueOf(paths.size()+1)));
					paths.add(path);;
					dialogBean.addMessage(FacesUtil.getMessage("MAR020"), DialogType.INFO_CLOSABLE,null);
					
				}else{								
					//se modificou, salva o novo nome
					FileUtil.renomearFileOrDir(RESOURCE + directoryOldName, RESOURCE + path.getName());			
					dialogBean.addMessage(FacesUtil.getMessage("MAR023"), DialogType.INFO_CLOSABLE,null);		
				}
				
			}else{	
				//ver se modificou o nome do path 
				if(!path.getName().equals(directoryOldName)){
					dialogBean.addMessage(FacesUtil.getMessage("MAR024"), DialogType.INFO_CLOSABLE,null);
					return;
				}
			}				
			RequestContext context = RequestContext.getCurrentInstance();
			context.update("formArquivos:selectPasta");			
			closeDlgFolder();			
			
		} catch (FileNotFoundException e) {
			dialogBean.addMessage(FacesUtil.getMessage("MGL074"), DialogType.INFO_CLOSABLE,null);
			
		} catch (IOException e) {
			dialogBean.addMessage(FacesUtil.getMessage("MGL074"), DialogType.INFO_CLOSABLE,null);
		}
	}
	
	public void cancelarIncluirOuAlterarPasta(){
		 closeDlgFolder();
	}
	
	void closeDlgFolder(){
		RequestContext context = RequestContext.getCurrentInstance();
		context.execute("PF('dlgFolder').hide();");		
	}
	
	public String confirmarExcluirPasta(){
		String[] params = {path.getName()};		
		dialogBean.addConfirmMessage(FacesUtil.getMessage("MAR025",params), 
				"manterArquivosBean.excluirPasta", null, ":formArquivos");
		
		return null;
	}
	
	public void excluirPasta(){
		FileUtil.excluirDiretorio(RESOURCE + path.getName());
		
		//Atualiza a lista de paths e mostra mensagem de sucesso.
		Iterator<Path> it = paths.iterator();
		while (it.hasNext()) {  
		   Path p = it.next();  
		   if (p.equals(path)){  
			    it.remove();
			    continue;
		   }
		}
		path = null; //permite retornar ao estado atual do selectOne ([SELECT]).
		this.getPaths();
	}
	
	public List<Path> getPaths() {
		paths = new ArrayList<Path>();
		String resourceFiles = RESOURCE;
	
		//Listando todos as pastas no diretorio de fullResourceFiles...
		List<String> lista = FileUtil.listarDiretorios(resourceFiles);
		Long l =1L;
		for(String str : lista){
			Path path = new Path();
			path.setId(l);
			path.setName(str);
						
			//buscando os arquivos em cada path...
			List<Arquivo> listaArquivos = new ArrayList<Arquivo>();
			path.setListaArquivos(this.getListaArquivos(
					resourceFiles + path.getName(), listaArquivos));					
			paths.add(path);			
			l++;
		}
		return paths;
	}	
	
	/*---------------------------------------
	 * OPERACOES COM ARQUIVOS
	 --------------------------------------*/
	public void chamarRenomearArquivo(){
		index = Integer.valueOf(FacesUtil.getParam("index")); //pegando o index da view
		fileOldName = arquivo.getName();
		RequestContext context = RequestContext.getCurrentInstance();
		context.update("formRenFile");
		context.execute("PF('dlgRenFile').show();");	
	}
	
	public String renomearArquivo(){	
		try {	
	        String oldName = fileOldName;		
			String newName = arquivo.getName();				
			int posO = oldName.lastIndexOf(".");	//Pega extensao original do arquivo.
			int posN = newName.lastIndexOf(".");	//Pega extensao digitada pelo usuario.
			
			//Verifica se usuario digitou extensao.
			if(posN != -1){			
				newName = newName.substring(0,posN) + oldName.substring(posO);				
			}else{			
				newName = newName + oldName.substring(posO);
			}			
			arquivo.setName(newName);
			
			//atualizando ao veiw
			path.getListaArquivos().set(path.getListaArquivos().indexOf(arquivo), arquivo);		
			FileUtil.renomearFileOrDir(RESOURCE + path.getName() + "/" + 
						oldName, RESOURCE + path.getName() + "/"  + newName);		
			
			closeDlgRenFile();			
			dialogBean.addMessage(FacesUtil.getMessage("MAR026"), DialogType.INFO_CLOSABLE,null);			
			
		} catch (FileNotFoundException e) {
			dialogBean.addMessage(FacesUtil.getMessage("MGL073"), DialogType.INFO_CLOSABLE,null);
			
		} catch (IOException e) {
			dialogBean.addMessage(FacesUtil.getMessage("MGL073"), DialogType.INFO_CLOSABLE,null);
		}
		return null;
	}
	
	public void cancelarRenomearArquivo(){
		closeDlgRenFile();
	}
	
	void closeDlgRenFile(){	
		RequestContext context = RequestContext.getCurrentInstance();		
		context.execute("PF('dlgRenFile').hide();");		
		updateRow();
	}
	
	//Este metodo possibilita dar um update apenas na linha da tabela pessoa.
	public void updateRow() {
		if(index != null){
			FacesContext ctx = FacesContext.getCurrentInstance();		
			DataTable dataTable = (DataTable) ctx.getViewRoot().findComponent("formArquivos:tableArquivos");	
			RequestContext.getCurrentInstance().update(dataTable.getClientId(ctx)+ ":" + index + ":pnlName");	
		}
	}
	
	public String confirmarExcluirArquivo(){
		String[] params = {arquivo.getName()};		
		dialogBean.addConfirmMessage(FacesUtil.getMessage("MAR027",params), 
				"manterArquivosBean.excluirArquivo", null, ":formArquivos");		
		return null;
	}
	
	public void excluirArquivo(){		
		try {
			FileUtil.excluirArquivo(RESOURCE + path.getName() + "/" + arquivo.getName());
	
			//Atualiza a lista de paths e mostra mensagem de sucesso.
			Iterator<Arquivo> it = path.getListaArquivos().iterator();
			while (it.hasNext()) {  
			   Arquivo a = it.next();  
			   if (a.equals(arquivo)){  
				    it.remove();
				    continue;
			   }
			}			
			
		} catch (FileNotFoundException e) {
			dialogBean.addMessage(FacesUtil.getMessage("MGL073"), DialogType.INFO_CLOSABLE,null);			
		} catch (IOException e) {
			dialogBean.addMessage(FacesUtil.getMessage("MGL073"), DialogType.INFO_CLOSABLE,null);
		}
	}
	
	public void chamarLocalizarArquivos(){
		RequestContext context = RequestContext.getCurrentInstance();
		context.update("formLocalizar");
		context.execute("PF('dlgLocalizar').show()");
	}
	
	public void cancelarLocalizarArquivos(){
		RequestContext context = RequestContext.getCurrentInstance();		
		context.execute("PF('dlgLocalizar').hide()");
		nomeLocalizar = null;
	}
	
	public void localizarArquivos(){		
		if(nomeLocalizar.length() < 3){
			dialogBean.addMessage(
					"Digite um minimo de 3 caracteres para a pesquisa.", DialogType.INFO_CLOSABLE);
			return;
		}
		
		this.getPathLocalizaArquivos(nomeLocalizar);		
		RequestContext context = RequestContext.getCurrentInstance();
		context.update("formArquivos:tableArquivos");		
		context.execute("PF('dlgLocalizar').hide()");
	}	
	
	void getPathLocalizaArquivos(String nomeArquivo){				
		List<Arquivo> listaArquivos = new ArrayList<Arquivo>();
		for(Path p:paths){
			for(Arquivo a:p.getListaArquivos()){
				if(a.getName().toLowerCase().contains(nomeArquivo.toLowerCase())){
					listaArquivos.add(a);
				}
			}
		}		
		path.setListaArquivos(listaArquivos);
	}
	
	public StreamedContent getScArquivo() {
		try {			
	        String fullFile = RESOURCE + path.getName() + "/" + arquivo.getName();	        
	        
	        scArquivo = new DefaultStreamedContent(
	        	FileUtil.getInputStream(fullFile),
	        	FileUtil.getMimeType(fullFile),
	        	arquivo.getName()
	        );	        
			return scArquivo;
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return null;		
	}
		
	/*-------------------------------
	 * UPLOAD DE ARQUIVOS
	 -------------------------------*/
	public void chamarUpload(){ //Inicializa o componente Upload em modo FILE.					
		upload = new Upload(
				dialogBean, 
				UploadMode.FILE_SERVER, 
				fullPath, 
				"manterArquivosBean.atualizeAposUpload", //.....a acao que serah executada apos o upload
				false);
	}
	
	public void atualizeAposUpload(){
		
		//buscando os arquivos em cada path...
		List<Arquivo> listaArquivos = new ArrayList<Arquivo>();
		path.setListaArquivos(this.getListaArquivos(RESOURCE + path.getName(), listaArquivos));		
		paths.set(paths.indexOf(path), path);		
		RequestContext context = RequestContext.getCurrentInstance();
		context.update("formArquivos:tableArquivos");
	}


	/*---------------------
	 * get/set simples
	 ---------------------*/
	public String getVisibilidade() {
		return visibilidade;
	}
	public void setVisibilidade(String visibilidade) {
		this.visibilidade = visibilidade;
	}
	public Path getPath() {
		return path;
	}
	public void setPath(Path path) {
		this.path = path;
	}
	public Arquivo getArquivo() {
		return arquivo;
	}
	public void setArquivo(Arquivo arquivo) {
		this.arquivo = arquivo;
	}
	public Upload getUpload() {
		return upload;
	}
	public void setUpload(Upload upload) {
		this.upload = upload;
	}
	public String getFullPath() {
		return fullPath;
	}
	public void setFullPath(String fullPath) {
		this.fullPath = fullPath;
	}
	public String getDirectoryOldName() {
		return directoryOldName;
	}
	public void setDirectoryOldName(String directoryOldName) {
		this.directoryOldName = directoryOldName;
	}
	public String getFileOldName() {
		return fileOldName;
	}
	public void setFileOldName(String fileOldName) {
		this.fileOldName = fileOldName;
	}
	public String getNomeLocalizar() {
		return nomeLocalizar;
	}
	public void setNomeLocalizar(String nomeLocalizar) {
		this.nomeLocalizar = nomeLocalizar;
	}
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	public void setPaths(List<Path> paths) {
		this.paths = paths;
	}
	public void setScArquivo(StreamedContent scArquivo) {
		this.scArquivo = scArquivo;
	}
	
}