package br.eti.amazu.blankapp.view.vo;

import br.eti.amazu.component.pworld.domain.AbstractEntity;

public class Arquivo extends AbstractEntity<Long> {

	private static final long serialVersionUID = 1L;
		
	public Arquivo() {
		super();
	}
	
	public Arquivo(Long id) {
		super();
		this.id = id;
	}

	private Long id;
	private String name;
	private Double size;

	/*--------
	 * get/set
	 ---------*/
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getSize() {
		return size;
	}
	public void setSize(Double size) {
		this.size = size;
	}

}
