package br.eti.amazu.blankapp.view.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.ejb.Asynchronous;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.apache.log4j.Level;
import org.primefaces.context.RequestContext;

import br.eti.amazu.blankapp.domain.infra.Empresa;
import br.eti.amazu.blankapp.domain.infra.Perfil;
import br.eti.amazu.blankapp.domain.infra.Pessoa;
import br.eti.amazu.blankapp.domain.infra.Usuario;
import br.eti.amazu.blankapp.persistence.facade.IAppFacade;
import br.eti.amazu.blankapp.persistence.facade.IAppMailFacade;
import br.eti.amazu.blankapp.view.bean.common.ConfigBean;
import br.eti.amazu.blankapp.view.bean.common.MenuBean;
import br.eti.amazu.blankapp.view.bean.common.UserSessionInBean;
import br.eti.amazu.component.dialog.DialogBean;
import br.eti.amazu.component.dialog.DialogType;
import br.eti.amazu.component.progressbar.ProgressBean;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.component.pworld.persistence.exception.MailException;
import br.eti.amazu.component.pworld.util.CompoundMenu;
import br.eti.amazu.util.Crypt;
import br.eti.amazu.util.DateUtil;
import br.eti.amazu.util.FacesUtil;
import br.eti.amazu.util.RegexUtil;
import br.eti.amazu.util.log.Ansi;
import br.eti.amazu.util.log.Log;

@Named
@ViewScoped
public class RealizarLoginBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	IAppFacade<Empresa> empresaFacade;
	
	@Inject
	IAppFacade<Usuario> usuarioFacade;
	
	@Inject	
	IAppFacade<Pessoa> pessoaFacade;
	
	@Inject	
	IAppFacade<Perfil> perfilFacade;
	
	@Inject
	IAppMailFacade appMailFacade;
	
	@Inject
	ConfigBean configBean;
	
	@Inject
	DialogBean dialogBean;
	
	@Inject
	MenuBean menuBean;
	
	@Inject
	UserSessionInBean userSessionInBean;
	
	@Inject
	ProgressBean progressBean;
		
	private String user; //Utilizado na pagina login.
	private String password; //Utilizado na pagina login.
	private String newPassword; //Utilizado na pagina primeiroAcesso (trocar a senha).
	private String confirmNewPassword; //Utilizado na pagina primeiroAcesso (trocar a senha).	
	private Usuario usuario;
	private List<Pessoa> pessoas;
	private List<Empresa> empresas;
	
	// Quantidade de vezes que um usuario nao adiministrador tenta efetuar o login
	int contador = 0;
	
	@CompoundMenu
	public String iniciarRealizarLogin(){		
		FacesUtil.resetBeans(null); //param null: porque o bean estah no escopo de request.
		return "/pages/realizarLogin/login?faces-redirect=true";
	}
	
	@CompoundMenu
	public String iniciarRealizarLogout(){ //sair...
		FacesUtil.sessionInvalidate();		
		return "/pages/home/homePage?faces-redirect=true";
	}	
	
	/* ********************
	 * UC - REALIZAR LOGIN
	 * VALIDAR E AUTENTICAR
	 *********************/
	//Metodo que realiza a autenticacao do usuario
	public String autenticarUsuario(){		
		try{			
			if((user == null || user.equals("")) && (password == null || password.equals(""))){
				dialogBean.addMessage(FacesUtil.getMessage("RLO001"), DialogType.ERROR);
				return null;
			}
			
			if(user == null || user.equals("")){
				dialogBean.addMessage(FacesUtil.getMessage("RLO002"), DialogType.ERROR);
				return null;
			}
			
			if(password == null || password.equals("")){
				dialogBean.addMessage(FacesUtil.getMessage("RLO003"), DialogType.ERROR);
				return null;
			}
			
			if(isUsuarioValido()){ //Usuario eh valido?
				
				
				
				/* O USUARIO EXISTE --> VERIFICAR SE ELE ESTAH BLOQUEADO
				* se o usuario estiver bloqueado (bloqueado=T), nao entra... */
				if (usuario.getBloqueado().equals("T")){
					dialogBean.addMessage(FacesUtil.getMessage("RLO004"), DialogType.INFO_CLOSABLE);
					return null;
				}
				
				/* USUARIO NAO ESTAH BLOQUEADO - VERIFICA A SENHA
				* Aqui faz a comparacao da senha obtida no banco de dados com a
				* senha aplicada na pagina login. Quantas vezes deve-se verificar a senha? 3...
				* Usuario administrador tem acesso ilimitado...
				* Os outros iniciam a contagem para bloquear o usuario.*/
				if(isSenhaValida()){
					
					/* Neste caso a senha estah valida: PASSOU POR TODAS AS VERIFICACOES.
					* Verifica se eh o primeiro acesso: Se for, direciona-o para a pagina de trocar a senha,
					* onde ele serah convidado a trocar a sua senha.
					* O USUARIO ESTAH LOGADO (PARCIALMENTE).*/
					if(usuario.getPrimeiroAcesso().equals("T")){
											
						//Aqui vai apenas o nome do usuario... (parcialmente logado)						
						userSessionInBean.setPerfisLogado(usuario.getPerfis().stream().collect(Collectors.toList()));
						userSessionInBean.setUserLogged(usuario.getNomeUsuario());						
						retornarPagTrocaSenha();
					}
					
					//usuario estah sem prefil...
					if(usuario.getPerfis() == null) {
						dialogBean.addMessage(FacesUtil.getMessage("RLO055"), DialogType.INFO_CLOSABLE);
						return null;
					}
					
					/* Nao eh o 1� acesso - usuarios unicamente visitantes nao expiram senha, portanto acaba aqui 
					 * para eles - (efetua o login desde jah). Se o usuario possui apenas o perfil de visitante...*/					
					if(usuario.getPerfis().size() == 1 && containsPerfil(usuario.getPerfis(), 5L)) {
											
						/* Loga, mas lembre-se: Usuarios visitantes ou outros que nao sejam os operadores padroes,
						* devem possuir acesso limitado ao sistema. Esta limitacao pode ser imposta pelo operador
						* que realizou o seu cadastro, naquele momento ele pode conceder privilegios de acesso aos 
						* menus (visitantes quase sempre nao teem acesso aos menus da administracao, mas podem
						* ter acessos a outros menus que sejam publicos).*/
						this.usuarioLogado(true);
						return null;					
					}				
				
					/* Daqui para baixo, soh usuarios desenvolvedores, administradores e operadores.
					* Aqui realiza o calculo para saber se sua senha estah expirada.*/
					int tempoDaSenha = calcularPrazoExpiraSenha();
									
					/* OBTIDO O TEMPO DA SENHA: TRES CAMINHOS A SEREM TOMADOS:
					* a) Se o tempo da senha ainda nao atingiu 30 dias, prossegue o login...
					* b) Se o tempo da senha passou de 30 dias - inicia-se o aviso de "senha prestes a expirar".
					* c) Se o tempo da senha passou de 45 dias, avisa ao usuario de
					* que a sua senha estah expirada. Ele nao poderá logar e
					* receberah uma mensagem para procurar o administrador. */
					if (tempoDaSenha > 45){
						
						
						
						/* Se for um usuario desenvolvedor ou administrador, nao hah bloqueio por tempo
						 * de senha expirada, apenas mostra uma mensagem perguntando se ele quer trocar
						 * a senha agora. (por motivos de seguranca), caso contrario (nao eh dev ou adm),
						 * informa que a senha expirou. Usuario estah logado somente para dev ou adm. */
						if ( containsPerfil(usuario.getPerfis(), 1L) || containsPerfil(usuario.getPerfis(), 2L) ){
							
							this.usuarioLogado(false);						
							dialogBean.addConfirmMessage(
									FacesUtil.getMessage("RLO005"), //.........................	message
									"realizarLoginBean.retornarPagTrocaSenha", //..............	actionButtonYes
									"realizarLoginBean.retornarPagHomeAplicativo", //..........	actionButtonNo								
									null, //...................................................	updateButtonYes
									null); //..................................................	updateButtonNo							
							return null;
							
						}else{							
							//Nao eh dev ou adm - informa senha expirada.
							dialogBean.addMessage(FacesUtil.getMessage("RLO006"), DialogType.INFO_CLOSABLE);
							return null;
						}
					}
					
					if (tempoDaSenha > 30 && tempoDaSenha <=45){
						
						/* Apresenta uma mensagem que a senha estah prestes a expirar, mas tem de autenticar,
						* solicitando que ele troque agora a sua senha (não eh obrigatorio trocar agora),
						* pois pode-se continuar logado nesta situacao (isto eh apenas um aviso). */
						this.usuarioLogado(false);
						
						String tempoExpiracao = String.valueOf(45 - tempoDaSenha);
						String[] params = {tempoExpiracao};
						
						dialogBean.addConfirmMessage(							
								FacesUtil.getMessage("RLO007",params), //......................	message
								"realizarLoginBean.retornarPagTrocaSenha", //.................	actionButtonYes
								"realizarLoginBean.retornarPagHomeAplicativo", //.............	actionButtonNo
								null, //.......................................................	updateButtonYes
								null); //......................................................	updateButtonNo						
						return null;
					}
					
					/* Chegou ateh aqui, seu tempo de senha estah dentro de 30 dias.
					* Entao basta autenticar o usuario.*/
					this.usuarioLogado(true);
					
				}else{					
					// SENHA INVALIDA... 
					
					//Se for unicamente um visitante nao incrementa o contador
					if(usuario.getPerfis().size() == 1 && containsPerfil(usuario.getPerfis(), 5L)) {
						dialogBean.addMessage(FacesUtil.getMessage("RLO052"), DialogType.INFO_CLOSABLE);
						return null;
					}
					
					// nao eh administrador nem desenvolvedor, nem unicamente visitante, incrementa o contador.
					if ( !containsPerfil(usuario.getPerfis(), 1L) && !containsPerfil(usuario.getPerfis(), 2L) ){
												
						contador++; 										
						
						
						
						//Se atingiu 3 tentativas avisa que se errar na proxima vai bloquear...
						if (contador == 3){
							dialogBean.addMessage(FacesUtil.getMessage("RLO008"), DialogType.INFO_CLOSABLE);
							return null;
						}
						
						// Se o numero de tentativas for maior que 3, bloqueia o usuario.
						if (contador > 3){
							contador = 0;
							usuario.setBloqueado("T");
							Pessoa pessoa = usuario.getPessoa();
							pessoa.getUsuario().setBloqueado("T");
							usuarioFacade.alterar(usuario);
							dialogBean.addMessage(FacesUtil.getMessage("RLO009"), DialogType.INFO_CLOSABLE);
							return null;
						}
						
					} //Fim da rotina usuarios nao administradores - senha.
					
					/* Em seguida, apos somar +1 a variavel "contador",
					* exibe a mensagem de senha invalida para todos os tipos de usuarios.*/
					dialogBean.addMessage(FacesUtil.getMessage("RLO010"), DialogType.INFO_CLOSABLE);
					return null;						
				}//Fim da rotina senha invalida
				
			}else{				
				//Usuario nao foi encontrado no banco de dados...
				dialogBean.addMessage(FacesUtil.getMessage("RLO011"), DialogType.INFO_CLOSABLE);
				return null;
			}
			
		}catch(DaoException e){
			e.printStackTrace();
		}		
		return null;		
	}
				
	private boolean isUsuarioValido(){			
		try {
			/* Inicializa um array de parametros, a ser utilizado na consulta. Este
			 * parametro eh o nome do usuario digitado na tela de login.
			 * - usuario --------------> possui os dados da tela de login;
			 * Lembrando que o campo NOME da tabela USUARIO eh chave unica, portanto o resultado
			 * da consulta abaixo eh para trazer apenas um registro (por isto utilizou o metodo "recuperar").*/	
			ArrayList<Object> params = new ArrayList<Object>();
			params.add(user); //Adiciona o nome de usuario para o parametro de consulta.
			usuario = usuarioFacade.recuperar("Usuario.recuperarPeloNome", params);
			
			/* VERIFICA SE O USUARIO EXISTE.
			* Se a fachada conseguiu encontrar um registro no banco de dados com o
			* nome de usuario digitado na tela de login, retorna "true"...*/
			if(usuario != null) return true;
			
		} catch (DaoException e) {
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
		}		
		return false; //Nao encontrou o usuario, retorna "false"...
	}
		
	//Verifica se a senha do usuario eh valida (realiza descriptografia)
	private boolean isSenhaValida(){
		try {			
			/* Recebe a senha digitada no browser.
			 * Lembrando que esta senha foi mascarada com CriptpJs (ela deve ser descriptografada)
			 * antes de cmparar com a do banco de dados.*/						
			String passw; //chegando aqui a senha criptografada
			Log.setLogger("", "Senha com CriptoJs: " + password, Level.INFO, Ansi.RED);
			passw = Crypt.decrypt(password);
			Log.setLogger("", "Senha  -   original: " + passw, Level.INFO, Ansi.RED);		
			//com a senha original recuperada, realiza a comparacao			
			if (Crypt.checkPassword(passw, usuario.getSenha())) {				
				return true;
				
			}else {
				return false;
			}
			
		} catch (Exception e) {
			dialogBean.addMessage(FacesUtil.getMessage("RLO052"), DialogType.FATAL_ERROR);
		}
		return false;
	}	

	private void usuarioLogado(boolean mostraDialog){
		
		/* Isto irah informar ao "userSessionInBean" os dados do usuario logado.
		 * Com isto, os menus serao instanciados conforme os perfis do usuario que estah logado neste momento.*/
		userSessionInBean.setPerfisLogado(usuario.getPerfis().stream().collect(Collectors.toList()));
		userSessionInBean.setPessoaLogged(usuario.getPessoa().getNome());
		userSessionInBean.setUserLogged(usuario.getNomeUsuario());	
		userSessionInBean.setEmpresa(usuario.getPessoa().getEmpresa());
		userSessionInBean.setUsuarioDevLogado(containsPerfil(usuario.getPerfis(), 1L));
		configBean.setConfiguracoes(); //refazendo as configuracoes do usuario logado
		menuBean.criarMenu();
		
		if(mostraDialog){
			
			/* Retorna para homePage, se usuario visitante. Ir para homeAplicativo, se usuario nao visitante.*/
			if(usuario.getPerfis().size() == 1 && containsPerfil(usuario.getPerfis(), 5L)) {
				dialogBean.addActionMessage(FacesUtil.getMessage("RLO012"), 
						"realizarLoginBean.retornarPagHomePage", null);				
				
			}else{
				dialogBean.addActionMessage(FacesUtil.getMessage("RLO012"), 
						"realizarLoginBean.retornarPagHomeAplicativo", null);
			}
		}
		
	}
		
	private int calcularPrazoExpiraSenha(){
		
		/* OBTER O TEMPO DE SUA SENHA
		* Via de regra, a senha expira em 45 dias apos o primeiro acesso.
		* Solicita a classe utilitaria a realizar o calculo da diferenca entre as datas.	*/
		return DateUtil.getDiferencaEntreDatas (usuario.getDataPrimeiroAcesso(), new Date());
	}		
	
	boolean containsPerfil(Set<Perfil> perfis, Long idPerfil) {
		for(Perfil perfil:perfis) {
			if(idPerfil == perfil.getId()) {
				return true;
			}
		}
		return false;
	}
		
	
	/* Redirects comuns
	 ----------------*/
	public void retornarPagHomePage(){FacesUtil.redirect("/pages/home/homePage");}	
	public void retornarPagTrocaSenha(){FacesUtil.redirect("/pages/adm/trocarSenha/trocaSenha");}	
	public void retornarPagHomeAplicativo(){FacesUtil.redirect("/pages/adm/homeAplicativo");}	
	public String retornarNulo(){return null;}	
	public String retornarPagRecuperaSenha(){return "/pages/realizarLogin/recuperaSenha?faces-redirect=true";}			
	public String retornarPagCadastreMe(){return "/pages/realizarLogin/cadastreMe?faces-redirect=true";}		
	public void retornarPagLogin(){FacesUtil.redirect("/pages/realizarLogin/login");}
	/* ***************************
	 * FIM DE UC - REALIZAR LOGIN
	 * VALIDAR E AUTENTICAR
	 ****************************/
	
	
	/* *******************
	 * UC - TROCAR A SENHA
	 *********************/	
	public void trocarSenha(){
		try{	
			
			
			if(newPassword == null || newPassword.equals("")){
				dialogBean.addMessage(FacesUtil.getMessage("RLO043"), DialogType.ERROR);
				return;
			}
			
			if(confirmNewPassword == null || confirmNewPassword.equals("")){
				dialogBean.addMessage(FacesUtil.getMessage("RLO044"), DialogType.ERROR);
				return;
			}
			
			/* Recebe a senha digitada no browser (jah criptografada).
			 * Lembrando que esta senha foi mascarada com CriptpJs (ela deve ser descriptografada)
			 * antes de cmparar com a do banco de dados.*/			
			String newPassw = Crypt.decrypt(newPassword);
			String confirmeNewPassw = Crypt.decrypt(confirmNewPassword);
			
			//verifica se possui minimo de 3 caracteres
			if(newPassw.length() < 3) {
				dialogBean.addMessage(FacesUtil.getMessage("RLO045"), DialogType.ERROR);
				return;
			}
			
			//verifica se possui caracteres invalidos...
			if (!newPassw.matches("[a-zA-Z0-9_]+")) {
				dialogBean.addMessage(FacesUtil.getMessage("MGL004"), DialogType.ERROR);
				return;
			}
			
			if(newPassw.equals(confirmeNewPassw)){				
				
				/* Isto irah atualizar os dados do usuario em seu primeiro acesso.*/
				List<Object> params = new ArrayList<Object>();
				params.add(userSessionInBean.getUserLogged());
				if(usuario == null) usuario = usuarioFacade.recuperar("Usuario.recuperarPeloNome", params);				
				usuario.setSenha(Crypt.getHash(newPassw));
				usuario.setDataPrimeiroAcesso(new Date());
				usuario.setPrimeiroAcesso("F");
				usuarioFacade.alterar(usuario);
				this.usuarioLogado(true);
				
			}else{
				dialogBean.addMessage(FacesUtil.getMessage("RLO013"), DialogType.INFO_CLOSABLE);
			}
			
		}catch(DaoException e){
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
		}
		
	}
	/* **************************
	 * FIM DE UC - TROCAR A SENHA
	 ***************************/	
	
	
	/* ******************
	 * UC LEMBRAR A SENHA
	 *******************/
	private String emailVisitante;
	
	public void recuperarVisitantePeloEmail(){		
		try {
			/*  A recuperacao da pessoa deve ser feita unicamente pelo seu email
			 * Verificando se existe usuario cuja pessoa possui um mesmo email. */
			List<Object> params = new ArrayList<Object>();
			params.add(emailVisitante);
			List<Pessoa> pessoas = pessoaFacade.listar("Pessoa.recuperarPeloEmail", params);
			
			if(pessoas == null){
				dialogBean.addMessage(FacesUtil.getMessage("RLO014", new String[]{user}), DialogType.INFO_CLOSABLE);
				return;
			}
			
			//pessoas ===> lista de pessoas de uma mesma pessoa que se cadastrou em mais de uma unidade.
			Pessoa pessoa = pessoas.get(0);	//...por isto pega o primeiro da lista (todos sao os mesmos).
			
			//se pessoa for um desenvolvedor, nada faz...
			if(containsPerfil(pessoa.getUsuario().getPerfis(), 1L)) {
				Log.setLogger("", "Procure o Gerente do Projeto.", Level.INFO, Ansi.RED_BOLD_YELLOWBG);
				return; //nada faz... desenvolvedor se vira com a sua senha!
			}
			
			if(pessoas.size() == 1) {							
				if(pessoa.getUsuario() != null){					
					this.salvarEnviarEmail(pessoa);
					
				}else{				
					//Invalida a sessao (se nao existe um usuario cadastrado para esta pessoa)...
					FacesUtil.sessionInvalidate();
						dialogBean.addActionMessage(FacesUtil.getMessage("RLO018"), 
							"realizarLoginBean.retornarNulo", null);
				}
				
			}else {
				//Se existe mais de uma pessoa cadastrada com o mesmo nome (em empresas diferentes)
				this.pessoas = pessoas; //disponibiliza pessoas para a pagina
				
				//abrir um dlg para que o usuario especifique qual empresa quer mudar a senha.
				RequestContext context = RequestContext.getCurrentInstance();				
				context.execute("PF('dlgFixaEmpresa').show();");	
				context.update("formFixaEmpresa");
			}
			
		} catch (DaoException e) {
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
			
		} catch (Exception e){
			dialogBean.addMessage(FacesUtil.getMessage("RLO027"), DialogType.ERROR);			
		} 	
		
	}
	
	public void fixarEmpresaEnviarEmail(Long idEmpresa) {		
		for(Pessoa pessoa : pessoas) {//localizar a pessoa com a empresa passada
			if(pessoa.getEmpresa() != null && pessoa.getEmpresa().getId() == idEmpresa) {
				this.salvarEnviarEmail(pessoa);
				break;
			}
		}
	}
	
	public void salvarEnviarEmail(Pessoa pessoa) {		
		try {
			//Reseta a senha do usuario.
			String senhaDescriptografada = getSenhaPosReset(); //Gera nova senha
			pessoa.getUsuario().setSenha(Crypt.getHash(senhaDescriptografada)); //obtem o hash da nova senha
			pessoa.getUsuario().setPrimeiroAcesso("T");
			pessoa.getUsuario().setDataPrimeiroAcesso(new Date());
			pessoa.getUsuario().setBloqueado("F"); //desbloqueia por garantia...
			pessoaFacade.alterar(pessoa);
			
			//enviar um email ao usuario
			this.enviarEmail(pessoa.getEmail(), //email do usuario
					FacesUtil.getMessage("RLO017") + ": " + senhaDescriptografada); //mensagem com a senha
			
			//Invalida a sessao (se existia uma)...
			FacesUtil.sessionInvalidate();
				dialogBean.addActionMessage(FacesUtil.getMessage("RLO019"), 
					"realizarLoginBean.retornarPagHomePage", null);
			
		} catch (DaoException e) {
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
			
		
		
		} catch (Exception e){
			dialogBean.addMessage(FacesUtil.getMessage("RLO027"), DialogType.ERROR);			
		} 	
		
	}
	
	//devolve uma nova senha randomicamente. Este metodo tambem eh aproveitado em recursosHumanosBean
	public String getSenhaPosReset() {
		String[] carct ={"0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f","g",
	    		"h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A",
	    		"B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q",
	    		"R","S","T","U","V","W","X","Y","Z"};
	    String senha="";
	    for (int x=0; x<10; x++){
	        int j = (int) (Math.random()*carct.length);
	        senha += carct[j];
	    }
		return senha;
	}
	
	//Este metodo tambem eh aproveitado em recursosHumanosBean
	@Asynchronous public void enviarEmail(String to, String message) {	     
    	try {appMailFacade.sendMail(
    				"amaz@bol.com.br", //........ from (obrigatorio ser o mesmo usuario de FTP, para smtp.bol.com.br)
    				to, //........................destinatario
    				"Amazu Technology", //........subject
    				message, //...................corpo da mensagem
    				null //.......................poderia aqui enviar uma lista (ArrayList) de caminhos de arquivos
    			);    		
		} catch (MailException e) {			
			e.printStackTrace();			
		} catch (Exception e) {			
			e.printStackTrace();
		} 	    
	}
	/* *************************
	 * FIM DE UC LEMBRAR A SENHA
	 **************************/
	
	
	/* **********************
	 * UC CADASTRAR VISITANTE
	 ***********************/
	private String nomeVisitante;
	private String identidadeVisitante;
	private String cpfVisitante;
	private Date dataNascimentoVisitante;
	
	public void cadastrarVisitante(Empresa empresa){		
		try {									
			/* Recebe a senha digitada no browser (jah criptografada).
			 * Lembrando que esta senha foi mascarada com CriptpJs (ela deve ser descriptografada)
			 * antes de cmparar com a do banco de dados.*/
			String newPassw = Crypt.decrypt(newPassword);
			String confirmeNewPassw = Crypt.decrypt(confirmNewPassword);
			
			//verifica se possui minimo de 3 caracteres
			if(newPassw.length() < 3) {
				dialogBean.addMessage(FacesUtil.getMessage("RLO045"), DialogType.ERROR);
				return;
			}
			
			//verifica se possui caracteres invalidos...
			if (!newPassw.matches("[a-zA-Z0-9_]+")) {
				dialogBean.addMessage(FacesUtil.getMessage("MGL004"), DialogType.ERROR);
				return;
			}
			
			if(!newPassw.equals(confirmeNewPassw)){
				dialogBean.addMessage(FacesUtil.getMessage("RLO013"), DialogType.ERROR);
				return;
			}
			
			/* Verifica se existe uma pessoa com os dados informados:Nao pode usuario com mesmo nome*/			
			List<Object> params = new ArrayList<Object>();
			
			//Verificando se existe um nome de usuario igual (nao pode ter nome de usuario igual)
			params.clear();
			params.add(user);
			Usuario usPeloNome = usuarioFacade.recuperar("Usuario.recuperarPeloNome", params);			
			if(usPeloNome != null){				
				dialogBean.addMessage(FacesUtil.getMessage("RLO036", new String[]{user}), DialogType.ERROR);				
				return;
			}
			
			//verificando se existe um email igual dentro de uma mesma empresa (situacao nao permitida)
			params.clear();
			params.add(emailVisitante);
			params.add(empresa.getId());
			Pessoa p = pessoaFacade.recuperar("Pessoa.recuperarPeloEmailPelaEmpresa", params);
				
			if(p != null) { //nao deixa cadastrar...
				dialogBean.addMessage(FacesUtil.getMessage("RLO040"), DialogType.ERROR);				
				return;
			}
					
			params.clear();
			params.add("VIS"); //recupera o perfil VISITANTE
			Perfil perfil = perfilFacade.recuperar("Perfil.peloCod", params);
			Set<Perfil> perfis = new HashSet<Perfil>();
			perfis.add(perfil);
			
			Pessoa pessoa = new Pessoa();
			pessoa.setNome(nomeVisitante);
			pessoa.setIdt(identidadeVisitante);
			pessoa.setCpf(cpfVisitante);
			pessoa.setDataNascimento(dataNascimentoVisitante);
			pessoa.setEmail(emailVisitante);
			pessoa.setEmpresa(empresa);
			
			Usuario usuario = new Usuario();
			usuario.setBloqueado("T");
			usuario.setPrimeiroAcesso("F");
			usuario.setDataPrimeiroAcesso(new Date());
			usuario.setNomeUsuario(user);			
			usuario.setSenha(Crypt.getHash(newPassw));						
			usuario.setPerfis(perfis);
			pessoa.setUsuario(usuario);
			usuario.setPessoa(pessoa);			
			pessoaFacade.incluir(pessoa);			
			this.usuario = usuario;
			
			//Notifica que o usuario estah cadastrado solicitando-o a abrir seu email para validar o cadastro.
			StringBuffer linkAtivacao = new StringBuffer();
			linkAtivacao.append(FacesUtil.getMessage("RLO041"));
			linkAtivacao.append("<br/><br/>");
			linkAtivacao.append("<a href=");
			linkAtivacao.append(configBean.getConfig().getServerName());
			linkAtivacao.append("/blankapp/pages/realizarLogin/activate.faces?id=");
			linkAtivacao.append(usuario.getId());
			linkAtivacao.append(">");
			linkAtivacao.append(FacesUtil.getMessage("RLO047"));
			linkAtivacao.append("</a>");
			this.enviarEmail(emailVisitante, linkAtivacao.toString());
						
			dialogBean.addActionMessage(FacesUtil.getMessage("RLO033", new String[]{user}),
					"realizarLoginBean.retornarPagHomePage" ,null);
		
		} catch (DaoException e) {
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
			
		} catch (Exception e){
			dialogBean.addMessage(FacesUtil.getMessage("RLO035"), DialogType.ERROR);
		}		
	}
	
	public void validarChecarEmpresas() {
		try {
			if(newPassword == null || newPassword.equals("")){
				dialogBean.addMessage(FacesUtil.getMessage("RLO031"), DialogType.ERROR);
				return;
			}
			
			if(confirmNewPassword == null || confirmNewPassword.equals("")){
				dialogBean.addMessage(FacesUtil.getMessage("RLO046"), DialogType.ERROR);
				return;
			}
			
			empresas = empresaFacade.listar("Empresa.all");
			
			if(empresas.size() > 1) {
				
				//abrir um dlg para que o usuario especifique qual empresa quer se cadastrar.
				RequestContext context = RequestContext.getCurrentInstance();				
				context.execute("PF('dlgFixaEmpresaCadastra').show();");	
				context.update("formFixaEmpresaCadastra");
				
			}else {
				this.cadastrarVisitante(empresas.get(0));
			}
		
		} catch (DaoException e) {			
			e.printStackTrace();
		}
		
	}

	public void ativarVisitante() {						
		try {		
			Long idUsuario = Long.parseLong(FacesUtil.getParam("idUsuario")); //recupera o parametro	
			Usuario usuario = usuarioFacade.recuperar(Usuario.class, idUsuario); //busca o usuario
					
			if(usuario != null) {//Se encontrou o usuario...
				usuario.setBloqueado("F");
				usuario.setPrimeiroAcesso("F"); //Seta o primeiro acesso, para ele nao precisar trocar a senha....
				usuarioFacade.alterar(usuario);		
				
				dialogBean.addActionMessage(FacesUtil.getMessage("RLO051"), 
						"realizarLoginBean.retornarPagLogin", null);				
			}else {
				dialogBean.addMessage(FacesUtil.getMessage("RLO011"), DialogType.ERROR);
			}			
			
		} catch (DaoException e) {			
			e.printStackTrace();
		}		
	}
	
	public void fixarEmpresaCadastrarVisitante(Empresa empresa) {		
		for(Empresa e: empresas) {//localizar a empresa selecionada pelo usuario
			if(empresa.equals(e)) {
				this.cadastrarVisitante(e);
				break;
			}
		}
	}
	
	public String getLimitCharNotBlankSpace() {		
		return RegexUtil.getLimitCharNotBlankSpace(); //Tratamentode strings - limitacoes
	}
	/* *****************************
	 * FIM DO UC CADASTRAR VISITANTE
	 ******************************/
	
	
	/*--------
	* get/set
	----------*/
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public String getConfirmNewPassword() {
		return confirmNewPassword;
	}
	public void setConfirmNewPassword(String confirmNewPassword) {
		this.confirmNewPassword = confirmNewPassword;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public List<Pessoa> getPessoas() {
		return pessoas;
	}
	public void setPessoas(List<Pessoa> pessoas) {
		this.pessoas = pessoas;
	}
	public List<Empresa> getEmpresas() {
		return empresas;
	}
	public void setEmpresas(List<Empresa> empresas) {
		this.empresas = empresas;
	}
	public String getEmailVisitante() {
		return emailVisitante;
	}
	public void setEmailVisitante(String emailVisitante) {
		this.emailVisitante = emailVisitante;
	}
	public String getNomeVisitante() {
		return nomeVisitante;
	}
	public void setNomeVisitante(String nomeVisitante) {
		this.nomeVisitante = nomeVisitante;
	}
	public String getIdentidadeVisitante() {
		return identidadeVisitante;
	}
	public void setIdentidadeVisitante(String identidadeVisitante) {
		this.identidadeVisitante = identidadeVisitante;
	}
	public String getCpfVisitante() {
		return cpfVisitante;
	}
	public void setCpfVisitante(String cpfVisitante) {
		this.cpfVisitante = cpfVisitante;
	}
	public Date getDataNascimentoVisitante() {
		return dataNascimentoVisitante;
	}
	public void setDataNascimentoVisitante(Date dataNascimentoVisitante) {
		this.dataNascimentoVisitante = dataNascimentoVisitante;
	}

}
