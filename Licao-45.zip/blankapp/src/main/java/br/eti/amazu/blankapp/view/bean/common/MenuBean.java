package br.eti.amazu.blankapp.view.bean.common;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.log4j.Level;
import org.primefaces.context.RequestContext;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DefaultSeparator;
import org.primefaces.model.menu.DefaultSubMenu;
import org.primefaces.model.menu.MenuModel;

import br.eti.amazu.blankapp.domain.infra.Funcionalidade;
import br.eti.amazu.blankapp.domain.infra.Menu;
import br.eti.amazu.blankapp.domain.infra.Perfil;
import br.eti.amazu.blankapp.persistence.facade.IAppFacade;
import br.eti.amazu.component.dialog.DialogBean;
import br.eti.amazu.component.dialog.DialogType;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.component.pworld.util.CompoundMenu;
import br.eti.amazu.util.FacesUtil;
import br.eti.amazu.util.log.Log;

@Named
@SessionScoped
public class MenuBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private MenuModel menuModel;
	private List<Menu> listaMenus = new ArrayList<Menu>();	
	List<String> funcionalidades;
	List<Perfil> perfisLogado;	

	@Inject
	ConfigBean configBean;
	
	@Inject
	UserSessionInBean userSessionInBean;
	
	@Inject
	IAppFacade<Menu> menuFacade;
	
	@Inject
	IAppFacade<Funcionalidade> funcionalidadeFacade;
	
	@Inject
	IAppFacade<Perfil> perfilFacade;
	
	@Inject
	DialogBean dialogBean;
	
	List<Class<?>> classBeans;
	
	@PostConstruct
	public void init(){		
		
		classBeans = ConfigBean.getClassBeans();
		
		if(menuModel == null){						
			if(userSessionInBean != null && userSessionInBean.getPessoaLogged()!=null){
				if(listaMenus.isEmpty()){
					this.criarMenu();
					Log.setLogger(MenuBean.class, "Instantiated menus", Level.INFO);
				}
				
			}else{				
				//Nao ha pessoa logada, nao vai ao banco... renderiza apenas menu login
				this.criarMenuNaoLogado();
			}
		}
	}	
	
	public void criarMenuNaoLogado(){		

		boolean criouSubMenuRecursos = false; //para o panelMenu.
		DefaultSubMenu submenuRecursos = null;	
		
		menuModel = new DefaultMenuModel();	//Cria um novo modelo de menu em branco.	
		
		Funcionalidade f1 = new Funcionalidade();
		f1.setLabel("mm_keyLabel_login");
		Menu menu = new Menu();
		menu.setIcon("key.gif");
		menu.setLabel("mm_keyLabel_login");
		menu.setMetodo("#{realizarLoginBean.iniciarRealizarLogin}");
		menu.setTipo("2");
		menu.setOrdem(0);
		menu.setDisabled("F");
		menu.setSelectable("T");
		menu.setVisibility("F");
		listaMenus = new ArrayList<Menu>();
		listaMenus.add(menu);
			
		if(configBean.getConfig().getMenuType().equals("panelMenu")){
			
			/*Para panelMenu, embora os menus sejam raizes, aqui ele nao serah.
			 *Se ainda nao criou o menu "Recursos"...*/
			Menu mnRecursos = null;
			if (!criouSubMenuRecursos) {
				mnRecursos = new Menu();
				mnRecursos.setLabel("mm_keyLabel_recursos");
				mnRecursos.setOrdem(0);
				mnRecursos.setTipo("1");
				mnRecursos.setVisibility("T");
				mnRecursos.setDisabled("F");
				mnRecursos.setSelectable("T");
				submenuRecursos = new DefaultSubMenu();							
				submenuRecursos.setLabel(FacesUtil.getMessage(mnRecursos.getLabel()));							
				criouSubMenuRecursos = true; // o submenu "Recursos".
			}
			
			menu.setMenu(mnRecursos);
			
			//Adciona o menu "recursos" na lista que tem de ser sincronizada.
			listaMenus = rebuildListaMenus(menu);
			
			DefaultMenuItem menuItem = new DefaultMenuItem();
			
			//Seta o label								
			menuItem.setValue(FacesUtil.getMessage(menu.getLabel())); 
			menuItem.setIcon(menu.getIcon().substring(0,menu.getIcon().indexOf("."))); 						
			menuItem.setCommand(getMethod(menu.getMetodo()));
			menuItem.setOnclick("PF('dlgLoader').show()");
			menuItem.setOncomplete("PF('dlgLoader').hide()");
			submenuRecursos.getElements().add(menuItem); 
			menuModel.addElement(submenuRecursos);
			
		}else{			
			//Para outros tipos de menus, adiciona o menu como raiz que ele jah eh.							
			DefaultMenuItem menuItem = new DefaultMenuItem();
			menuItem.setDisabled(menu.getDisabled().equals("T")?true:false);
			menuItem.setValue(FacesUtil.getMessage(menu.getLabel()));
			menuItem.setIcon(menu.getIcon().substring(0,menu.getIcon().indexOf(".")));						
			menuItem.setCommand(getMethod(menu.getMetodo()));	
			menuItem.setOnclick("PF('dlgLoader').show()");
			menuItem.setOncomplete("PF('dlgLoader').hide()");
			menuModel.addElement(menuItem);
		}
	}
			
	/* Dois metodos sao utilizados para criar os menus convenientemente:
	 * criarMenu()
	 * criarSubMenu()
	 * Ambos realizam chamadas recursivas.
	 * Metodo utilizado apenas para usuarios logados*/	
	public void criarMenu() {
		
		funcionalidades = new ArrayList<String>();
		boolean criouSubMenuRecursos = false; //para o panelMenu.
		DefaultSubMenu submenuRecursos = null;
		
		try {			
			/* Inicialmente, popular funcionalidades com as funcionalidades ostensivas.
			 * Aqui, todos os menus publicos sao adicionados na lista para futura comparacao.*/
			List<Funcionalidade> todasFunc = funcionalidadeFacade.listar("Funcionalidade.all");
			
			List<Funcionalidade> funcNaoPublicas = new ArrayList<Funcionalidade>();
			
			for(Funcionalidade f:todasFunc){
				if(f.getVisibility().equals("T")) {					
					if(f.getLabel().contains("/") ) {
						funcionalidades.add(f.getLabel().substring(f.getLabel().lastIndexOf("/")));
						
					}else{
						funcionalidades.add(f.getLabel());
					}
					
				}else{
					funcNaoPublicas.add(f); //as nao publicas entram aqu...
				}				
			}
			
			//remove o menu login (pois aqui jah se encontra logado)
			Iterator<String> it = funcionalidades.iterator();
			while (it.hasNext()){
				String f= it.next();
				if(f.contains("mm_keyLabel_login")){
					it.remove();
				}						
			}
					
			//Recupera os perfis do usuario logado.			
			perfisLogado = userSessionInBean.getPerfisLogado();
						
			/* Perceba que a lista (funcionalidades) jah possui as funcionalidades publicas.
			 * Restando agora, adicionar as funcionalidades privadas (somente as autorizadas constantes
			 * na lista de perfisLogado - se o usuario loga, tem perfil, caso contrario, nao).
			 * Melhor ainda: se perfisLogado eh dif nulo, eh porque tem usuario logado).
			 * Neste caso, colocar na lista de funcionalidades, apenas as funcionalidades
			 * existentes na lista de perfis do usuario que estah logado no momento. 
			 * A ideia eh utilizar essa lista de funcionalidades para comparar com cada menu da
			 * lista de menus, no momento de sua criacao.*/						
			for(Funcionalidade funcNaoPublica : funcNaoPublicas){
				
				//iterando cada label que compoe a funcnionalidade nao publica
				for(String label : funcNaoPublica.getLabel().split("/")){
					
						//se o perfil eh dev, adiciona todas as funcionalidades
						if(containsPerfil("DEV")){
							if(label.length() > 1 && !funcionalidades.contains(label)) funcionalidades.add(label);
						
						}else{
						
							//usuario nao eh o dev - adiciona apenas se ele possui a permissao de acesso
							if(containsFuncionalidade(label)){{
								if(label.length() > 1 && !funcionalidades.contains(label)) funcionalidades.add(label);
							}
						}
					}
				}				
			}	
														
			menuFacade.clear(); //Limpa o entityManager			
			menuModel = new DefaultMenuModel();	//Cria um novo modelo de menu em branco.
					
			// Obtem todos os menus raizes, independentemente se sao publicos ou privados.			
			listaMenus = menuFacade.listar("Menu.rootMenus");
						
			//Percorrendo a lista de menus...
			for (Menu menu : listaMenus) {
				String keyLabel = menu.getLabel();	
				
				/* Aqui compara se o menu estah contido na lista de funcionalidades
				 * (lembrando que esta lista de funcionalidades tambem possui as funcionalidades publicas). 
				 * A logica utilizada eh a seguinte:
				 * Se o usuario nao logou entao a lista de funcionalidades possui apenas as
				 * funcionalidades publicas. Neste caso apenas os menus publicos serao criados.
				 * Se a lista de funcionalidades estiver nula ou vazia, nenhum menu serah criado.*/
				if(!funcionalidades.isEmpty() && (funcionalidades.contains("/"+ keyLabel) ||
						funcionalidades.contains(keyLabel)) ){
												
						//CHECANDO TODOS OS MENUS RAIZES - POIS COMECA TUDO COM ELES.
						//Precisa ver se ele eh do tipo 0(grupo) ou 1(item).
						if(menu.getTipo().equals("1")){							
							/* Aqui o menu eh do tipo 1(Item) (tambem raiz)
							 * Se o menu eh do tipo 1 - agrupa todos no
							 * menu publico raiz "Recursos". Esta eh a regra para utilizacao de
							 * menus em sistemas desktop usando Swing, ou para o panelMenu do primeFaces,
							 * desde que o tipo assinalado em config seja do tipo "panelMenu".*/						
							if(configBean.getConfig().getMenuType().equals("panelMenu")){
								
								/*Para o panelMenu, embora os menus sejam raizes, aqui ele nao serah.
								 *Se ainda nao criou o menu "Recursos"...*/
								Menu mnRecursos = null;
								
								if (!criouSubMenuRecursos) {
									mnRecursos = new Menu();
									mnRecursos.setLabel("mm_keyLabel_recursos");
									mnRecursos.setOrdem(0);
									mnRecursos.setTipo("0");
									mnRecursos.setVisibility("T");
									mnRecursos.setDisabled("F");
									mnRecursos.setSelectable("T");								
									submenuRecursos = new DefaultSubMenu();							
									submenuRecursos.setLabel(FacesUtil.getMessage(mnRecursos.getLabel()));			
									criouSubMenuRecursos = true; // sinaliza que jah criou o submenu "Recursos".
								}							
								menu.setMenu(mnRecursos);
								
								//Adciona o menu "recursos" na lista que tem de ser sincronizada.
								listaMenus = rebuildListaMenus(menu);														
															
								DefaultMenuItem menuItem = new DefaultMenuItem();
								
								//Seta o label								
								if(menu.getLabel() != null) menuItem.setValue(
										FacesUtil.getMessage(menu.getLabel())); 
								
								//Seta o icone
								if(menu.getIcon()!= null)	menuItem.setIcon(menu.getIcon().
										substring(0,menu.getIcon().indexOf("."))); 
								
								menuItem.setCommand(getMethod(menu.getMetodo()));
								menuItem.setOnclick("PF('dlgLoader').show()");
								menuItem.setOncomplete("PF('dlgLoader').hide()");
								
								//adicionando o menuItem no subMenu criado...
								if(menu.getLabel().equals("mm_keyLabel_logout")){
									
									//soh adiciona o menu logout se usuario estiver logado
									if(userSessionInBean.getPerfisLogado() != null ) 
										submenuRecursos.getElements().add(menuItem);
									
								}else{								
									//Adiciona item de menu ao grupo.
									if(!funcionalidades.isEmpty() && funcionalidades.contains(menu.getLabel())) 
										submenuRecursos.getElements().add(menuItem); 												
								}
								menu.setMenu(menu);
								
								//adiciona o subMenu criado no modelo
								if(!menuModel.getElements().contains(submenuRecursos)) 
									menuModel.addElement(submenuRecursos);	
								
							}else{							
								//Para outros tipos de menus, adiciona o menu como raiz que ele jah eh.			
								DefaultMenuItem menuItem = new DefaultMenuItem();
								menuItem.setDisabled(menu.getDisabled().equals("T")?true:false);							
								
								//Seta o label.
								if(menu.getLabel() != null)	menuItem.setValue(FacesUtil.getMessage(menu.getLabel()));
								
								//Seta o icone.
								if(menu.getIcon()!= null) menuItem.setIcon(menu.getIcon().
										substring(0,menu.getIcon().indexOf(".")));	
								
								menuItem.setCommand(getMethod(menu.getMetodo()));
								menuItem.setOnclick("PF('dlgLoader').show()");
								menuItem.setOncomplete("PF('dlgLoader').hide()");
								menuItem.setTitle(menu.getTitle());							
								this.resolveMenuItem(menu, null, menuItem, true);
							}
							
						}else{											
							/* Aqui o menu eh tipo 0(grupo).
							 * Aqui, o menu que nao tem tem pai, nao possui um metodo.
							 * Se ele nao tem metodo, entao ele eh um "grupo de menu" (tipo 0).*/
							DefaultSubMenu submenu = new DefaultSubMenu();
							
							//Seta o label
							if(menu.getLabel() != null) submenu.setLabel(FacesUtil.getMessage(menu.getLabel()));
							
							//Seta o icone
							if(menu.getIcon()!= null) submenu.setIcon(menu.getIcon().
									substring(0,menu.getIcon().indexOf(".")));
							
							//Eh grupo de menus, verifica seus filhos (se tiver)...
							for (Menu mn : menu.getMenus()) {								
												
								if (mn.getMenus() != null && !mn.getMenus().isEmpty()) {
									
									//Tem filhos: Eh grupo de menu. cria um por um, recursivamente.
									DefaultSubMenu subm = new DefaultSubMenu();	
									
									//Seta o label
									if(mn.getLabel() != null) subm.setLabel(
											FacesUtil.getMessage(mn.getLabel()));																	
									
									subm = criarSubmenu(mn); //Recursivamente aqui...								
									if(!funcionalidades.isEmpty() && funcionalidades.contains(mn.getLabel())) {
										submenu.getElements().add(subm);
										
										//verificando se o submenu contem separator
										if(mn.getSeparator().equals("T")) {
											addSeparator(submenu);
										}
									}								
									
								} else {									
									//Nao tem filhos. Eh item de menu, apenas adiciona.
									if(mn.getMetodo() != null){
										DefaultMenuItem menuItem = new DefaultMenuItem();
										menuItem.setDisabled(mn.getDisabled().equals("T")?true:false);
										
										
										//Seta o label
										if(mn.getLabel() != null) menuItem.setValue(
												FacesUtil.getMessage(mn.getLabel())); 
										
										//Seta o icone
										if(mn.getIcon()!= null)	menuItem.setIcon(mn.getIcon().
												substring(0,mn.getIcon().indexOf("."))); 
																			
										menuItem.setCommand(getMethod(mn.getMetodo()));	
										menuItem.setOnclick("PF('dlgLoader').show()");
										menuItem.setOncomplete("PF('dlgLoader').hide()");
										menuItem.setTitle(mn.getTitle());									
										this.resolveMenuItem(menu, submenu, menuItem, false);
									}
								}
							}												
							//Adiciona o submenu no modelo
							if(!funcionalidades.isEmpty() && (funcionalidades.contains(menu.getLabel()))) 
								menuModel.addElement(submenu);						
						}						
					}
				}
						
			} catch (DaoException e) {
				e.printStackTrace();
			}				
		}
				
		private DefaultSubMenu criarSubmenu(Menu menu) throws DaoException {
			/* Adiciona grupos de menus recursivamente.
			 * Se o grupo possuir filhos (itens de menus) eles tambem serao criados.*/		
			DefaultSubMenu submenu = new DefaultSubMenu();
			
			//Seta o label do grupo
			if(menu.getLabel() != null) submenu.setLabel(FacesUtil.getMessage(menu.getLabel()));
			
			//Seta o icone do grupo
			if(menu.getIcon()!= null) submenu.setIcon(menu.getIcon().substring(0,menu.getIcon().indexOf(".")));
			
			//Verifica se o grupo possui filhos adcionando-os recursivamente...
			for (Menu mn : menu.getMenus()) {					
				if(!funcionalidades.isEmpty() && funcionalidades.contains(mn.getLabel())){				
					if (mn.getMenus() != null && !mn.getMenus().isEmpty()) {
						
						//Se nao tem filhos eh grupo. Adiciona esse grupo, recursivamente.					
						submenu.getElements().add(criarSubmenu(mn));
						
						//verificando se o submenu contem separator
						if(mn.getSeparator().equals("T")) addSeparator(submenu);
											
						//------------------------------------------------------------------------------------
						//O dado foi setado diretamente no banco. precisa adicionar isto no modulo manterMenus
						submenu.setRendered(menu.getDisabled().equals("T")?false:true);
		
					} else {
						// Se nao tem filho, eh item. Nao adiciona recursivamente,
						//incorpora o item de menu ao grupo pai.
						DefaultMenuItem menuItem = new DefaultMenuItem();
						menuItem.setDisabled(mn.getDisabled().equals("T")?true:false);
						
						
						
						//Seta o label.
						if(mn.getLabel() != null) menuItem.setValue(FacesUtil.getMessage(mn.getLabel()));
						
						//Seta o icone.
						if(mn.getIcon()!= null) menuItem.setIcon(mn.getIcon().substring(0,mn.getIcon().indexOf(".")));
													
						menuItem.setCommand(getMethod(mn.getMetodo()));	
						menuItem.setOnclick("PF('dlgLoader').show()");
						menuItem.setOncomplete("PF('dlgLoader').hide()");					
						this.resolveMenuItem(mn, submenu, menuItem, false);
					}
				}
			}				
			return submenu;		
		}
		
		void resolveMenuItem(Menu menu, DefaultSubMenu submenu, 
				DefaultMenuItem menuItem, boolean raiz){	
			
			/*Adiciona o item no grupo de menu. Veja que o menu logout 
			 * (se eh que existe um menu logout) soh serah criado se houver um usuario logado. 
			 * Aqui estamos supondo que o menu logout nao eh raiz.*/			
			menuItem.setDisabled(menu.getDisabled().equals("T")?true:false);
					
			if(!raiz){				
				if(menu.getLabel().equals("mm_keyLabel_logout")){
					if(userSessionInBean.getPerfisLogado() != null ) {
						submenu.getElements().add(menuItem);					
					}
					
				}else{ //Adiciona item de menu ao grupo.						
					if(!funcionalidades.isEmpty() && funcionalidades.contains(menu.getLabel())) {							
						submenu.getElements().add(menuItem);
						
						//verificando se o submenu contem separator
						if(menu.getSeparator().equals("T")) {
							addSeparator(submenu);
						}
					}				
				}
				return;			
			}
							
			/* Adiciona o menu no modelo. Veja que o menu logout (se eh que existe um menu logout) 
			 * soh serah criado se houver um usuario logado. Aqui estamos supondo que o
			 * menu logout eh raiz. Se estiver na raiz, nao renderiza o label (apenas o icone)*/
			if(raiz){				
				if(menu.getLabel().equals("mm_keyLabel_logout")){
					menuItem.setValue("");
					menuModel.addElement(menuItem);				
					
				}else{
					if(menu.getLabel().equals("mm_keyLabel_homePage")) {
						menuItem.setValue("");
						menuModel.addElement(menuItem);							
					}else{					
						if(!funcionalidades.isEmpty() && funcionalidades.contains("/" + menu.getLabel())) 
							menuModel.addElement(menuItem);
					}
				}
			}		
		}
		
		void addSeparator(DefaultSubMenu submenu){
			DefaultSeparator def = new DefaultSeparator();
			def.setStyle("margin-left:4px;width:90%;height:1px");
			def.setRendered(true);
			submenu.addElement(def);
		}
				
		public void setMethodNotImplemented(){	
			dialogBean.addMessage(FacesUtil.getMessage("MGL042"), DialogType.INFO_CLOSABLE);
		}
		
		String getMethod(String action){			
			if(action != null) {			
				StringBuffer strClass = new StringBuffer(action.substring(2, 3).toUpperCase());
				strClass.append(action.substring(3, action.indexOf(".")));
				Boolean classExist = false;
				Boolean methodExist = false;
				for(Class<?> clazz:classBeans){
					if(clazz.getName().contains(strClass)){
						classExist = true;
						Method[] methods = clazz.getDeclaredMethods();
						for (int i = 0; i < methods.length; i++) {
							Method m = methods[i];  
							if(action.contains(m.getName())){
								methodExist = true;
								return action;
							}
						}				
					}
				}
				
				if(!classExist){
					Log.setLogger(this.getClass(), "N�o encontrou o bean: " + strClass, Level.WARN);
					return "#{menuBean.setMethodNotImplemented}";
					
				}else{
					if(!methodExist){						
						Log.setLogger(this.getClass(), "Encontrou " + strClass + ", mas n�o encontrou o m�todo: " 
								+ action, Level.WARN);		
						
						return "#{menuBean.setMethodNotImplemented}";
					}
				}
				
			}else{
				Log.setLogger(this.getClass(), "Funcionalidade nao implementada: " + 
						action, Level.WARN);
				
				return "#{menuBean.setMethodNotImplemented}";
			}		
			return null;		
		}
		
		public List<Menu> rebuildListaMenus(Menu menu){
			List<Menu> lista = new ArrayList<Menu>();		
			synchronized (listaMenus){
				lista.add(0, menu);
			}
			return lista;
		}
		
		//Verifica se uma funcionalidade est� contida na lista de funcionalidades do usuario
		boolean containsFuncionalidade(String funcionalidade){			
			if(perfisLogado != null) {
				
				for(Perfil perfil : perfisLogado) {
					for(Funcionalidade f:perfil.getFuncionalidades()){
						if(f.getLabel().contains(funcionalidade)){
							return true;
						}
					}
				}
			}
			return false;
		}
		
		
		
		
		boolean containsPerfil(String codPerfil) {
			if(userSessionInBean.getPerfisLogado() != null) {
				for(Perfil perfil : userSessionInBean.getPerfisLogado()) {
					if(perfil.getCodPerfil().equals(codPerfil)) {
						return true;
					}
				}
			}
			return false;
		}
				
		/*Actions comuns	
		----------------------*/			
		/* Colocar neste espaco, os metodos de alguns menus comuns ao aplicativo, como:
		 * - Acionamento de help;
		 * - Show Case;
		 * - Home Page;
		 * - outros... */
							
		/* ***************************************************
		 * Acionamento de menus comuns a todos os casos de uso
		 ****************************************************/
		@CompoundMenu
		public String iniciarShowCase(){
			FacesUtil.resetBeans(null);
			return "/pages/showcase/homeShowCase?faces-redirect=true";
		}
		
		@CompoundMenu
		public String iniciarHomePage(){
			FacesUtil.resetBeans(null);
			return "/pages/home/homePage?faces-redirect=true";
		}
		
		@CompoundMenu
		public void getHelp(){
			RequestContext context = RequestContext.getCurrentInstance();

			//Precisa desbloquear popups no browser
			context.execute("abrirPopup('"+ configBean.getConfig().getServerName() + 
					"/" + FacesUtil.getContextName() + "/resources/files/help.pdf', 1000, 500);");
		}
		/* ***************************************************/		
		
		/*--------
		 * get/set
		 ---------*/	
		public List<Menu> getListaMenus() {		
			return listaMenus;
		}
		public MenuModel getMenuModel() {
			return menuModel;
		}
		public void setMenuModel(MenuModel menuModel) {
			this.menuModel = menuModel;
		}		
	}

