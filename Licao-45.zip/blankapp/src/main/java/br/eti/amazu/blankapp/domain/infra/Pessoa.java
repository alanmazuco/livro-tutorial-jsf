package br.eti.amazu.blankapp.domain.infra;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;
import javax.persistence.PrimaryKeyJoinColumn;
import org.hibernate.annotations.Cascade;
import br.eti.amazu.component.pworld.domain.AbstractEntity;


@Entity(name = "Pessoa")
@Table(schema = "PWORLD", name = "PESSOA", 
	uniqueConstraints=@UniqueConstraint(name="UK_EMAIL_EMPRESA", columnNames={"EMAIL","ID_EMPRESA"}))

@NamedQueries({
	@NamedQuery(name = "Pessoa.all", query = "select p from Pessoa p order by p.nome"),	
	@NamedQuery(name = "Pessoa.excluirPeloNome",  	query = "delete Pessoa p where p.nome =:param0"),
	
	// LICAO 30 EM DIANTE---------------------------------------------------------------------------------
	@NamedQuery(name = "Pessoa.similarPeloNome", query = "select p from Pessoa p where "+
			"PWORLD.sem_acento(upper(p.nome)) like upper(:param0) order by p.nome"),
	
	@NamedQuery(name = "Pessoa.recuperarPeloNome", 
		query = "select p from Pessoa p where p.nome like :param0"),	
	
	@NamedQuery(name = "Pessoa.allEmp", 
		query = "select p from Pessoa p where p.empresa.id =:param0 order by p.nome"),		
	
	@NamedQuery(name = "Pessoa.excluirPeloNomeEmp", 
		query = "delete Pessoa p where p.nome =:param0 and p.empresa.id =:param1"),
	
	@NamedQuery(name = "Pessoa.similarPeloNomeEmp", query = "select p from Pessoa p where "+
			"PWORLD.sem_acento(upper(p.nome)) like upper(:param0) and p.empresa.id =:param1 order by p.nome"),
	
	@NamedQuery(name = "Pessoa.recuperarPeloNomeEmp", 
		query = "select p from Pessoa p where PWORLD.sem_acento(upper(p.nome)) like upper(:param0) "+
			"and p.empresa.id =:param1"),
	
	@NamedQuery(name = "Pessoa.tudoComFETCH", 
		query = "select p from Pessoa p "+
						"left join fetch p.usuario u "+
						"left join fetch u.perfis pfs "+		
						"left join fetch pfs.funcionalidades funcs "+
						"left join fetch p.dependentes dpnds "+
		                  "where p.id=:param0"),
	
	@NamedQuery(name = "Pessoa.recuperarPeloEmail", query = "select p from Pessoa p where p.email=:param0"),
	
	@NamedQuery(name = "Pessoa.recuperarPeloEmailPelaEmpresa", 
		query = "select p from Pessoa p where p.email =:param0 and p.empresa.id =:param1"),
	
	//LICAO 43 EM DIANTE-----------------------------------------------------------------------------------
	@NamedQuery(name = "Pessoa.allFetch", 
	query = "select p from Pessoa p left join FETCH p.usuario u order by p.nome"),
	
	@NamedQuery(name = "Pessoa.allCount",  query = "select COUNT(*) from Pessoa"),

	@NamedQuery(name = "Pessoa.similarPeloNomeCount",  
		query = "select COUNT(*) from Pessoa p "+
			"where  pworld.sem_acento(upper(p.nome)) like upper(:param0)"),

	@NamedQuery(name = "Pessoa.similarPelaDataNasc", 
		query = "select p from Pessoa p left join FETCH p.usuario u " +
			"where p.dataNascimento =:param0 order by p.nome"),

	@NamedQuery(name = "Pessoa.similarPelaDataNascCount",  
		query = "select COUNT(*) from Pessoa p where p.dataNascimento =:param0"),

})
public class Pessoa extends AbstractEntity<Long> {

	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(schema="PWORLD", allocationSize=1, initialValue=1, name = "PESSOA_SEQ",
										sequenceName = "PESSOA_SEQ")	
	
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "PESSOA_SEQ")
	@Column(name = "ID_PESSOA")	
	private Long id;
	
	@Column(name = "NOME", columnDefinition = "CHARACTER VARYING(70)", nullable=false)
	private String nome;
	

	@Temporal(TemporalType.DATE)
	@Column(name = "DATA_NASCIMENTO", columnDefinition = "DATE", nullable=false)	
	private Date dataNascimento;

	@Column(name="CPF", columnDefinition = "CHAR(14)", nullable=false)
	private String cpf;

	@Column(name = "IDT", columnDefinition = "CHARACTER VARYING(20)", nullable=false)
	private String idt;
	
	@Column(name = "UF", columnDefinition = "CHAR(2)")
	private String uf;
	
	@Column(name = "CIDADE", columnDefinition = "CHARACTER VARYING(70)")
	private String cidade;
	
	@Column(name = "BAIRRO", columnDefinition = "CHARACTER VARYING(70)")
	private String bairro;
	
	@Column(name = "LOGRADOURO", columnDefinition = "CHARACTER VARYING(125)")
	private String logradouro;
	
	@Column(name = "CEP", columnDefinition = "CHAR(9)")
	private String cep;
	
	@Column(name = "NR", columnDefinition = "CHARACTER VARYING(15)")
	private String nr;

	@Column(name = "COMPLEMENTO", columnDefinition = "CHARACTER VARYING(100)")
	private String complemento;

	@Column(name = "FONE", columnDefinition = "CHARACTER VARYING(15)")
	private String fone;

	@Column(name = "CELULAR", columnDefinition = "CHARACTER VARYING(15)")
	private String celular;

	@Column(name = "EMAIL", columnDefinition = "CHARACTER VARYING(40)")
	private String email;

	/* Configuracao especifica para ORACLE
	 * @Column(name="FOTO", columnDefinition = "BLOB") */	
	@Column(name="FOTO", columnDefinition = "BYTEA")
	private byte[] foto;
	
	/* Associacao 1:1 com usuario:
	 * -----------------------------------------------------------------------
	 * 	LEITURA BIDIRECIONAL: 
	 *		pessoa 	| <---------(EAGER)-------> 	|  usuario
	 *------------------------------------------------------------------------
	 *		ESCRITA UNIDIRECINAL:
	 *		pessoa 	|-------------(write)-------->	|  usuario
	 *    (A relacao eh unidirecional porque somente pessoa escreve em usuario)
	 *-----------------------------------------------------------------------*/
	@OneToOne(
		fetch = FetchType.LAZY, optional=true,
		orphanRemoval = true
	)

	@PrimaryKeyJoinColumn()
	@Cascade(org.hibernate.annotations.CascadeType.ALL) 	
	private Usuario usuario;
	
	/* Associacao *:1 com Empresa:
	 * -------------------------------------------------------------
	 * 	LEITURA BIDIRECIONAL: 
	 *      				| ----------(LAZY)-------->	|
	 *		empresa			|                           |  pessoa
	 *   					|< -------(EAGER)--------	|
	 *--------------------------------------------------------------
	 * 	pessoa nao escreve em empresa (sem anotacao de cascade aqui)
	 *------------------------------------------------------------*/
	@ManyToOne(targetEntity = Empresa.class, fetch = FetchType.EAGER)
	@JoinColumn(name="ID_EMPRESA", 
			foreignKey= @ForeignKey(name = "EMPRESA_PESSOA_FK"))
	private Empresa empresa;	
	
	/* Associacao 1:* com dependentes:
	 * --------------------------------------------------------------------------
	 * 	LEITURA BIDIRECIONAL: 
	 *      				| ----------(LAZY)-------->	|
	 *		pessoa 			|                         	|  dependente
	 *   					|< -------(EAGER)--------	|
	 *---------------------------------------------------------------------------
	 *		ESCRITA UNIDIRECINAL:
	 *		pessoa 	|----------(write)-------->	|  dependente
	 *    (A relacao eh unidirecional porque somente pessoa escreve em dependente)
	 *--------------------------------------------------------------------------*/
	@OneToMany(
		fetch = FetchType.LAZY,
		orphanRemoval=true,
		targetEntity=Dependente.class,
		mappedBy="pessoa"		
	)	
	@Cascade (org.hibernate.annotations.CascadeType.ALL)
	private Set<Dependente> dependentes;

	
	@Version
	@Column(name = "VERSAO", columnDefinition = "INTEGER DEFAULT 0")
	private Integer versao;

	
	/*--------
	 * get/set
	 ---------*/
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Date getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getIdt() {
		return idt;
	}
	public void setIdt(String idt) {
		this.idt = idt;
	}
	public String getUf() {
		return uf;
	}
	public void setUf(String uf) {
		this.uf = uf;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public String getNr() {
		return nr;
	}
	public void setNr(String nr) {
		this.nr = nr;
	}
	public String getComplemento() {
		return complemento;
	}
	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}
	public String getFone() {
		return fone;
	}
	public void setFone(String fone) {
		this.fone = fone;
	}
	public String getCelular() {
		return celular;
	}
	public void setCelular(String celular) {
		this.celular = celular;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public byte[] getFoto() {
		return foto;
	}
	public void setFoto(byte[] foto) {
		this.foto = foto;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public Integer getVersao() {
		return versao;
	}
	public void setVersao(Integer versao) {
		this.versao = versao;
	}
	public Empresa getEmpresa() {
		return empresa;
	}
	public void setEmpresa(Empresa empresa) {
		this.empresa = empresa;
	}
	public Set<Dependente> getDependentes() {
		return dependentes;
	}
	public void setDependentes(Set<Dependente> dependentes) {
		this.dependentes = dependentes;
	}

}