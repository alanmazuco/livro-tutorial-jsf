package br.eti.amazu.blankapp.view.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.log4j.Level;
import org.omnifaces.cdi.ViewScoped;
import org.primefaces.context.RequestContext;
import org.primefaces.event.NodeSelectEvent;
import org.primefaces.event.NodeUnselectEvent;
import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.TreeNode;

import br.eti.amazu.blankapp.domain.infra.Funcionalidade;
import br.eti.amazu.blankapp.domain.infra.Menu;
import br.eti.amazu.blankapp.domain.infra.Perfil;
import br.eti.amazu.blankapp.persistence.facade.IAppFacade;
import br.eti.amazu.blankapp.view.bean.common.MenuBean;
import br.eti.amazu.blankapp.view.bean.common.UserSessionInBean;
import br.eti.amazu.component.dialog.DialogBean;
import br.eti.amazu.component.dialog.DialogType;
import br.eti.amazu.component.manterMenus.util.MountFeature;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.component.pworld.util.CompoundMenu;
import br.eti.amazu.util.FacesUtil;
import br.eti.amazu.util.log.Log;

@Named
@ViewScoped
public class ManterPerfisBean implements Serializable{
		
	/* Cada usuario possui um unico perfil, a saber:
	*
	* 1 - DESENVOLVEDOR
	* Este perfil carrega todas as funcionalidades do sistema.
	*
	* 2 - ADMINISTRADOR:
	* Carrega todas as funcionalidades, menos:
	* .ferramentas do desenvolvedor.
	*
	* 3 - OPERADOR MASTER
	* Carrega todas as funcionalidades, menos:
	* . ferramentas do desenvolvedor;
	* . configuracoes do sistema e
	* . criacao de perfis.
	*
	* 4 - OPERADOR SENIOR
	* Carrega todas as funcionalidades, menos:
	* . ferramentas do desenvolvedor;
	* . configuracoes do sistema;
	* . criacao de perfis;
	* . cadastro de usuarios.
	*
	* 5 - VISITANTE
	* Apenas as funcionalidades publicas.
	*
	* Alem desses perfis, podem ser criados outros (com qualquer nome).
	* o administrador poderah cria-los e atribuir as funcionalidades 
	* que desejar ao perfil.
	*
	* Os cinco perfis default nao podem ser alterados em nenhum de 
	* seus atributos, exceto a lista de funcionalidades e a lista de usuarios. 
	* 
	* A lista de usuarios de cada perfil eh atualizada em outro UC: 
	* ===> Manter Recursos Humanos*/
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	DialogBean dialogBean;
	
	@Inject
	UserSessionInBean userSessionInBean;
	
	@Inject
	IAppFacade<Perfil> perfilFacade;
	
	@Inject
	IAppFacade<Funcionalidade> funcionalidadeFacade;
	
	@Inject
	MenuBean menuBean;
	
	private String renderIndexPanel = "0"; //Renderizacoes dos paineis em perfil.xhtml.
	private Perfil perfil;
	private List<Perfil> perfis;
	
	private TreeNode root;
	private TreeNode node[];	
	List<Funcionalidade> funcionalidadesSelecionadas;	
	List<Menu> menus = new ArrayList<Menu>();
	
	@CompoundMenu
	public void iniciarManterPerfis(){
		FacesUtil.resetBeans(null);		
		FacesUtil.redirect("/pages/adm/manterPerfis/perfis");
	}
			
	public void novoPerfil(){
		
		renderIndexPanel = "0";
		perfil = new Perfil();	
		this.openDlgPerfil(perfil);		
	}
	
	public void editarPerfil(Perfil perfil){	
		
		renderIndexPanel = "0";	
		
		funcionalidadesSelecionadas = 
				perfil.getFuncionalidades().stream().collect(Collectors.toList());
		
		this.openDlgPerfil(perfil);	
		
	}
	
	public void cancelar(){
		this.closeDlgPerfil();
	}
		
	public void closeDlgPerfil(){		
		RequestContext request = RequestContext.getCurrentInstance();		
		request.execute("PF('dlgPerfil').hide()");
	}
	
	private void openDlgPerfil(Perfil perfil){	
		
		this.perfil = perfil;
		
		//Abre o dialog de inclusao/alteracao de novo perfil.
		RequestContext request = RequestContext.getCurrentInstance();
		request.update("formPerfil");
		request.execute("PF('dlgPerfil').show()");
		
	}
		
	/* Avanca ou retrocede paineis de perfil.xhtml. Contendo varias customizacoes 
	 * de validacao e recuperacao de dados. */
	public void goStep() {	
		
		try {		
			
			if(renderIndexPanel.equals("1")){
				
				//Limpa o entityManager, a fim de evitar gravacao indevida.			
				perfilFacade.clear();
				
				/* Converte o nome do perfil para letras maiusculas.	*/
				perfil.setNome(perfil.getNome().toUpperCase());
					
				/*  - Se estah alterando um perfil, verfica se jah nao existe um perfil com o mesmo
				 *   nome jah registrado no banco de dados.*/	
				List<Object> params = new ArrayList<Object>();
				params.clear();
				params.add(perfil.getNome());
								
				this.initTree();
				
				//Obtem todas as funcionalidades que o perfil tem acesso.
				List<Funcionalidade> funcionalidadesSelecionadas = new ArrayList<Funcionalidade>();
				
				if(perfil.getId()!= null){	
					
					funcionalidadesSelecionadas = perfilFacade.recuperar(
							Perfil.class, perfil.getId()).getFuncionalidades().stream().collect(Collectors.toList());
				}
				
				this.funcionalidadesSelecionadas = funcionalidadesSelecionadas;
			}
						
		} catch (DaoException e) {
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
		}
		
    }	
		
	public void initTree(){
		
		Perfil p = new Perfil();
		
		if(perfil.getId() != null){			
			List<Object> params = new ArrayList<Object>();
			params.add(perfil.getCodPerfil());
			
			try {
				p = perfilFacade.recuperar("Perfil.peloCod", params);
				p.setNome(perfil.getNome());
				p.setUsuarios(perfil.getUsuarios());
				p.setCaracteristicas(perfil.getCaracteristicas());
				
			} catch (DaoException e) {
				e.printStackTrace();
			}
			
			funcionalidadesSelecionadas = p.getFuncionalidades().stream().collect(Collectors.toList());
			
		}else{
			funcionalidadesSelecionadas = new ArrayList<Funcionalidade>();
			p.setCodPerfil(perfil.getCodPerfil());
			p.setNome(perfil.getNome());
			p.setUsuarios(perfil.getUsuarios());
			p.setCaracteristicas(perfil.getCaracteristicas());
			p.setFuncionalidades(p.getFuncionalidades());
		}
		
		root = new DefaultTreeNode("Root", null);			
				
		menus = menuBean.getListaMenus();
			
		int i = 0;
		node = new DefaultTreeNode[menus.size()];
		
		for(Menu menu:menus){	
			
			if(menu.getVisibility().equals("F") && !menu.getLabel().contains("help") ){	
				
				node[i] = new DefaultTreeNode(menu, root);											
				
				if(menu.getTipo().equals("0")){
					
					node[i].setSelected(containsFuncionalidade(
							funcionalidadesSelecionadas,menu.getLabel())?true:false);
					
					node[i].setSelectable(false);
					
				}else{
					node[i].setSelected(containsFuncionalidade(
							funcionalidadesSelecionadas,menu.getLabel())?true:false);
					
					
					node[i].setSelectable(desabilite(p, menu.getLabel()));
				}	
				
				//Se o usuario logado nao possuir perfil de desenvolvedor, remove o menu ferramentas
				if(!containsPerfil(userSessionInBean.getPerfisLogado(), 1L)) {	
					
					Iterator<Menu> it = menu.getMenus().iterator();
					while (it.hasNext()){
						Menu m = it.next();
						if(m.getLabel().contains("ferramentas")) it.remove();
					}
					
				}	
				
				criarSubTree(menu, node[i], p);
			}	
			
			i++;		
			
		}
		
		perfil = p;				
		Log.setLogger(ManterPerfisBean.class, "Crou Tree....", Level.INFO);
	}
	
	boolean containsPerfil(List<Perfil> perfis, Long idPerfil) {
		
		for(Perfil perfil:perfis) {
			if(perfil.getId() == idPerfil) { //o id do perfil dev eh sempre 1.
				return true;
			}
		}
		
		return false;		
	}
		
	private void criarSubTree(Menu menu, TreeNode n, Perfil pf) {
		
		/* Adiciona grupos de menus recursivamente.
		 * Se o grupo possuir filhos (itens de menus) eles tambem serao criados.*/	
				
		if(menu.getMenus().size()>0){
			
			TreeNode nod[] = new DefaultTreeNode[menu.getMenus().size()];
			int i = 0;		
		
			for(Menu m:menu.getMenus()){				
				//evitando um loop infinito...
				if(m.equals(menu) ){
					i++;
					continue;
				}
				
				if(m.getVisibility().equals("F")){														
					nod[i] = new DefaultTreeNode(m, n);		
					
					if(m.getTipo().equals("0")){						
						nod[i].setSelected(containsFuncionalidade(
								funcionalidadesSelecionadas,m.getLabel())?true:false);
			
						
						nod[i].setSelectable(false);
						
					}else{
						
						nod[i].setSelected(containsFuncionalidade(
								funcionalidadesSelecionadas,m.getLabel())?true:false);
						
						nod[i].setSelectable(desabilite(pf, m.getLabel()));
					}
					
					criarSubTree(m,nod[i], pf );
				}
				
				i++;
				
			}
		}			
	}
		
	//saber se uma determinada funcionalidade estah contida na lista de menus
	boolean containsFuncionalidade(List<Funcionalidade> lista, String f){
		
		//pega a funcionalidade (string apos a ultima barra)...
		int pos = 0;
		
		if(f.contains("/")) pos = f.lastIndexOf("/")+1;	
		
		String func = f.substring(pos);
		
		for(Funcionalidade m:lista){
			
			int pos1 = 0;
			
			if(m.getLabel().contains("/")) pos1 = m.getLabel().lastIndexOf("/")+1;
			
			String func1 = m.getLabel().substring(pos1);
			
			if(func1.equals(func)){
				return true; 
			}
		}
		
		return false;
	}
		
	boolean desabilite(Perfil perfil, String label){
						
		//Travando a funcionalidade ManterPerfis (Nem o adm terah acesso)
		if(label.equals("mm_keyLabel_manterPerfis"))  return false;
		
		//PODERIA HAVER OUTRAS DESABILITACOES DAQUI PARA BAIXO...
		return true;
	}
		
	public void onNodeSelect(NodeSelectEvent event) {		
		if(perfil.getFuncionalidades() != null && perfil.getFuncionalidades().size() > 0) {
			
			funcionalidadesSelecionadas = 
					perfil.getFuncionalidades().stream().collect(Collectors.toList());		
		}	
		
		
		funcionalidadesSelecionadas.add(
				recupereFuncionalidade((Menu) event.getTreeNode().getData()));		
	}	
	
	public void onNodeUnselect(NodeUnselectEvent event) {
		
		if(perfil.getFuncionalidades() != null && perfil.getFuncionalidades().size() > 0) {
			
			funcionalidadesSelecionadas = 
					perfil.getFuncionalidades().stream().collect(Collectors.toList());
		}	
		
		funcionalidadesSelecionadas.remove(recupereFuncionalidade((Menu) 
				event.getTreeNode().getData()));
		
	}
	
	
	Funcionalidade recupereFuncionalidade(Menu menu){
		
		try {
			List<Object> params = new ArrayList<Object>();
			params.clear();
			params.add(new MountFeature().storeMenu(menu));		
			return funcionalidadeFacade.recuperar("Funcionalidade.nomeFuncionalidade", params);
			
		} catch (DaoException e) {			
			e.printStackTrace();
		}
		
		return null;		
	}
		
	public void salvarPerfil(){		
		try{			
			if(perfil.getId() == null){					
				/* Conforme a regra do relacionamento *:*, voce nao pode incluir uma
				 * entidade de um dos lados, referenciando o outro lado.
				 * Primeiro, inclua o Perfil (insert);
				 * Em seguida, associe o perfil com a lista de funcionalidades;
				 * Finalmente, salve o perfil com a lista setada (update). */
				
				//Primeiro, inclui perfil (funcionalidades nulas).
				perfil.setFuncionalidades(null);
				perfilFacade.incluir(perfil);
				
				// Em seguida, associe o perfil com as funcionalidades definidas na xhtml.
				perfil.setFuncionalidades(funcionalidadesSelecionadas.stream().collect(Collectors.toSet()));
				
				// Finalmente, salve o perfil com a lista setada (update com flush e refresh).
				perfil = (Perfil) perfilFacade.alterarAtualizar(perfil);
				
				//adiciona o perfil na lista de perfis (atualizando a view)
				perfis.add(perfil);				
		
			}else{				
				//Seta as funcionalidades selecionadas e realiza o update em perfil.
				perfil.setFuncionalidades(funcionalidadesSelecionadas.
						stream().collect(Collectors.toSet()));			
				
				


				perfilFacade.alterar(perfil);				
			}

			dialogBean.addActionMessage(
					FacesUtil.getMessage("MGL034"), "manterPerfisBean.closeDlgPerfil", "formPerfis:tablePerfis");
			
		} catch (DaoException e) {
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
		}		
	}

	public void listarPerfis(){
		
		try {
			perfis = perfilFacade.listar("Perfil.all");

			//se o usuario logado nao possuir o perfil dev, nao mostra o perfil de desenvolvedor.
			if(!containsPerfil(userSessionInBean.getPerfisLogado(), 1L)) {	//id do perfil dev eh sempre 1
				
				Iterator<Perfil> it = perfis.iterator();
				
				while (it.hasNext()){
					Perfil p = it.next();
					if(p.getId() == 1){
						it.remove();						
					}
				}
			}
			
		} catch (DaoException e) {
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
		}		
	}

	public void confirmarExcluirPerfil (Perfil perfil){
		
		this.perfil = perfil;
		
		dialogBean.addConfirmMessage(
			FacesUtil.getMessage("MGL038",new String[]{perfil.getNome()}), //....message
			"manterPerfisBean.excluirPerfil",     //.............................actionButtonYes
			null,  //............................................................actionButtonNo				
			null); //............................................................update
	}

	public void excluirPerfil(){	
		
		try {	
			
			/* seta funcionalidades e usuarios para null, para nao haver exclusao em cascata.
			 * Soh haverah a exclusao na tabela perfil e na tabela perfil_funcionalidade. */
			perfil.setFuncionalidades(null);	
			perfil.setUsuarios(null);
			perfilFacade.excluir(perfil);
			perfis.remove(perfil);				
			RequestContext request = RequestContext.getCurrentInstance();					
			request.update("formPerfis:tablePerfis");
			
		} catch (DaoException e) {			
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);			
		}		
	}
		
	/*---------------------------------------------------------------------
	 * Traduz cada funcionalidade a partir do seu label,
	 * recuperando algo como: '/Administracao/Ferramentas/Show Case'.
	 * O ultimo elemento (no exemlo acima eh Show Case), aparecerah na
	 * view em destaque, mas o componente a ser utilizado
	 * deve ter sua propriedade "escape" setada para "false"
	 ----------------------------------------------------------------------*/
	public String getFuncionalidadeTraduzida(String label){		
		
		String sp[] = label.split("/");
		
		StringBuffer buffer = new StringBuffer();
		int i = 0;
		
		for(String str:sp){
			
			buffer.append("/");
			if(sp!=null && sp.length>1){
				if(i == sp.length-1){
					buffer.append("<span style=\"background:#f0ff00;color:black;\">");
					buffer.append(FacesUtil.getMessage(str));
					buffer.append("</span>");
					
				}else{
					buffer.append(FacesUtil.getMessage(str));
				}
			}
			
			i++;
			
		}	
		
		return buffer.toString().replace("/: invalid key", "");		
	}
	
	
	/*--------------
	 * get/set
	 --------------*/	
	public List<Perfil> getPerfis() {
		if(perfis == null) {
			this.listarPerfis();			
		}		
		return perfis;
	}
	
	////outros get-set.......
	
	public IAppFacade<Perfil> getPerfilFacade() {
		return perfilFacade;
	}
	public void setPerfilFacade(IAppFacade<Perfil> perfilFacade) {
		this.perfilFacade = perfilFacade;
	}
	public String getRenderIndexPanel() {
		return renderIndexPanel;
	}
	public void setRenderIndexPanel(String renderIndexPanel) {
		this.renderIndexPanel = renderIndexPanel;
	}
	public Perfil getPerfil() {
		return perfil;
	}
	public void setPerfil(Perfil perfil) {
		this.perfil = perfil;
	}
	public TreeNode getRoot() {
		return root;
	}
	public void setRoot(TreeNode root) {
		this.root = root;
	}
	public TreeNode[] getNode() {
		return node;
	}
	public void setNode(TreeNode[] node) {
		this.node = node;
	}
	public List<Menu> getMenus() {
		return menus;
	}		
}	
