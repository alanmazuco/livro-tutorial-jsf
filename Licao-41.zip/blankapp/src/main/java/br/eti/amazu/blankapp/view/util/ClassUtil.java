package br.eti.amazu.blankapp.view.util;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.log4j.Level;

import br.eti.amazu.blankapp.view.vo.Icon;
import br.eti.amazu.component.pworld.util.CompoundMenu;
import br.eti.amazu.util.log.Log;

public class ClassUtil {		
	
	static List<String> listaMetodos; //disponibiliza uma lista de metodos	
	
	/* Retorna os nomes dos metodos que compoem os itens de menu
	 -------------------------------------------------------------------*/
	public static List<String> getMethodNameMakeMenu(List<Class<?>> classes) {		
		List<String> makeMenus = new ArrayList<String>();
		for (Class<?> c : classes) {			
			for (Method m : c.getDeclaredMethods()){
				if(m.isAnnotationPresent(CompoundMenu.class)){
					StringBuffer b = new StringBuffer("#{");
					
					b.append(  c.getName().substring(c.getName().lastIndexOf(".")+1,
							c.getName().lastIndexOf(".")+2).toLowerCase()  );
					
					b.append(  c.getName().substring(c.getName().lastIndexOf(".")+2)  );
					b.append(".");
					b.append(m.getName());
					b.append("}");
					makeMenus.add(b.toString());
				}
			}		
		}
		
		Collections.sort(makeMenus);
		return makeMenus;		
	}

	
	/* Retorna as referencias aos �cones existentes no arquivo de biblioteca icons.jar. 
	 --------------------------------------------------------------------------------*/
    public static List<Icon> getIconsInFrameworkJar(String path){			
    	List<Icon> listaIcons = new ArrayList<Icon>();		    	
    
    	try {	    	
    		ZipFile zipFile;
 			zipFile = new ZipFile(path); 					
			Enumeration<? extends ZipEntry> entries = zipFile.entries();
	     	        
	        while (entries.hasMoreElements()) {
	            ZipEntry zipEntry = entries.nextElement();
	            String name = zipEntry.getName();
	            if(!zipEntry.isDirectory() && name.contains("images/buttons/") 
	            		&& !name.contains("Thumbs.db")){
	            	String strIcon = name.replace("META-INF/resources/images/buttons/", "");
	            	String iconName = strIcon.substring(0,strIcon.indexOf("."));	            	
	            	Icon icon = new Icon();
	            	icon.setIcon(strIcon);
	            	icon.setIconName(iconName);	            	
	            	listaIcons.add(icon);
	            }
	        }
	        zipFile.close();
		
		} catch (IOException e) {
			e.printStackTrace();				
		} catch (SecurityException e) {
			e.printStackTrace();					
		} catch (IllegalArgumentException e) {
			e.printStackTrace();			
		}
		return listaIcons;
	}
    
    /* Retorna uma string com o nome do pacote recebido como parametro.
	 ----------------------------------------------------------------*/
    public static String getBeansPackage(Package pacote){
		if(!pacote.getName().contains("bean")){
			Log.setLogger(ClassUtil.class, 
				"Para obter o nome completo do pacote que cont�m os beans do aplicativo, "+
					"a classe chamadora tem de estar enquadrada sob um pacote \"*.view.bean.*\", "+
						"obrigatoriamente", 	Level.ERROR);
			return null;
		}
		return pacote.getName().substring(0, pacote.getName().lastIndexOf(".bean") + 5);
	}
    
     /* Recupera todas as classes de um diretorio, recursivamente.
	 -----------------------------------------------------------*/
    public static List<Class<?>> findClasses(File directory, String packageName)
    		throws ClassNotFoundException {

		List<Class<?>> classes = new ArrayList<Class<?>>();		
        if (!directory.exists())  return classes;        
        File[] files = directory.listFiles();
        for (File file : files) {
            if (file.isDirectory()) {
                assert !file.getName().contains(".");
                classes.addAll(findClasses(file, packageName + "." + file.getName()));
                
            } else {
                classes.add(Class.forName(packageName + '.' +
                		file.getName().substring(0, file.getName().length() - 6)));
            }
        }
        return classes;
    }        
}

