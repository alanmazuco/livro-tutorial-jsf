package br.eti.amazu.blankapp.persistence;

public enum SqlRepository {
	
	//UC - Realizar Login=================================================
	RECUPERAR_PESSOA_PELO_NOME_DATA_NASC(recuperaPessoaPorNomeDataNasc()),
	//====================================================================
	
	//UC - Recursos Humanos=============================================
	RECUPERAR_QUANTIDADE_USUARIOS_DEV (recuperaQuantUsuarioDev())
	//==================================================================	
	;
	
	private String sql;
	
	//Construtor
	SqlRepository(String sql) {
		this.sql = sql;
	}
	
	static String recuperaPessoaPorNomeDataNasc() {
		StringBuffer buff = new StringBuffer();
		buff.append("SELECT * FROM PWORLD.PESSOA WHERE UPPER(NOME) = UPPER(:param0) ");
		buff.append("AND DATA_NASCIMENTO =:param1 AND EMAIL =:param2");
		return buff.toString();
	}
	
	static String recuperaQuantUsuarioDev() {
		StringBuffer buff = new StringBuffer();
		buff.append("SELECT COUNT(*) FROM PWORLD.USUARIO_PERFIL WHERE ID_PERFIL = 1");		
		return buff.toString();
	}
	
	/*--------
	 * get/set
	 ---------*/
	public String getSql() {		
		return sql;
	}	
}
