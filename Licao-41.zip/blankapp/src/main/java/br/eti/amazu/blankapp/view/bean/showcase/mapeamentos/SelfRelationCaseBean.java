package br.eti.amazu.blankapp.view.bean.showcase.mapeamentos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.apache.log4j.Level;

import br.eti.amazu.blankapp.domain.infra.Menu;
import br.eti.amazu.blankapp.persistence.facade.IAppFacade;
import br.eti.amazu.blankapp.view.util.FormatTest;
import br.eti.amazu.component.dialog.DialogBean;
import br.eti.amazu.component.dialog.DialogType;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.util.FacesUtil;
import br.eti.amazu.util.log.Ansi;
import br.eti.amazu.util.log.Log;

@Named
@RequestScoped
public class SelfRelationCaseBean  implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Inject
	IAppFacade<Menu> menuFacade;
	
	@Inject
	DialogBean dialogBean;

	/* ----------------------------------------
	 *  EXPERIMENTO 01 - Subindo o Aplicativo
	 ----------------------------------------*/
	//Apenas colocando o servidor para rodar...
	
	/* -------------------------------
	 *  EXPERIMENTO 02 - Incluir Menus
	 -------------------------------*/
	public void incluirMenus(){	

		/* Instancia e inclui cada menu (inclui ou avisa que jah foi incluido).
		 * Cada menu leva consigo quatro parametros: o label, o menuPai, o tipo e o nr ordem.
		 * 
		 *  A IDEIA EH MONTAR O MENU ABAIXO:
		 *  
		 * Administracao
					|					
					|--- Manter Menus
                    |--- Ferramentas
					|   		|---Showcase		
					| 		
					'--- Recursos Humanos
								|--- Cadastro de Pessoal
								|--- Cadastro de Usuarios
								'--- Manter Perfis
			Download
			Home Page
			Login
			Logout
		 */	
		//Montando o cabecalho do log
		FormatTest.printHeader("SELF RELATION", "Experimento 02 - Incluir Menus");
		
		Menu menuAdm = null;
		Menu menuFerram = null;
		Menu menuRecHumanos = null;
		
		for(int i=0; i<=11; i++){
			
			if( i==0 ) menuAdm	= this.instancieMenus("Administra��o", null, "0",  0);
					
					if( i==1 ) menuFerram = this.instancieMenus("Ferramentas", menuAdm, "0", 1);	
							if( i==2 ) this.instancieMenus("Manter Menus", menuFerram, "1", 0);
							if( i==3 ) this.instancieMenus("Showcase", menuFerram, "1", 1);
					
					if( i==4 ) menuRecHumanos = this.instancieMenus("Recursos Humanos", menuAdm, "0", 2);	
							if( i==5 ) this.instancieMenus("Cadastro de Pessoal", menuRecHumanos, "1", 0);
							if( i==6 ) this.instancieMenus("Cadastro de Usu�rios", menuRecHumanos, "1", 1);
							if( i==7 ) this.instancieMenus("Manter Perfis", menuRecHumanos, "1", 2);
							
			if( i==8 ) this.instancieMenus("Download", null, "1", 1);
			if( i==9 ) this.instancieMenus("Home Page", null, "1", 2);
			if( i==10 ) this.instancieMenus("Login", null, "1", 3);
			if(i==11) this.instancieMenus("Logout", null, "1", 4);
		}		
		
		dialogBean.addMessage(FacesUtil.getMessage("MGL025"), DialogType.INFO_CLOSABLE);
		
		//Montando o rodapeh do experimento.
		FormatTest.printFooter(); 
	}
	
	/* ---------------------------------------------------
	 *  EXPERIMENTO 03 - Demonstrando uma ViewDaoException
	 ---------------------------------------------------*/
	public void demonstrarDaoException(){
			
		//Montando o cabecalho do log
		FormatTest.printHeader("SELF RELATION", "Experimento 03 - Demonstrando uma DaoException");
					
		// Instancia um menu com label muito grande, superior ao tamanho definido para o campo.
		this.instancieMenus("Administra��iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii", null,"0",  0);
		
		//Montando o rodapeh do experimento.
		FormatTest.printFooter(); 
	}

	/* -------------------------------------------
	 *  EXPERIMENTO 04 - Demonstrando uma Rollback
	 --------------------------------------------*/
	public void demonstrarRollback(){
		
		try{	
			FormatTest.printHeader("SELF RELATION", "Experimento 04 - Demonstrando uma Rollback");	
			menuFacade.demonstrarRollBack();				
			FormatTest.printFooter(); 
			
		}catch(DaoException e){
			e.printStackTrace();
		}		
	}
	
	/* ---------------------------------
	 *  EXPERIMENTO 05 - Montando o Menu
	 ----------------------------------*/
	/* Este experimento realiza uma consulta na tabela Menu e monta os menus como estao
	* atualmente. Desligue o log do SQL (agindo no arquivo persistence,xml).	*/	
	String indentStr = "                                                       ";
	int level = 1;
	int it = 0;
	public void montarMenu(){
			
		try{	
			FormatTest.printHeader("SELF RELATION", "Experimento 05 - Montando o menu");				
			List<Menu> menus = 	menuFacade.listar("Menu.rootMenus");
			
			if (menus.isEmpty()) {
				System.out.println("A tabela nao possui registros.");
				dialogBean.addMessage(FacesUtil.getMessage("MGL076"), DialogType.INFO_CLOSABLE);	
				FormatTest.printFooter(); 
				return;
				
			} else {
				for (Menu menu : menus) {
					level++;
					Log.setLogger("",indentar(menu, level) +menu.getLabel(), Level.INFO, Ansi.BLUE);
					
					if (menu.getMenus() != null && !menu.getMenus().isEmpty()) {				
						for (Menu subMenu : menu.getMenus()) {
							Log.setLogger("",indentar(subMenu, level) + subMenu.getLabel(), Level.INFO, Ansi.BLUE);
							printarSubMenu(subMenu);
						}
					}
				}
			}			
			dialogBean.addMessage(FacesUtil.getMessage("MGL025"), DialogType.INFO_CLOSABLE);
			FormatTest.printFooter(); 	
			
		}catch(DaoException e){
			e.printStackTrace();
		}		
	}

	String indentar(Menu menu, int level) {
		if (menu.getMenu() == null) level = 0;
		return  indentStr.substring(0, level * 3);
	}

	private void printarSubMenu(Menu subMenu) {
		if (subMenu.getMenus() != null && !subMenu.getMenus().isEmpty()) {
			level++;
			level++;
			int a = 1;
			for (Menu mnu : subMenu.getMenus()) {
				Log.setLogger("", indentar(subMenu, level) + mnu.getLabel(), Level.INFO, Ansi.BLUE);
				printarSubMenu(mnu);
				if (a == subMenu.getMenus().size()) {
					level--;
					level--;
				}
				a++;
			}
		}
	}
	
	

	/* -----------------------
	 *  APOIO AOS EXPERIMENTOS
	 ------------------------*/
	Menu  instancieMenus(String label, Menu menuPai, String tipo, Integer nrOrdem){

		Menu menu = new Menu(label); //instancio o menu (estado new).
		menu.setMenu(menuPai); //setando o pai do menu Administracao (como eh raiz, o pai eh nulo).
		
		//Verificando se jah existe o menu. Se nao existe inclui, se jah existia, loga.
		if(existMenu(menu.getLabel())){
			this.printExistMenu(menu);		
			
		}else{	
			menu.setTipo(tipo); //setando o tipo do menu (grupo ou item).
			menu.setOrdem(nrOrdem); //setando o nr ordem do menu.
			menu = this.incluaMenu(menu); //inclui o menu - e realiza logs.
		}		
		return menu; //...e retorna o menu perfeitamente sincronizado com o banco de dados.
	}	
	
	boolean existMenu(String label){
		
		//Busca o menu no banco de dados...
		try{
			List<Object> params = new ArrayList<Object>();		
			params.add(label);
			return menuFacade.recuperar("Menu.singleMenu", params) != null ; //retorna true se achou..
			
		}catch(DaoException e){
			e.printStackTrace();
		}
		
		return false; //retorna false se nao achou.
	}
	
	void printExistMenu(Menu menu){		
		Log.setLogger("", "J� existia um menu com o label "+ menu.getLabel(), Level.INFO, Ansi.BLUE);
	}
	
	Menu  incluaMenu(Menu menu){
		
		try{
		
			//setando todos os outros atributos requeridos (eh um teste...).
			menu.setVisibility("F"); // O menu nao serah visivel a todos.
			menu.setDisabled("T"); // O menu  serah habilitado.
			menu.setSelectable("T"); //O menu serah selecionavel.
			menu.setSeparator("F"); //O menu nao terah separador.
			
			// O icone que serah renderizado no menu - igual para todos (eh um teste...).
			menu.setIcon("edit_pen.gif"); 	
			
			//Aqui inclui o menu e realiza log.
			menuFacade.incluir(menu);						
			Log.setLogger("", "Incluiu o menu: " + menu.getLabel(), Level.INFO, Ansi.BLUE);
						
			return menu; //...e retorna o menu perfeitamente sincronizado com o banco de dados.
		
		}catch(DaoException e){
			e.printStackTrace();
		}
		
		return null; 
	}
	
}
