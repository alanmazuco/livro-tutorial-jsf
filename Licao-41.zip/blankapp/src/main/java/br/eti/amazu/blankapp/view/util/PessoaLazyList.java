package br.eti.amazu.blankapp.view.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

import br.eti.amazu.blankapp.domain.infra.Perfil;
import br.eti.amazu.blankapp.domain.infra.Pessoa;
import br.eti.amazu.blankapp.persistence.facade.IAppFacade;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.util.DateUtil;

public class PessoaLazyList extends LazyDataModel<Pessoa> {

	private static final long serialVersionUID = 1L;	
	IAppFacade<Pessoa> pessoaFacade;
	boolean devLogado;
	String modoPesquisa;
	String paramPesquisa;		
	private List<Pessoa> pessoas;
	
	public PessoaLazyList(){
		pessoas = new ArrayList<Pessoa>();
	}
	
	public PessoaLazyList (IAppFacade<Pessoa> pessoaFacade, boolean devLogado, 
			String modoPesquisa, String paramPesquisa){			
		this.pessoaFacade = pessoaFacade;		
		this.devLogado = devLogado;
		this.modoPesquisa = modoPesquisa;	
		this.paramPesquisa = paramPesquisa;				
	}
		    
	@Override
	public List<Pessoa> load(int startingAt, int maxPerPage, String sortField, 
			SortOrder sortOrder, Map<String, Object> filters) {				     
		String namedQuery = null;
		String namedQueryTotal = null;		
	    try{
	    	List<Object> params = new ArrayList<Object>();		    					
	    	
	    	//Definindo o tipo de consulta, baseado nos parametrod de recursosHumanosBean.
	    	if(modoPesquisa.equals("listarTodos")){
	    		params.clear();
	    		namedQuery = "Pessoa.allFetch";
			  	namedQueryTotal = "Pessoa.allCount";		
	    	}	    	
	    	if(modoPesquisa.equals("nome")){
	    		params.clear();
	    		params.add("%" + paramPesquisa + "%");
	    		namedQuery = "Pessoa.similarPeloNome";
			  	namedQueryTotal = "Pessoa.similarPeloNomeCount";
	    	}	    
	    	if(modoPesquisa.equals("dataNasc")){	    		    	
	    		params.clear();
	    		params.add(DateUtil.getDate(paramPesquisa));
	    		namedQuery = "Pessoa.similarPelaDataNasc";
			  	namedQueryTotal = "Pessoa.similarPelaDataNascCount";
	    	}	    		    			    		
		  	pessoas = pessoaFacade.listartPaginado(namedQuery, params, startingAt, maxPerPage);		        		        
		  	setPageSize(maxPerPage);
		  	
		  	/* Ao retornar pessoas, retirar as pessoas que sao desenvolvedoras, 
		  	 * mas isto, somente se a lista de perfis do logado nao contiver esse perfil de dev.*/
		  	if(!devLogado){ //a lista perfisLogado nao contem um dev (o usuario nao eh um desenvolvedor?)
		  		
		  		//se o usuario logado nao eh um desenvolvedor, ele nao enxerga os desenvolvedores do sistema.
		  		Iterator<Pessoa> it = pessoas.iterator();
		  		while (it.hasNext()){
		  			Pessoa pessoa = it.next();
		  			if( pessoa.getUsuario() != null && containsPerfil(pessoa.getUsuario().getPerfis(), 1L) ) {
		  				it.remove();			  				
		  			}
		  		}	  		
		  		if (getRowCount() <= 0) setRowCount(pessoaFacade.recuperarMaxResult(namedQueryTotal, params) - 1);
		  	}else{		  		
		  		if (getRowCount() <= 0) setRowCount(pessoaFacade.recuperarMaxResult(namedQueryTotal, params));
		  	}		  			  			  	
		  	return pessoas; 
	        
	    }catch(DaoException e){
	    	e.printStackTrace();
	    }	    
	    return null;
	}
	
	boolean containsPerfil(Set<Perfil> perfis, Long idPerfil) {		
		for(Perfil perfil:perfis) {
			if(perfil.getId() == idPerfil) { //o id do perfil dev eh sempre 1.
				return true;
			}
		}		
		return false;		
	}
	
    @Override
    public Object getRowKey(Pessoa pessoa) {
        return pessoa.getId();
    }
    
    @Override
    public Pessoa getRowData(String pessoaId) {
        Long id = Long.valueOf(pessoaId);
        for (Pessoa pessoa : pessoas) {
            if (id.equals(pessoa.getId())) {
                return pessoa;
            }
        }
        return null;
    }
       
    public void removeRow(Pessoa pessoa){
    	pessoas.remove(pessoa);
    }
    
    public void addRow(Pessoa pessoa){
    	pessoas.add(pessoa);
    }
    
    public void setRow(Pessoa pessoa, Integer index){
    	pessoas.set(index, pessoa);
    }    	
}

