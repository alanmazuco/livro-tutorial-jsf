package br.eti.amazu.blankapp.view.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.log4j.Level;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;
import org.primefaces.event.NodeSelectEvent;
import org.primefaces.event.NodeUnselectEvent;
import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.TreeNode;

import br.eti.amazu.blankapp.domain.brasil.Cidade;
import br.eti.amazu.blankapp.domain.brasil.Logradouro;
import br.eti.amazu.blankapp.domain.brasil.Uf;
import br.eti.amazu.blankapp.domain.infra.Empresa;
import br.eti.amazu.blankapp.domain.infra.Perfil;
import br.eti.amazu.blankapp.domain.infra.Pessoa;
import br.eti.amazu.blankapp.domain.infra.Usuario;
import br.eti.amazu.blankapp.persistence.SqlRepository;
import br.eti.amazu.blankapp.persistence.facade.IAppFacade;
import br.eti.amazu.blankapp.view.bean.common.UserSessionInBean;
import br.eti.amazu.blankapp.view.util.PessoaLazyList;
import br.eti.amazu.component.dialog.DialogBean;
import br.eti.amazu.component.dialog.DialogType;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.component.pworld.util.CompoundMenu;
import br.eti.amazu.component.upload.Upload;
import br.eti.amazu.component.upload.UploadMode;
import br.eti.amazu.util.Crypt;
import br.eti.amazu.util.DateUtil;
import br.eti.amazu.util.FacesUtil;
import br.eti.amazu.util.RegexUtil;
import br.eti.amazu.util.log.Log;

@Named
@ViewScoped
public class RecursosHumanosBean implements Serializable{

	private static final long serialVersionUID = 1L;	
	@Inject
	DialogBean dialogBean;
	
	@Inject
	UserSessionInBean userSessionInBean;
	
	@Inject
	IAppFacade<Pessoa> pessoaFacade;
	
	@Inject
	IAppFacade<Usuario> usuarioFacade;
	
	@Inject
	IAppFacade<Perfil> perfilFacade;
	
	@Inject
	IAppFacade<Empresa> empresaFacade;
	
	@Inject
	IAppFacade<Uf> ufFacade;
	
	@Inject
	IAppFacade<Cidade> cidadeFacade;
	
	@Inject
	IAppFacade<Logradouro> logradouroFacade;
	
	@Inject
	IAppFacade<Long> longFacade;
	
	
	/* ********************************
	 * UC MANTER O CADASTRAO DE PESSOAS
	 *********************************/
	private PessoaLazyList pessoas;
	String paramConsulta;
	
	/* modoConsulta = "listarTodos" ------> consulta serah listar todos os registros.
	 * modoConsulta = "nome" -------------> consulta serah uma pesquisa por nome.
	 * modoConsulta = "dataNas------------> consulta serah uma pesquisa por data nascimento */
	String modoConsulta = "listarTodos"; //listarTodos eh o modo default.
	
	private Pessoa pessoa;	
	private String nomeLocalizar;
	private Date dataNascLocalizar;
	private List<Empresa> empresas;	
	private Long selectedIdEmpresa;
	Empresa empresa;
	private Uf uf;
	private List<Uf> ufs;
	private Long selectedIdUf;
	private Cidade cidade;
	private List<Cidade> cidades;	
	private Long selectedIdCidade;	
	private String cep; //Campos de busca nao devem ser atrelados ao dominio.	
	byte[] oldFoto;	
	private Integer index;
	
	@CompoundMenu
	public void iniciarManterCadPes(){
		FacesUtil.resetBeans (null);
		FacesUtil.redirect("/pages/adm/recursosHumanos/cadastroPessoas/pessoas");
	}
	
	//Listar pessoas (realiza paginacao)
	public PessoaLazyList getPessoas() {     					
		if(pessoas == null){    			
            pessoas = new PessoaLazyList(pessoaFacade, 
            		userSessionInBean.isUsuarioDevLogado() == true ? true : false, modoConsulta, paramConsulta);            
        }    	

        return pessoas;
    }
	
	public void listarTodos(){
		modoConsulta = "listarTodos";
		paramConsulta = null;
		nomeLocalizar = null;
		dataNascLocalizar = null;	
		
		//Paginacao...
		pessoas = new PessoaLazyList(	pessoaFacade, 
				userSessionInBean.isUsuarioDevLogado() == true ? true : false, modoConsulta, paramConsulta); 
				
		RequestContext context = RequestContext.getCurrentInstance();
		context.update("formPessoas:tablePessoas");
	}
	
	public void localizar(){
		
		//localizar por nome, por data de nascimento
		if(nomeLocalizar == null || nomeLocalizar.trim().length() == 0  && dataNascLocalizar == null){
			
			//se nao digitou um filtro...
			dialogBean.addMessage(FacesUtil.getMessage("MPS020"), DialogType.ERROR);
			return;
		}	
		
		//se digitou os dois filtros...		
		if((nomeLocalizar != null  && nomeLocalizar.trim().length() > 0)  && dataNascLocalizar != null){			
			dialogBean.addMessage(FacesUtil.getMessage("MPS021"), DialogType.ERROR);
			return;
		}
		
		modoConsulta = "listarTodos"; //default;
		
		//se digitou o filtro nomeLocalizar...		
		if(nomeLocalizar != null && nomeLocalizar.trim().length() > 0) 	{
			modoConsulta = "nome";
			paramConsulta = nomeLocalizar;
		}
		
		//se digitou o filtro dataNascLocalizar...
		if(dataNascLocalizar != null) {
			modoConsulta = "dataNasc";				
			paramConsulta = DateUtil.getStringDate(dataNascLocalizar);
		}		
		pessoas = null;		
		
		//Abre o dlg Pessoa.
		RequestContext context = RequestContext.getCurrentInstance();
		context.execute("PF('dlgLocalizar').hide();");
		context.update("formPessoas:tablePessoas");
	}
	
	public void openDlgPessoa(Pessoa pessoa){
		
		try {			
			//popular a lista de empresas, de acordo com o usuario logado (traz a empresa do usuario logado)
			if(empresas == null) {
				if(userSessionInBean.isUsuarioDevLogado()) {
					empresas = empresaFacade.listar("Empresa.all"); //Util apenas ao usuario dev
					
				}else {
					empresas = new ArrayList<Empresa>();
					empresas.add(userSessionInBean.getEmpresa());					
				}
			}				
			
			List<Object> params = new ArrayList<Object>();
			
			//assegurando que upload em userSessionInBean esteja a estado inicial...
			if(userSessionInBean.getUpload() != null) userSessionInBean.getUpload().reset();
			
			//Popula a combo uf, para todos os casos.
			if(ufs == null || ufs.isEmpty()){
				params.clear();
				params.add(55L); //id do Brasil
				ufs = ufFacade.listar("Uf.porPais", params);
			}
			
			if(pessoa == null) {				
				pessoa = new Pessoa();
				this.pessoa = pessoa;				
				uf = null;
				selectedIdCidade = null;
				cidade = null;
				selectedIdUf = null;
				cep = null;				
				userSessionInBean.setFoto(null);
				
				
			}else{		
				
				if(pessoa.getUsuario() != null && pessoa.getUsuario().getPerfis() != null) {
					if(!podeExcluirEditar(pessoa.getUsuario().getPerfis(), 2)) {
						dialogBean.addMessage(FacesUtil.getMessage("MGL059"), DialogType.WARN);//==>nao deixa editar
						return; //==>nao deixa editar
					}
				}
				
				index = Integer.valueOf(FacesUtil.getParam("index")); //pegando o index da view
				
				//Seta variaveis...		
				this.pessoa = pessoa;
				cep = this.pessoa.getCep();	
				oldFoto = this.pessoa.getFoto();
				
				userSessionInBean.setFoto(pessoa.getFoto());
				
				
				//Recuperando cidade e uf baseado na cidade/uf da pessoa.
				if(this.pessoa.getCidade() != null && this.pessoa.getUf() != null){
					params.clear();
					params.add(this.pessoa.getCidade());
					params.add(this.pessoa.getUf());										

					cidade = cidadeFacade.recuperarNQ(new Cidade(),SqlRepository.RECUPERAR_CIDADE_UF_DA_PESSOA.getSql(), params);	
					
					if(cidade !=null){
						selectedIdCidade = cidade.getId();
						uf = cidade.getUf();
						selectedIdUf = uf.getId();
						
						//Populando os itens da combo cmbCidade, baseado na uf de pessoa.
						params.clear();
						params.add(uf.getId());
						cidades = cidadeFacade.listar("Cidade.porUf", params);
					}
				}				
			}			
			//Defalt eh a empresa do usuario logado.
			selectedIdEmpresa = userSessionInBean.getEmpresa().getId(); 
			empresa = userSessionInBean.getEmpresa();
			this.pessoa.setEmpresa(empresa);
									
			//Abre o dialog de inclusao/alteracao de novo perfil.
			RequestContext request = RequestContext.getCurrentInstance();
			request.update("formPessoa");			
			request.execute("PF('dlgPessoa').show()");
		
		} catch (DaoException e) {				
			e.printStackTrace();
		}
	}
	
	//Inicializa o componente Upload em modo DATABASE.
	public void chamarUpload(){		
		
		//se a imagem for maior que 113 x 85 pixels, o upload nao serah feito.
		userSessionInBean.setScImage(null);		

		userSessionInBean.setUpload(new Upload(
				dialogBean, 				
				UploadMode.IMAGE_DATABASE, 
				null,//FacesUtil.getFullPath("/resources/temp"), 
				null, 
				113, //tamanho de 113 pixels (altura de uma foto 3x4)
				85, //tamanho de 85 pixels (largura de uma foro 3x4)
				null, null, 	false));
	}
	
	public void cancelarEditar(){
		this.resetImage();
		pessoa.setFoto(oldFoto);			
		RequestContext request = RequestContext.getCurrentInstance();			
		request.execute("PF('dlgPessoa').hide()");
	}
	
	/* Este metodo ocorre sempre quando o usuario clica na cmbUf.
	 * Recupera a uf (o entityManager soh entra em acao caso nao haja uma uf managed).
	 * O selectedIdUf eh extremamente importante ser setado nesta etapa, ele
	 * irah propiciar o preenchimento dos itens dentro da cmbCidade.*/
	public void setarUf(AjaxBehaviorEvent event){	
		
		
		
		try {
			Map<String, Object> map = event.getComponent().getAttributes();			
			
			if( map.get("value") != null && (Long) map.get("value") != 0){
				uf = ufFacade.recuperar(Uf.class, (Long) map.get("value"));
				selectedIdUf = uf.getId();
				cidades = uf.getCidades().stream().collect(Collectors.toList());
				
			}else{
				cidades = new ArrayList<Cidade>();
			}
			
		} catch (DaoException e) {
			dialogBean.addMessage(e.getMessage(), DialogType.ERROR);
		}	
	}
	
	/* Este metodo ocorre sempre quando o usuario clica na cmbCidade.
	 * Recupera a uf (o entityManager soh entra em acao caso nao haja uma cidade managed).
	 * O selectedIdCidade eh importante ser setado nesta etapa, ele
	 * irah propiciar o preenchimento do valor setado na cmbCidade.*/
	public void setarCidade(AjaxBehaviorEvent event){		
						
		try {
			
			Map<String, Object> map = event.getComponent().getAttributes();
			if( map.get("value") != null && (Long) map.get("value") != 0){
				cidade= cidadeFacade.recuperar(Cidade.class, (Long) map.get("value"));			
				selectedIdCidade = cidade.getId();
			}
			
		} catch (DaoException e) {
			dialogBean.addMessage(e.getMessage(), DialogType.ERROR);
		}
	}
	
	/* Este metodo ocorre sempre quando o usuario dev clica na cmbEmpresa.*/
	public void setarEmpresa(AjaxBehaviorEvent event){				
		try {
			Map<String, Object> map = event.getComponent().getAttributes();			
			
			if( map.get("value") != null && (Long) map.get("value") != 0){
				empresa = empresaFacade.recuperar(Empresa.class, (Long) map.get("value"));
				selectedIdEmpresa = empresa.getId();
								
			}else{
				cidades = new ArrayList<Cidade>();
			}
			
		} catch (DaoException e) {
			dialogBean.addMessage(e.getMessage(), DialogType.ERROR);
		}	
	}
		
	public void salvar() {		
		try{								
			//Setar uf, cidade e cep (o operador pode ter redefinido essas propriedades).			
			pessoa.setUf(uf!=null ? uf.getSigla() : null);
			pessoa.setCidade(cidade!=null ? cidade.getNome() : null);			
			pessoa.setCep(cep);
			pessoa.setEmpresa(empresa);
			
			
			if(userSessionInBean.getUpload() != null && userSessionInBean.getUpload().getFile() != null){				
			    byte[] b = userSessionInBean.getUpload().getImageBytes();				
				pessoa.setFoto(b);
			}
			
			//Se jah possui um mesmo email em uma mesma empresa nao salva (restricao UK_EMAIL_EMPRESA)
			if(possuiRestricaoUK_EMAIL_EMPRESA()) {
				dialogBean.addMessage(FacesUtil.getMessage("MPS025"), DialogType.INFO_CLOSABLE);
				return;
			}
			
			/* Neste ponto, o atributo email pode estar nao-nulo e 'empty'.
			 * Neste caso, melhor setar para null, devido a restricao UK 
			 * dos campos EMAIL/ID_EMPRESA da tabela PESSOA.*/
			if(pessoa.getEmail() != null && pessoa.getEmail().equals("")) {
				pessoa.setEmail(null);
			}
				
			if(pessoa.getId() == null){
				pessoaFacade.incluir(pessoa); //inclui no BD
				pessoas.addRow(pessoa); //atualiza a view				
				
			}else{
				if(userSessionInBean.getUpload() != null && 
						userSessionInBean.getUpload().getScImage() == null) pessoa.setFoto(null);
				
				pessoa = (Pessoa) pessoaFacade.alterarAtualizar(pessoa); //altera no banco e atualiza o objeto.
				pessoas.setRow(pessoa, index); //atualiza a view				
			}
			
			//refresca imagem em userSessionInBean
			if(userSessionInBean.getUpload() != null) {
				userSessionInBean.getUpload().setScImage(null);	
				userSessionInBean.getUpload().setFile(null);
				userSessionInBean.getUpload().setImageBytes(null);
			}
			userSessionInBean.setFoto(null);
			userSessionInBean.setScImage(null);	
			
			//atualiza a view e emite mensagem ao usuario.
			RequestContext context = RequestContext.getCurrentInstance();
			context.execute("PF('dlgPessoa').hide()");
			context.update("formPessoas:tablePessoas");				
			dialogBean.addMessage(FacesUtil.getMessage("MGL025"), DialogType.INFO_CLOSABLE);
			
		}catch(DaoException e){		
			
			//Adiciona a mensagem vinda de DaoException
			dialogBean.addMessage(e.getMessage(), DialogType.ERROR);			
		}
	}
	
	/* Este metodo verifica se existe uma pessoa cadastrada dentro de
	 * uma mesma empresa com um email dado. Se existir um registro assim,
	 * nao deixa cadastrar novo registro, para nao violar uma restricao do banco de dados.*/
	boolean possuiRestricaoUK_EMAIL_EMPRESA() {		
		
		
		
		try {
			if(pessoa.getEmail() == null || pessoa.getEmail().equals("")) {
				return false;
			}
			
			List<Object> params = new ArrayList<Object>();
			params.add(pessoa.getEmail());
			params.add(empresa.getId());
			
			return longFacade.recuperarMaxResultNQ(
					SqlRepository.VERIFICAR_UK_EMAIL_EMPRESA.getSql(), params) >= 1 ? true: false;
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public void localizarEnderecoPeloCep(){				
		try {			
			//Aqui soh necessito de uma validacao (o campo cep nao pode ser nulo).
			if(cep == null || cep.equals("")){
				dialogBean.addMessage(FacesUtil.getMessage("MPS005"), DialogType.ERROR);
				return;
			}					
			
			//Busca o logradouro da pessoa baseado no cep.
			List<Object> params = new ArrayList<Object>();
			params.add(cep);
			
			Logradouro logradouro = logradouroFacade.recuperarNQ(new Logradouro(), 
					SqlRepository.RECUPERAR_ENDERECO__PELO_CEP.getSql(), params);
			
			//Se nao encontra o logradouro avisa e sai.
			if(logradouro == null){
				dialogBean.addMessage(FacesUtil.getMessage("MPS004"), DialogType.INFO_CLOSABLE);
				return;
			}
			
			/* Quando encontra o logradouro, encontra tambem:
			 * - A cidade;
			 * - Seta o id da cidade, forcando a renderizacao na cmbCidade;
			 * - A uf;
			 * - Seta o id da uf, forcando a renderizacao na cmbUf;
			 * - Obtem a lista de cidades da uf para popular os itens da cmbCidade;
			 * - Seta os dados do endereco localizado na pessoa que se estah editando. */			
			cidade = logradouro.getBairro().getCidade();
			selectedIdCidade = cidade.getId();
			uf = cidade.getUf();
			selectedIdUf = uf.getId();
			cidades = uf.getCidades().stream().collect(Collectors.toList());			
			pessoa.setCep(cep);
			pessoa.setLogradouro(logradouro.getNome());
			pessoa.setBairro(logradouro.getBairro().getNome());
			pessoa.setCidade(cidade.getNome());			
			pessoa.setUf(uf.getSigla());
						
		} catch (DaoException e) {			
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
		}
	}
	
	public void confirmarExcluirPessoa(Pessoa pessoa){					
		
		try {
			/* As instrucoes abaixo evitam a LazyInitializationException.
			 * Colocando pessoa em estado "managed" (isto pode ser necessario, caso o objeto esteja detach)
			 * Colocando os perfis do usuario em usuario (porque a sessao estende demais)*/
			pessoa = (Pessoa) pessoaFacade.recuperar(Pessoa.class, pessoa.getId());			
			List<Object> params = new ArrayList<Object>();
			if(pessoa.getUsuario() != null) {
				params.add(pessoa.getUsuario().getId());	
				
				pessoa.getUsuario().setPerfis(
						perfilFacade.listar("Perfil.porUsuario", params).stream().collect(Collectors.toSet()));
			}//------------------------------------------------------------------------------------------------
						
			if(pessoa.getUsuario() != null && pessoa.getUsuario().getPerfis() != null) {
				if(!podeExcluirEditar(pessoa.getUsuario().getPerfis(), 1)) {
					dialogBean.addMessage(FacesUtil.getMessage("MGL059"), DialogType.WARN);//==>nao deixa excluir
					return; //==>nao deixa excluir
				}
			}
			
			this.pessoa = pessoa;
			
			dialogBean.addConfirmWarnMessage(FacesUtil.getMessage("MGL028"), 
					"recursosHumanosBean.excluirPessoa", null, null);
		
		} catch (DaoException e1) {
			e1.printStackTrace();
		}
		
	}
	
	//Metodo comum aos UCs Cadastro de Pessoas e Cadastro de Usuarios
	boolean podeExcluirEditar(Set<Perfil> perfisEmExlusaoOuEdicao, int op) {
			
		/* Variavel "op" pode assumir os seguintes valores:
		 * 1 = excluir
		 * 2 = editar pessoa
		 * 3 = editar usuario		 * 
		 * Regras para um usuario Dev logado, que pode tudo, exceto:
		 * - se perfisEmExlusaoOuEdicao conter o Adm (nao pode excluir nem editar);
		 * - se existir apenas um usuario dev nao pode excluir mas pode editar*/
		if(containsPerfil(userSessionInBean.getPerfisLogado().stream().collect(Collectors.toSet()), 1L)) {
			if(perfisEmExlusaoOuEdicao != null) {
				if(!containsPerfil(perfisEmExlusaoOuEdicao, 2L)) {
					return true; //pode excluir e editar pessoa e editar usuario
					
				}else {
					//nao contendo o adm - verifica se possui apenas um usuario dev
					int quantDev = quantUsuarioDev();
					if(quantDev > 1) {
						return true; //pode excluir e editar
						
					}else {
						if(op == 1) return false; //nao pode excluir
						if(op == 2 || op == 3) return true; //pode editar pessoa e usuario
					}
				}
				
			}else {
				return true; //pode excluir e editar pessoa e editar usuario
			}
			
		}else {
			/* Regras para o Admin logado:
			 * - se perfisEmExlusaoOuEdicao conter o Adm (nao pode excluir nem editar);*/
			if(containsPerfil(userSessionInBean.getPerfisLogado().stream().collect(Collectors.toSet()), 2L)) {				
				if(perfisEmExlusaoOuEdicao != null) {
					if(!containsPerfil(perfisEmExlusaoOuEdicao, 2L)) {					
						return true; //pode excluir e editar pessoa e editar usuario
						
					}else {
						if(op == 1) return false; //nao pode excluir
						if(op == 2 || op == 3) return true; //pode editar pessoa e usuario						
					}
					
				}else {
					if(op == 1) return false; //nao pode excluir
					if(op == 2 || op == 3) return true; //pode editar pessoa e usuario
				}
				
			}else {
				/* Regras para o Master logado:
				 * - se perfisEmExlusaoOuEdicao conter Adm ou Master (nao pode excluir nem editar);*/
				if(containsPerfil(userSessionInBean.getPerfisLogado().stream().collect(Collectors.toSet()), 3L)) {					
					if(perfisEmExlusaoOuEdicao != null) {
						if(containsPerfil(perfisEmExlusaoOuEdicao, 2L) || containsPerfil(perfisEmExlusaoOuEdicao, 3L)) {					
							return false; //nao pode excluir nem editar
							
						}else {
							return true; //pode excluir, editar pessoa e usuario											
						}
						
					}else {
						return true; //pode excluir, editar pessoa e usuario
					}
					
				}else {
					/* Regras para o Senior logado:
					 * - se perfisEmExlusaoOuEdicao conter Adm ou Master ou Senior (nao pode excluir nem editar);*/
					if(containsPerfil(userSessionInBean.getPerfisLogado().stream().collect(Collectors.toSet()), 4L)) {
						if(perfisEmExlusaoOuEdicao != null) {
							if(!containsPerfil(perfisEmExlusaoOuEdicao, 2L) &&
									!containsPerfil(perfisEmExlusaoOuEdicao, 3L) &&
											!containsPerfil(perfisEmExlusaoOuEdicao, 4L) ) {
								return false; //nao pode excluir nem editar								
							}
							
						}else {							
							return false; //nao pode excluir nem editar							
						}
					}
				}
			}
		}		
		return false;
	}

	
	
	public void excluirPessoa(){			
		
		/* Regra: "ao excluir uma pessoa, apaga tambem o usuario respectivo e seus dependentes.
		 * Como existem fortes restricoes, a estrutura abaixo eh fortemente recomendada, 
		 * na sequencia em que se apresenta.
		 * Lembrando que isto conduz a uma exclusao imediata, portanto a regra deve ser repensada.*/
		
		try {			
			//Desassocia usuario de perfis e pessoa de usuario
			if(pessoa.getUsuario() != null) {
				pessoa.getUsuario().setPerfis(null);
				usuarioFacade.alterar(pessoa.getUsuario());				
				//Dessasocia pessoa de usuario e exclui usuario		
				pessoa.setUsuario(null);
				pessoaFacade.alterar(pessoa);
			}

			//Remove a pessoa da empresa e consequentemente a pessoa no banco de dados.
			Empresa empresa = empresaFacade.recuperar(Empresa.class, pessoa.getEmpresa().getId());
			empresa.getPessoas().remove(pessoa);
			empresaFacade.alterar(empresa);
			
			//atualiza a view
			pessoas.removeRow(pessoa); 			
			RequestContext context = RequestContext.getCurrentInstance();
			context.update("formPessoas:tablePessoas");			
			dialogBean.addMessage(FacesUtil.getMessage("MGL029"), DialogType.INFO_CLOSABLE);
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}
	
	//Este metodo possibilita dar um update apenas na linha da tabela pessoa.
	public void updateRow() {		
		FacesContext ctx = FacesContext.getCurrentInstance();		
		DataTable dataTable = (DataTable) ctx.getViewRoot().findComponent("formPessoas:tablePessoas");					
		RequestContext.getCurrentInstance().update(dataTable.getClientId(ctx)+ ":" + index + ":pnlNome");
		RequestContext.getCurrentInstance().update(dataTable.getClientId(ctx)+ ":" + index + ":pnlDataNasc");
		RequestContext.getCurrentInstance().update(dataTable.getClientId(ctx)+ ":" + index + ":pnlAcoes");
	}	
	
	public void resetImage(){
		pessoa.setFoto(null);
		if(userSessionInBean.getUpload() != null) {
			userSessionInBean.getUpload().setScImage(null);	
			userSessionInBean.getUpload().setFile(null);
		}
		userSessionInBean.setScImage(null);		
		userSessionInBean.setFoto(null);	
	}
	
	public void excluirFoto(){
		pessoa.setFoto(null);
		if(userSessionInBean.getUpload() != null) {
			userSessionInBean.getUpload().setScImage(null);	
			userSessionInBean.getUpload().setFile(null);
		}
		userSessionInBean.setScImage(null);		
		userSessionInBean.setFoto(null);
	}
	
	//Mensurar a quantidade de usuarios desenvolvedores para validar exclusoes
	Integer quantUsuarioDev() {					
		try { //melhor buscar no BD...
			return usuarioFacade.recuperarMaxResultNQ(SqlRepository.RECUPERAR_QUANTIDADE_USUARIOS_DEV.getSql());
			
		} catch (DaoException e) {			
			e.printStackTrace();
		}
		return null;
	}
	
	//Este metodo permite ajustar alguns elementos na dataTable da view pessoas.xhtml
	public boolean isPerfilEsperado(Pessoa pessoa, Long idPerfilEsperado) {
		if(pessoa.getUsuario() != null && pessoa.getUsuario().getPerfis() != null) {
			for(Perfil perfil:pessoa.getUsuario().getPerfis()) {
				if(perfil.getId() == idPerfilEsperado) {
					return true;
				}
			}
		}
		return false;
	}
	
	//Metodo comum aos UCs Cadastro de Pessoas e Cadastro de Usuarios
	boolean containsPerfil(Set<Perfil> perfis, Long idPerfil) {
		for(Perfil perfil:perfis) {
			if(idPerfil == perfil.getId()) {
				return true;
			}
		}
		return false;
	}
	/* ***************************************
	 * FIM DO UC MANTER O CADASTRAO DE PESSOAS
	 ****************************************/
	
	
	
	/* ********************************
	 * UC MANTER OS USUARIOS DO SISTEMA
	 *********************************/	
	@Inject
	RealizarLoginBean realizarLoginBean;	
	private List<Perfil> perfis;
	private List<Perfil> perfisSelecionados;
	private String password;
	private String confirmPassword;
	String nomeUsuarioBackup;
	
	/* -------------------
	 * perfis
	 * -------------------*/
	private TreeNode root;
	private TreeNode node[];
	Perfil perfil;
	/*--------------------*/
	
	@CompoundMenu
	public void iniciarManterCadUs(){
		FacesUtil.resetBeans (null);			
		FacesUtil.redirect("/pages/adm/recursosHumanos/cadastroPessoas/pessoas");
	}	
		
	public void openDlgUsuario(Pessoa pessoa){

		Set<Perfil> perfisDoUsuario = null;
		if(pessoa.getUsuario() != null && pessoa.getUsuario().getPerfis() != null) {
			perfisDoUsuario = pessoa.getUsuario().getPerfis();
		}		
		if(!podeExcluirEditar(perfisDoUsuario, 3)) {
			dialogBean.addMessage(FacesUtil.getMessage("MGL059"), DialogType.WARN);//==>nao deixa editar
			return; //==>nao deixa editar
		}			
		
		this.pessoa = pessoa;				
		index = Integer.valueOf(FacesUtil.getParam("index")); //pegando o index da view		
		this.listarPerfis(); //disponibiliza a lista de perfis para a select de perfis
		
		//se usuario eh null ----> modo inclusao
		if(this.pessoa.getUsuario() == null || this.pessoa.getUsuario().getId() == null){		
			perfisSelecionados = new ArrayList<Perfil>();
			Usuario usuario = new Usuario();			
			this.pessoa.setUsuario(usuario);
			password = null;			
			
		}else{
			
			/* se usuario nao eh null -----> modo edicao
			 * Mesmo assim, buscar e setar usuario em pessoa: isto evitarah uma 
			 * LazyInitializationException neste ponto */
			List<Object> params = new ArrayList<Object>();
			params.add(1);
			try {
				Usuario u = usuarioFacade.recuperar(Usuario.class, pessoa.getId());
				
				//pegar os perfis que o militar jah possui e setar perfisSelecionados
				perfisSelecionados = u.getPerfis().stream().collect(Collectors.toList());
				
				/* aqui, evitando a  LazyInitializationException
			 	-----------------------------------------------*/			
				this.pessoa.setUsuario(u); 
				
			} catch (DaoException e) {				
				e.printStackTrace();
			}			
			//selectedIdPerfil = this.pessoa.getUsuario().getPerfil().getId();			
			//Comparar com isto, sempre ao salvar depois.
			nomeUsuarioBackup = this.pessoa.getUsuario().getNomeUsuario();			
		}
		
		//se o usuario logado nao eh o dev, nao mostra o perfil DEV
		if(!containsPerfil(perfis.stream().collect(Collectors.toSet()), 1L)) {
			//localizar a string DESENVOLVEDOR, e apagar			
			Iterator<Perfil> it = perfisSelecionados.iterator();
			while(it.hasNext()){
				Perfil p = it.next();
				if(p.getNome().equalsIgnoreCase("DESENVOLVEDOR")){
					it.remove();							
				}
			}		
		}
					
		//popular root (arvore tree)
		this.popularRoot();		

		
		//setando a foto da pessoa em userSessionInBean		
		userSessionInBean.setFoto(this.pessoa.getFoto());				
		RequestContext context = RequestContext.getCurrentInstance();
		context.update("formDlgUsuario");		
		context.execute("PF('dlgUsuario').show()");
	}
	
	void popularRoot() {
		int i = 0;
		root = new DefaultTreeNode("Root", null);
		node = new DefaultTreeNode[perfis.size()];			
		for(Perfil perfil : perfis){
			node[i] = new DefaultTreeNode(perfil, root);
			//node[i].setSelectable(true);								
			if(perfisSelecionados != null) {
				if(perfisSelecionados.contains(perfil)){
					node[i].setSelected(true);
				}else{
					node[i].setSelected(false);
				}
				
				if(perfil.getNome().equals("ADMINISTRADOR")){					
					node[i].setSelectable(false);
				}
			}
			i++;
		}	
	}
	
	/* Metodo que Seleciona o perfil */
	public void onNodeSelect(NodeSelectEvent event) {        
			    	
    	try {
        	//pega o perfil clicado
        	perfil = (Perfil) event.getTreeNode().getData();
        	
        	//se eh modo edicao, jah salva no banco
        	if(pessoa.getUsuario().getId() != null){
        		List<Object> params = new ArrayList<Object>();
        		params.add(pessoa.getId());
        		params.add(perfil.getId());
        		perfilFacade.executarNQ(SqlRepository.INSERIR_USUARIO_PERFIL.getSql(), params);
        	}
        	
			//atualiza a lista de perfis do militar
	    	perfisSelecionados.add(perfil); //atualiza a dlgPerfis	    	    	
		    	
		    Log.setLogger("", "Atribuiu o perfil " + perfil.getNome(), Level.INFO);
			
		} catch (DaoException e) {			
			e.printStackTrace();
		}    	
	}
	
	/* Metodo que Deseleciona o perfil */
	public void onNodeUnselect(NodeUnselectEvent event) {        
		
		try {
			//pega o perfil clicado
			perfil = (Perfil) event.getTreeNode().getData();									
			
			//se eh modo edicao, jah salva no banco
	    	if(pessoa.getUsuario().getId() != null){
	    		List<Object> params = new ArrayList<Object>();
        		params.add(pessoa.getId());
        		params.add(perfil.getId());
        		perfilFacade.executarNQ(SqlRepository.EXCLUIR_USUARIO_PERFIL.getSql(), params);	    		
	    	}
			
			//atualiza a lista de perfis do militar
			perfisSelecionados.remove(perfil);				    		    	
				
			Log.setLogger("", "Desselecionou do usuario o perfil " + perfil.getNome(), Level.INFO);
			
		} catch (DaoException e) {			
			e.printStackTrace();
		}  
	}
	
	public List<Perfil> listarPerfis() {
		if(perfis == null){
			try {
				perfis = perfilFacade.listar("Perfil.all");
				
				//se nao eh o dev logado, nao mostra o perfil de desenvolvedor.
				if(!userSessionInBean.isUsuarioDevLogado()) {				
					Iterator<Perfil> it = perfis.iterator();
					while (it.hasNext()){
						Perfil p = it.next();
						if(p.getId() == 1) it.remove();							
					}
				}
			
			} catch (DaoException e) {
				dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
			}
		}
		return perfis;
	}
	
	public void salvarNomeUsuario() {
		try {			
			List<Object> params = new ArrayList<Object>();
    		params.add(pessoa.getUsuario().getNomeUsuario());
    		params.add(pessoa.getUsuario().getId());
    		perfilFacade.executarNQ(SqlRepository.ALTERAR_USUARIOo.getSql(), params);			
						
		} catch (DaoException e) {			
			e.printStackTrace();
		}
	}
		
	public String salvarUsuario(String dlg){		
		try{			
			if(this.validarUsuario(pessoa.getUsuario())){				
				pessoa.getUsuario().setBloqueado("F");
				pessoa.getUsuario().setPrimeiroAcesso("T");
				pessoa.getUsuario().setDataPrimeiroAcesso(new Date());					
								
				if(pessoa.getUsuario().getId() == null){

					//chegando aqui a senha criptografada
					/* Recebe a senha digitada no browser.
					 * Lembrando que esta senha foi mascarada com CriptpJs (ela deve ser descriptografada)
					 * antes de cmparar com a do banco de dados.*/
					String newPassw = Crypt.decrypt(password);
					String confirmeNewPassw = Crypt.decrypt(confirmPassword);
					
					//verifica se possui minimo de 3 caracteres
					if(newPassw.length() < 3) {
						dialogBean.addMessage(FacesUtil.getMessage("RLO045"), DialogType.ERROR);
						return null;
					}					
					//verifica se possui caracteres invalidos...
					if (!newPassw.matches("[a-zA-Z0-9_]+")) {
						dialogBean.addMessage(FacesUtil.getMessage("MGL004"), DialogType.ERROR);
						return null;
					}					
					if(newPassw.equals(confirmeNewPassw)){				
						
						/* Isto irah atualizar os dados do usuario em seu primeiro acesso.*/
						List<Object> params = new ArrayList<Object>();					
						params.add(userSessionInBean.getUserLogged());						
						pessoa.getUsuario().setSenha(Crypt.getHash(newPassw));
												
					}else{
						dialogBean.addMessage(FacesUtil.getMessage("RLO013"), DialogType.INFO_CLOSABLE);
						return null;
					}
					pessoa.getUsuario().setPessoa(pessoa); //Setar o id da pessoa em USUARIO
					usuarioFacade.incluir(pessoa.getUsuario()); //primeiro inclui o usuario
					
					//Setando os perfis selecionados pelo usuario
					pessoa.getUsuario().setPerfis(perfisSelecionados.stream().collect(Collectors.toSet()));
					
					//Associa usuario com pessoa...
					usuarioFacade.alterar(pessoa.getUsuario());
									
				}else{	
					//Setando os perfis selecionados pelo usuario
					pessoa.getUsuario().setPerfis(perfisSelecionados.stream().collect(Collectors.toSet()));
					
					//altera
					usuarioFacade.alterar(pessoa.getUsuario());					
				}
								
				pessoas.setRow(pessoa, index); //atualiza a lista
				
				//Sincroniza o BD com o entityManager.
				usuarioFacade.flush(); //Sicroniza o banco de dados antes de pegar o objeto.
				
				RequestContext context = RequestContext.getCurrentInstance();
				context.execute("PF('" + dlg + "').hide()");
				
				dialogBean.addActionMessage(FacesUtil.getMessage("MGL025"),
						"recursosHumanosBean.updateRow", null);		
			}
					
		}catch(DaoException e){
			
			//Adiciona a mensagem vinda de DaoException (eh personalizada em InterceptorException).
			dialogBean.addMessage(e.getMessage(), DialogType.ERROR);
		}
		return null;
	}
	
	
	//O metodo valida um usuario para inclusao no DB
	public boolean validarUsuario(Usuario usuario){		
		
		//O usuario dev (com um nome = dev) eh reservado ao sistema
		if(usuario.getNomeUsuario().equals("dev")){			
			dialogBean.addMessage(FacesUtil.getMessage("MUS023"),DialogType.WARN);
			return false;
		}
		
		//Nao pode salvar um usuario com a lista de perfis nula
		if(perfisSelecionados == null || perfisSelecionados.size() == 0) {
			dialogBean.addMessage(FacesUtil.getMessage("MUS009"), DialogType.ERROR);
			return false;
		}		
		
		//Verifica se existe o nome de usuario que estah tentando atribuir.
		String nomeUsLoc = nomeUsuarioLocalizado(usuario);
		
		if(usuario.getId()==null){
			
			/* No caso de inclusao...
			 * Se as senhas nao sao iguais avisa e retorna false. */
			if(!password.equals(confirmPassword)){
				dialogBean.addMessage(FacesUtil.getMessage("RLO013"),DialogType.WARN);
				return false;
			}
			
			//Se encontrou um nome de usuario igual, avisa e retorna false.
			if(nomeUsLoc != null){				
				dialogBean.addMessage(FacesUtil.getMessage("MUS002", 
						new String[]{usuario.getNomeUsuario()}),DialogType.WARN);
				
				return false;
			}
			
		}else{			
			/* No caso de alteracao...
			 * Precisa verificar se o usuario trocou o nome.
			 * Isto eh necessario para nao invalidar caso ele esteja mudando outro atributo diferente do nome.*/
			if(!nomeUsuarioBackup.equals(usuario.getNomeUsuario())){				
				if(nomeUsLoc != null){
					
					/* Mudou o nome...(apresenta a mensagem apenas se mudou o 
					 * nome e caso esse nome exista no BD). */
					dialogBean.addMessage(FacesUtil.getMessage("MUS002", 
							new String[]{usuario.getNomeUsuario()}),DialogType.WARN);
					
					return false;
				}
			}			
		}		
		return true; //Passou por todas as validacoes sem erro...
	}
	
	String nomeUsuarioLocalizado(Usuario usuario){		
		try{
			List<Object> params = new ArrayList<Object>();			
			params.add(usuario.getNomeUsuario());
			
			return usuarioFacade.recuperar(
					"Usuario.recuperarPeloNome", params)!=null?usuario.getNomeUsuario():null;
			
		}catch(DaoException e){
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
		}		
		return null;
	}	
	
	public void confirmarExcluirUsuario(){
		
		//colocando pessoa em estado "managed" (isto pode ser necessario, caso o objeto esteja detach)
		try {
			pessoa = (Pessoa) pessoaFacade.recuperar(Pessoa.class, pessoa.getId());
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
		
		//Nao permite excluir o usuario administrador (mesmo que o logado seja um usuario dev)
		if(containsPerfil(pessoa.getUsuario().getPerfis().stream().collect(Collectors.toSet()), 2L)){			
			dialogBean.addMessage(FacesUtil.getMessage("MGL059"), DialogType.WARN);
			return;
		}
	
		dialogBean.addConfirmMessage(
				FacesUtil.getMessage("MGL028"), //...................message
				"recursosHumanosBean.excluirUsuarioEdita",     //....actionButtonYes
				null,  //............................................actionButtonNo
				null,  //............................................updateButtonYes
				null); //............................................updateButtonNo
	}
	
	public void excluirUsuarioEdita(){
		this.excluirUsuario("dlgEditaUsuario");
	}
	
	public String excluirUsuario(String dlg){		
		try {			
			//Nao pode excluir o usuario administrador
			if(containsPerfil(pessoa.getUsuario().getPerfis(), 2L)){			
				dialogBean.addMessage(FacesUtil.getMessage("MUS024"),DialogType.WARN);
				return null;
			}
			
			//inicialmente - desassocia usuario com perfis e salva usuario
			pessoa.getUsuario().setPerfis(null);
			usuarioFacade.alterar(pessoa.getUsuario());
			
			pessoa.setUsuario(null); //Exclui o usuario da pessoa.
			pessoaFacade.alterar(pessoa);			
			pessoas.setRow(pessoa, index); //atualiza a lista
			
			//Sincroniza o BD com o entityManager.
			usuarioFacade.flush(); //Sicroniza o banco de dados antes de pegar o objeto.
			
			RequestContext context = RequestContext.getCurrentInstance();
			context.execute("PF('dlgUsuario').hide()");
			
			dialogBean.addActionMessage(FacesUtil.getMessage("MUS022", new String[]{pessoa.getNome()}),
					"recursosHumanosBean.updateRow", null);			
			
		} catch (DaoException e) {			
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
		}		
		return null;
	}	
	
	public void resetPassword(){	
		
		try {				
			if(this.validarUsuario(pessoa.getUsuario())){			
								
				//Reseta a senha do usuario.
				String senhaDescriptografada = realizarLoginBean.getSenhaPosReset(); //Gera nova senha
				
				//setando o hash da senha
				pessoa.getUsuario().setSenha(Crypt.getHash(senhaDescriptografada));
				
				pessoa.getUsuario().setPrimeiroAcesso("T");				
				pessoa.getUsuario().setDataPrimeiroAcesso(new Date());			
							
				/* Salva e iguala o objeto da view com o do EntityManager, 
				 * evitando o aviso de lock para o mesmo usuario. */
				pessoa.setUsuario( (Usuario) usuarioFacade.alterarAtualizar(pessoa.getUsuario()));
				
				//Refresca o datamodel. 
				pessoas.setRow(pessoa, index); //atualiza a lista				
				RequestContext context = RequestContext.getCurrentInstance();
				context.update("formUsuario");
				
				//enviar um email ao usuario
				if(pessoa.getEmail() != null) {
					realizarLoginBean.enviarEmail(pessoa.getEmail(), //email do usuario
						FacesUtil.getMessage("RLO017") + ": " + senhaDescriptografada); //mensagem com a senha
					
					dialogBean.addMessage(FacesUtil.getMessage("MUS018", 
							new String[]{pessoa.getUsuario().getNomeUsuario()}), DialogType.INFO_CLOSABLE);
				}else {
					Log.setLogger("", FacesUtil.getMessage("MGL079"), Level.WARN);
					
					dialogBean.addMessage(FacesUtil.getMessage("MUS025", 
							new String[]{pessoa.getUsuario().getNomeUsuario()}), DialogType.INFO_CLOSABLE);
				}				
			}
							
		} catch (DaoException e) {			
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
		}		
	}	
	
	public void bloquearDesbloquear(){		
		try {	
			if(this.validarUsuario(pessoa.getUsuario())){				
				//pessoa.getUsuario().setPerfil(perfil); //evitando a LayInitializationException
				
				//Nao permite bloquear o usuario administrador ou dev
				if(!userSessionInBean.isUsuarioDevLogado() && 
						(containsPerfil(pessoa.getUsuario().getPerfis(), 1L) || 
								containsPerfil(pessoa.getUsuario().getPerfis(), 2L)) ) {								
					dialogBean.addMessage(FacesUtil.getMessage("MGL059"), DialogType.WARN);
					return;
				}	
				
				pessoa.getUsuario().setPrimeiroAcesso("T");
				pessoa.getUsuario().setDataPrimeiroAcesso(new Date());
				
				if(pessoa.getUsuario().getBloqueado().equals("T")){
					pessoa.getUsuario().setBloqueado("F");
					
				}else{
					pessoa.getUsuario().setBloqueado("T");
				}
				
				/* Salva e iguala o objeto da view com o do EntityManager, 
				 * evitando o aviso de lock para o mesmo usuario. */				
				pessoa.setUsuario( (Usuario) usuarioFacade.alterarAtualizar(pessoa.getUsuario()));
				
				//Refresca o datamodel. 
				pessoas.setRow(pessoa, index); //atualiza a lista
				
				RequestContext context = RequestContext.getCurrentInstance();
				context.update("formUsuario");
			}
		
		} catch (DaoException e) {			
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
		}	
		
	}
	
	public String getLimitCharNotBlankSpace() {		
		return RegexUtil.getLimitCharNotBlankSpace(); //Tratamentode strings - limitacoes
	}
	/* ***************************************
	 * FIM DE UC MANTER OS USUARIOS DO SISTEMA
	 ****************************************/

	
	
	/*--------
	 * get/set
	 -------*/
	public void setPessoas(PessoaLazyList pessoas) {
		this.pessoas = pessoas;
	}
	public Pessoa getPessoa() {
		return pessoa;
	}
	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}
	public String getNomeLocalizar() {
		return nomeLocalizar;
	}
	public void setNomeLocalizar(String nomeLocalizar) {
		this.nomeLocalizar = nomeLocalizar;
	}
	public Date getDataNascLocalizar() {
		return dataNascLocalizar;
	}
	public void setDataNascLocalizar(Date dataNascLocalizar) {
		this.dataNascLocalizar = dataNascLocalizar;
	}
	public List<Empresa> getEmpresas() {
		return empresas;
	}
	public void setEmpresas(List<Empresa> empresas) {
		this.empresas = empresas;
	}
	public Long getSelectedIdEmpresa() {
		return selectedIdEmpresa;
	}
	public void setSelectedIdEmpresa(Long selectedIdEmpresa) {
		this.selectedIdEmpresa = selectedIdEmpresa;
	}
	public Uf getUf() {
		return uf;
	}
	public void setUf(Uf uf) {
		this.uf = uf;
	}
	public List<Uf> getUfs() {
		return ufs;
	}
	public void setUfs(List<Uf> ufs) {
		this.ufs = ufs;
	}
	public Long getSelectedIdUf() {
		return selectedIdUf;
	}
	public void setSelectedIdUf(Long selectedIdUf) {
		this.selectedIdUf = selectedIdUf;
	}
	public Cidade getCidade() {
		return cidade;
	}
	public void setCidade(Cidade cidade) {
		this.cidade = cidade;
	}
	public List<Cidade> getCidades() {
		return cidades;
	}
	public void setCidades(List<Cidade> cidades) {
		this.cidades = cidades;
	}
	public Long getSelectedIdCidade() {
		return selectedIdCidade;
	}
	public void setSelectedIdCidade(Long selectedIdCidade) {
		this.selectedIdCidade = selectedIdCidade;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public List<Perfil> getPerfis() {
		return perfis;
	}
	public void setPerfis(List<Perfil> perfis) {
		this.perfis = perfis;
	}
	public TreeNode getRoot() {
		return root;
	}
	public void setRoot(TreeNode root) {
		this.root = root;
	}
	public TreeNode[] getNode() {
		return node;
	}
	public void setNode(TreeNode[] node) {
		this.node = node;
	}
	public List<Perfil> getPerfisSelecionados() {
		return perfisSelecionados;
	}
	public void setPerfisSelecionados(List<Perfil> perfisSelecionados) {
		this.perfisSelecionados = perfisSelecionados;
	}
}
