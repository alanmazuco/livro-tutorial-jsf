package br.eti.amazu.util;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


public final class Crypt {
	
	//Salt definido em 1000 iteracoes. Voce pode aumentar ou diminuir isto.
	private final static int ITERATION_NUMBER = 1000;
	
	public static final String getHash(String senha) {
		
		try {		
			//Geracao randomica do salt
			SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
			byte[] byteSalt = new byte[senha.length()];
			random.nextBytes(byteSalt);
			
			//Inicializa o algoritmo SHA-512
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
			messageDigest.reset();
			messageDigest.update(byteSalt);
			 
			//Gera o hash inicial
			byte byteHash[] = messageDigest.digest(senha.getBytes("UTF-8"));
			 
			//Melhora o hash (incrementa mais seguranca)
			for(int i=0; i<ITERATION_NUMBER; i++) {
			  messageDigest.reset();
			  byteHash = messageDigest.digest(byteHash);
			}
			 
			//transforma o hash para gravacao no banco
			StringBuilder hexHash = new StringBuilder();
			for(byte b : byteHash) {
			  hexHash.append(String.format("%02X", 0xFF & b));
			}
			
			//Transforma o salt para ser gravado no banco
			StringBuilder hexSalt = new StringBuilder();						
			for(byte b : byteSalt) {
			  hexSalt.append(String.format("%02X", 0xFF & b));
			}
			
			/* O retorno eh algo neste formato:
			 * Uma sequencia de caracteres que representa o salt. Exemplo: 00000000
			 * + a sequencia de caracteres "+HASH+" 
			 * + uma sequencia de caracteres que representa o Hash. exemplo: 999999999999999
			 * Ficando assim: 00000000+HASH+999999999999999 */			
			return(hexSalt.toString() + "+HASH+" + hexHash.toString());
			
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}	
		
		return null;
	}
	
	public static boolean checkPassword(String senha, String saltHash){		
		try {	
			//Desdobra o que veio do banco de dados em duas strings: salt e hash
			String salt = saltHash.substring(0, saltHash.indexOf("+HASH+"));
			String hashBD = saltHash.substring(saltHash.indexOf("+HASH+") + 6);
			
			//transforma o salt em array de bytes inteligivel ao algoritmo
			byte[] byteSalt = new byte[senha.length()];			
			for(int i=0; i<salt.length(); i+=2) {
				  byteSalt[i/2] = (byte) ((Character.digit(salt.charAt(i), 16) << 4) + Character.digit(salt.charAt(i+1), 16));
			}
			
			//Inicializa o algoritmo com o salt obtido do banco
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
			messageDigest.reset();
			messageDigest.update(byteSalt);
			 			
			//E utilizando a mesma iteracao utilizada na criacao do hash.
			byte byteHash[] = messageDigest.digest(senha.getBytes("UTF-8"));			 
			for(int i=0; i<ITERATION_NUMBER; i++) {
			  messageDigest.reset();
			  byteHash = messageDigest.digest(byteHash);
			}
			 
			//Transforma o hash em array de bytes inteligivel ao algoritmo.
			StringBuilder hexHash = new StringBuilder();
			for(byte b : byteHash) {
				  hexHash.append(String.format("%02X", 0xFF & b));
				}
				 
				//Compara o hash criado no login com o hash obitido do banco
				if(hexHash.toString().equals(hashBD)){
					return true; //se forem iguais, o usuario estah logado.
					
				}else{
					return false; //se forem diferentes o usuario nao loga.
				}
							
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (StringIndexOutOfBoundsException e)	{
			e.printStackTrace();
		}
		
		return false;
	}
	
	/* Codigo utilizado a partir da Licao 37.*/
	public static String decrypt(String cipherText) {
		 try {
			 String key = "encrypt-crypto-h";
			 String iv    = "encrypt-crypto-h";

	        final Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "SunJCE");
	        final SecretKeySpec skey = new SecretKeySpec(key.getBytes("UTF8"), "AES");
	        cipher.init(Cipher.DECRYPT_MODE, skey, new IvParameterSpec(iv.getBytes("UTF8")));        
	        return new String(cipher.doFinal(fromHexString(cipherText)));
	        
	    } catch (BadPaddingException | IllegalBlockSizeException | UnsupportedEncodingException 
			| InvalidAlgorithmParameterException | InvalidKeyException | NoSuchAlgorithmException 
				| NoSuchPaddingException | NoSuchProviderException ex) {
	       ex.printStackTrace();
	    }	    
	    return null;
	}
	
	public static byte[] fromHexString(String s) {
	    int len = s.length();
	    byte[] data = new byte[len / 2];
	    for (int i = 0; i < len; i += 2) {
	        data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i+1), 16));
	    }
	    return data;
	}

	
}
