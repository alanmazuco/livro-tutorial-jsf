package br.eti.amazu.component.pworld.persistence.exception;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class MailException extends Exception {
	private static final long serialVersionUID = 1L;

	public MailException(String message) {
		super(message);
	}
}

