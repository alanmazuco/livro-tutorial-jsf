package br.eti.amazu.blankapp.view.bean.showcase;

import javax.ejb.Asynchronous;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import br.eti.amazu.blankapp.persistence.facade.IAppMailFacade;
import br.eti.amazu.component.pworld.persistence.exception.MailException;

@Named
@RequestScoped
public class EmailCaseBean {

	@Inject
	IAppMailFacade appMailFacade;
   
	/* Metodo Assincrono para que a aplicacao 
	 * continue normalmente sem ficar bloqueada
	 * ateh que o email seja enviado*/
    @Asynchronous  
    public void sendEmail() {

    	try {appMailFacade.sendMail(
    				"user@bol.com.br", //........... from (obrigatorio ser o mesmo usuario de FTP, para smtp.bol.com.br)
    				"destinatario@***.com", //.......to
    				"Teste - BlankApp", //...........subject
    				"Isto � um teste.", //...........body (o corpo da mensagem)
    				null //poderia aqui enviar uma lista 
    				       //(ArrayList) de string contendo 
    				       //caminhos completos de arquivos anexos - para envio de anexos)
    			);
    		
		} catch (MailException e) {			
			e.printStackTrace();
			
		} catch (Exception e) {			
			e.printStackTrace();
		} 
    }
}

