package br.eti.amazu.blankapp.domain.brasil;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity (name="Bairro")
@Table (schema="PWORLD", name = "BAIRRO")
public class Bairro{
	
	@Id
	@Column (name="ID_BAIRRO")
	private Long id;
	
	@Column(name = "NOME_BAIRRO",
			columnDefinition = "CHARACTER VARYING(70)")
	private String nome;	
		
	@OneToMany(			
		targetEntity=Logradouro.class,
		mappedBy="bairro",
		fetch = FetchType.LAZY
	)
	private Set<Bairro> logradouros;
	
	@ManyToOne(
		targetEntity = Cidade.class,		
		fetch = FetchType.EAGER 
	)
	@JoinColumn(name="ID_CIDADE", foreignKey= @ForeignKey(name = "BAIRRO_CIDADE_FK"))
	private Cidade cidade;
	
	
	/*--------
	 * get/set
	 ---------*/
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}	
	public Cidade getCidade() {
		return cidade;
	}
	public void setCidade(Cidade cidade) {
		this.cidade = cidade;
	}	
	public Set<Bairro> getLogradouros() {
		return logradouros;
	}
	public void setLogradouros(Set<Bairro> logradouros) {
		this.logradouros = logradouros;
	}
	
}
