package br.eti.amazu.blankapp.persistence;

public enum SqlRepository {
		
	//UC - Manter o Cadastro de Pessoas ======================
	RECUPERAR_CIDADE_UF_DA_PESSOA (recuperarCidadeUfPessoa()),	
	RECUPERAR_ENDERECO__PELO_CEP (recuperarEnderecoPeloCep()),
	VERIFICAR_UK_EMAIL_EMPRESA(verificarUKEmailEmpresa()),
	RECUPERAR_QUANTIDADE_USUARIOS_DEV (recuperarQuantUsuarioDev())	
	//===========================================================	
	;
	
	private String sql;
	
	//Construtor
	SqlRepository(String sql) {
		this.sql = sql;
	}
	
	static String recuperarEnderecoPeloCep() {
		StringBuffer buff = new StringBuffer();
		buff.append("SELECT * FROM PWORLD.LOGRADOURO WHERE CEP=:param0");		
		return buff.toString();
	}
	
	static String recuperarCidadeUfPessoa() {
		StringBuffer buff = new StringBuffer();
		buff.append("SELECT CIDADE.ID_CIDADE, CIDADE.NOME_CIDADE, CIDADE.ID_UF ");
		buff.append("FROM PWORLD.CIDADE INNER JOIN PWORLD.UF ON PWORLD.CIDADE.ID_UF = PWORLD.UF.ID_UF ");
		buff.append("WHERE PWORLD.CIDADE.NOME_CIDADE =:param0 ");
		buff.append("AND PWORLD.UF.SIGLA =:param1 ORDER BY CIDADE.NOME_CIDADE");
		return buff.toString();
	}
	
	static String verificarUKEmailEmpresa() {
		StringBuffer buff = new StringBuffer();
		buff.append("SELECT COUNT(ID_PESSOA) FROM PWORLD.PESSOA WHERE EMAIL =:param0 AND ID_EMPRESA =:param1");		
		return buff.toString();
	}
	
	static String recuperarQuantUsuarioDev() {
		StringBuffer buff = new StringBuffer();
		buff.append("SELECT COUNT(*) FROM PWORLD.USUARIO_PERFIL WHERE ID_PERFIL = 1");		
		return buff.toString();
	}
	
	/*--------
	 * get/set
	 ---------*/
	public String getSql() {		
		return sql;
	}	
}
