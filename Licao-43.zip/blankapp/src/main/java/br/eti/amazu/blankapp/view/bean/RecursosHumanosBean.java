package br.eti.amazu.blankapp.view.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;
import br.eti.amazu.blankapp.domain.brasil.Cidade;
import br.eti.amazu.blankapp.domain.brasil.Logradouro;
import br.eti.amazu.blankapp.domain.brasil.Uf;
import br.eti.amazu.blankapp.domain.infra.Empresa;
import br.eti.amazu.blankapp.domain.infra.Perfil;
import br.eti.amazu.blankapp.domain.infra.Pessoa;
import br.eti.amazu.blankapp.domain.infra.Usuario;
import br.eti.amazu.blankapp.persistence.SqlRepository;
import br.eti.amazu.blankapp.persistence.facade.IAppFacade;
import br.eti.amazu.blankapp.view.bean.common.UserSessionInBean;
import br.eti.amazu.blankapp.view.util.PessoaLazyList;
import br.eti.amazu.component.dialog.DialogBean;
import br.eti.amazu.component.dialog.DialogType;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.component.pworld.util.CompoundMenu;
import br.eti.amazu.component.upload.Upload;
import br.eti.amazu.component.upload.UploadMode;
import br.eti.amazu.util.DateUtil;
import br.eti.amazu.util.FacesUtil;
import br.eti.amazu.util.RegexUtil;

@Named
@ViewScoped
public class RecursosHumanosBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Inject
	DialogBean dialogBean;
	
	@Inject
	UserSessionInBean userSessionInBean;
	
	@Inject
	IAppFacade<Pessoa> pessoaFacade;
	
	@Inject
	IAppFacade<Usuario> usuarioFacade;
	
	@Inject
	IAppFacade<Perfil> perfilFacade;
	
	@Inject
	IAppFacade<Empresa> empresaFacade;
	
	@Inject
	IAppFacade<Uf> ufFacade;
	
	@Inject
	IAppFacade<Cidade> cidadeFacade;
	
	@Inject
	IAppFacade<Logradouro> logradouroFacade;
	
	@Inject
	IAppFacade<Long> longFacade;
	
	/* ********************************
	 * UC MANTER O CADASTRAO DE PESSOAS
	 *********************************/
	private PessoaLazyList pessoas;
	String paramConsulta;
	
	/* modoConsulta = "listarTodos" ------> consulta serah listar todos os registros.
	 * modoConsulta = "nome" -------------> consulta serah uma pesquisa por nome.
	 * modoConsulta = "dataNas------------> consulta serah uma pesquisa por data nascimento */
	String modoConsulta = "listarTodos"; //listarTodos eh o modo default.
	
	private Pessoa pessoa;	
	private String nomeLocalizar;
	private Date dataNascLocalizar;
	private List<Empresa> empresas;	
	private Long selectedIdEmpresa;
	Empresa empresa;
	private Uf uf;
	private List<Uf> ufs;
	private Long selectedIdUf;
	private Cidade cidade;
	private List<Cidade> cidades;	
	private Long selectedIdCidade;	
	private String cep; //Campos de busca nao devem ser atrelados ao dominio.
	
	byte[] oldFoto;	
	private Integer index;
	
	@CompoundMenu
	public void iniciarManterCadPes(){
		FacesUtil.resetBeans (null);
		FacesUtil.redirect("/pages/adm/recursosHumanos/cadastroPessoas/pessoas");
	}
	
	//Listar pessoas (realiza paginacao)
	public PessoaLazyList getPessoas() {     					
		if(pessoas == null){    			
            pessoas = new PessoaLazyList(pessoaFacade, 
            		userSessionInBean.isUsuarioDevLogado() == true ? true : false, modoConsulta, paramConsulta);            
        }    	    	
        return pessoas;
    }
	
	public void listarTodos(){
		modoConsulta = "listarTodos";
		paramConsulta = null;
		nomeLocalizar = null;
		dataNascLocalizar = null;	
			
		pessoas = new PessoaLazyList(	pessoaFacade, 
				userSessionInBean.isUsuarioDevLogado() == true ? true : false, modoConsulta, paramConsulta); 
		
		RequestContext context = RequestContext.getCurrentInstance();
		context.update("formPessoas:tablePessoas");
	}
	
	public void localizar(){
		
		//localizar por nome, por data de nascimento
		if(nomeLocalizar == null || nomeLocalizar.trim().length() == 0  && dataNascLocalizar == null){
			
			//se nao digitou um filtro...
			dialogBean.addMessage(FacesUtil.getMessage("MPS020"), DialogType.ERROR);
			return;
		}	
		
		//se digitou os dois filtros...		
		if((nomeLocalizar != null  && nomeLocalizar.trim().length() > 0)  && dataNascLocalizar != null){			
			dialogBean.addMessage(FacesUtil.getMessage("MPS021"), DialogType.ERROR);
			return;
		}
		
		modoConsulta = "listarTodos"; //default;
		
		//se digitou o filtro nomeLocalizar...		
		if(nomeLocalizar != null && nomeLocalizar.trim().length() > 0) 	{
			modoConsulta = "nome";
			paramConsulta = nomeLocalizar;
		}
		
		//se digitou o filtro dataNascLocalizar...
		if(dataNascLocalizar != null) {
			modoConsulta = "dataNasc";				
			paramConsulta = DateUtil.getStringDate(dataNascLocalizar);
		}		
		pessoas = null;		
		RequestContext context = RequestContext.getCurrentInstance();
		context.execute("PF('dlgLocalizar').hide();");
		context.update("formPessoas:tablePessoas");
	}
	
	public void openDlgPessoa(Pessoa pessoa){
		
		try {			
			//popular a lista de empresas, de acordo com o usuario logado (traz a empresa do usuario logado)
			if(empresas == null) {
				if(userSessionInBean.isUsuarioDevLogado()) {
					empresas = empresaFacade.listar("Empresa.all"); //Util apenas ao usuario dev
					
				}else {
					empresas = new ArrayList<Empresa>();
					empresas.add(userSessionInBean.getEmpresa());					
				}
			}				
			
			List<Object> params = new ArrayList<Object>();
			
			//assegurando que upload em userSessionInBean esteja a estado inicial...
			if(userSessionInBean.getUpload() != null) userSessionInBean.getUpload().reset();
			
			//Popula a combo uf, para todos os casos.
			if(ufs == null || ufs.isEmpty()){
				params.clear();
				params.add(55L); //id do Brasil
				ufs = ufFacade.listar("Uf.porPais", params);
			}
			
			if(pessoa == null) {				
				pessoa = new Pessoa();
				this.pessoa = pessoa;				
				uf = null;
				selectedIdCidade = null;
				cidade = null;
				selectedIdUf = null;
				cep = null;				
				userSessionInBean.setFoto(null);
				
			}else{				
				index = Integer.valueOf(FacesUtil.getParam("index")); //pegando o index da view
				
				//Seta variaveis...		
				this.pessoa = pessoa;
				cep = this.pessoa.getCep();	
				oldFoto = this.pessoa.getFoto();
				
				userSessionInBean.setFoto(pessoa.getFoto());
				
				//Recuperando cidade e uf baseado na cidade/uf da pessoa.
				if(this.pessoa.getCidade() != null && this.pessoa.getUf() != null){
					params.clear();
					params.add(this.pessoa.getCidade());
					params.add(this.pessoa.getUf());										
					cidade = cidadeFacade.recuperarNQ(new Cidade(),SqlRepository.RECUPERAR_CIDADE_UF_DA_PESSOA.getSql(), params);	
					
					if(cidade !=null){
						selectedIdCidade = cidade.getId();
						uf = cidade.getUf();
						selectedIdUf = uf.getId();
						
						//Populando os itens da combo cmbCidade, baseado na uf de pessoa.
						params.clear();
						params.add(uf.getId());
						cidades = cidadeFacade.listar("Cidade.porUf", params);
					}
				}				
			}			
			//Defalt eh a empresa do usuario logado.
			selectedIdEmpresa = userSessionInBean.getEmpresa().getId(); 
			empresa = userSessionInBean.getEmpresa();
			this.pessoa.setEmpresa(empresa);
									
			//Abre o dialog de inclusao/alteracao de novo perfil.
			RequestContext request = RequestContext.getCurrentInstance();
			request.update("formPessoa");
			
			request.execute("PF('dlgPessoa').show()");
		
		} catch (DaoException e) {				
			e.printStackTrace();
		}
	}
	
	//Inicializa o componente Upload em modo DATABASE.
	public void chamarUpload(){		
		
		//se a imagem for maior que 113 x 85 pixels, o upload nao serah feito.
		userSessionInBean.setScImage(null);		

		userSessionInBean.setUpload(new Upload(
				dialogBean, 				
				UploadMode.IMAGE_DATABASE, 
				null,//FacesUtil.getFullPath("/resources/temp"), 
				null, 
				113, //tamanho de 113 pixels (altura de uma foto 3x4)
				85, //tamanho de 85 pixels (largura de uma foro 3x4)
				null, null, 	false));
	}
	
	public void cancelarEditar(){
		this.resetImage();
		pessoa.setFoto(oldFoto);			
		RequestContext request = RequestContext.getCurrentInstance();			
		request.execute("PF('dlgPessoa').hide()");
	}
	
	public void setarUf(AjaxBehaviorEvent event){	
		
		/* Este metodo ocorre sempre quando o usuario clica na cmbUf.
		 * Recupera a uf (o entityManager soh entra em acao caso nao haja uma uf managed).
		 * O selectedIdUf eh extremamente importante ser setado nesta etapa, ele
		 * irah propiciar o preenchimento dos itens dentro da cmbCidade.*/
		try {
			Map<String, Object> map = event.getComponent().getAttributes();			
			
			if( map.get("value") != null && (Long) map.get("value") != 0){
				uf = ufFacade.recuperar(Uf.class, (Long) map.get("value"));
				selectedIdUf = uf.getId();
				cidades = uf.getCidades().stream().collect(Collectors.toList());
				
			}else{
				cidades = new ArrayList<Cidade>();
			}
			
		} catch (DaoException e) {
			dialogBean.addMessage(e.getMessage(), DialogType.ERROR);
		}	
	}
	
	public void setarCidade(AjaxBehaviorEvent event){		
		
		/* Este metodo ocorre sempre quando o usuario clica na cmbCidade.
		 * Recupera a uf (o entityManager soh entra em acao caso nao haja uma cidade managed).
		 * O selectedIdCidade eh importante ser setado nesta etapa, ele
		 * irah propiciar o preenchimento do valor setado na cmbCidade.*/				
		try {
			
			Map<String, Object> map = event.getComponent().getAttributes();
			if( map.get("value") != null && (Long) map.get("value") != 0){
				cidade= cidadeFacade.recuperar(Cidade.class, (Long) map.get("value"));			
				selectedIdCidade = cidade.getId();
			}
			
		} catch (DaoException e) {
			dialogBean.addMessage(e.getMessage(), DialogType.ERROR);
		}
	}
	
	public void setarEmpresa(AjaxBehaviorEvent event){	
		
		/* Este metodo ocorre sempre quando o usuario dev clica na cmbEmpresa.*/
		try {
			Map<String, Object> map = event.getComponent().getAttributes();			
			
			if( map.get("value") != null && (Long) map.get("value") != 0){
				empresa = empresaFacade.recuperar(Empresa.class, (Long) map.get("value"));
				selectedIdEmpresa = empresa.getId();
								
			}else{
				cidades = new ArrayList<Cidade>();
			}
			
		} catch (DaoException e) {
			dialogBean.addMessage(e.getMessage(), DialogType.ERROR);
		}	
	}
		
	public void salvar() {		
		try{								
			//Setar uf, cidade e cep (o operador pode ter redefinido essas propriedades).			
			pessoa.setUf(uf!=null ? uf.getSigla() : null);
			pessoa.setCidade(cidade!=null ? cidade.getNome() : null);			
			pessoa.setCep(cep);
			pessoa.setEmpresa(empresa);
			
			if(userSessionInBean.getUpload() != null && userSessionInBean.getUpload().getFile() != null){				
			    byte[] b = userSessionInBean.getUpload().getImageBytes();				
				pessoa.setFoto(b);
			}
			
			//Se jah possui um mesmo email em uma mesma empresa nao salva (restricao UK_EMAIL_EMPRESA)
			if(possuiRestricaoUK_EMAIL_EMPRESA()) {
				dialogBean.addMessage(FacesUtil.getMessage("MPS025"), DialogType.INFO_CLOSABLE);
				return;
			}
	
			RequestContext context = RequestContext.getCurrentInstance();
			if(pessoa.getId() == null){
				pessoaFacade.incluir(pessoa); //inclui no BD
				pessoas.addRow(pessoa); //atualiza a view				
				
			}else{
				if(userSessionInBean.getUpload() != null && 
						userSessionInBean.getUpload().getScImage() == null) pessoa.setFoto(null);
				
				pessoa = (Pessoa) pessoaFacade.alterarAtualizar(pessoa); //altera no banco e atualiza o objeto.
				pessoas.setRow(pessoa, index); //atualiza a view				
			}
			
			//refresca imagem em userSessionInBean
			if(userSessionInBean.getUpload() != null) {
				userSessionInBean.getUpload().setScImage(null);	
				userSessionInBean.getUpload().setFile(null);
				userSessionInBean.getUpload().setImageBytes(null);
			}
			userSessionInBean.setFoto(null);
			userSessionInBean.setScImage(null);	
			
			context.execute("PF('dlgPessoa').hide()");
			context.update("formPessoas:tablePessoas");				
			dialogBean.addMessage(FacesUtil.getMessage("MGL025"), DialogType.INFO_CLOSABLE);
			
		}catch(DaoException e){		
			
			//Adiciona a mensagem vinda de DaoException
			dialogBean.addMessage(e.getMessage(), DialogType.ERROR);			
		}
	}
	
	boolean possuiRestricaoUK_EMAIL_EMPRESA() {		
		
		try {
			if(pessoa.getEmail() == null || pessoa.getEmail().equals("")) {
				return false;
			}
			
			List<Object> params = new ArrayList<Object>();
			params.add(pessoa.getEmail());
			params.add(empresa.getId());
			
			return longFacade.recuperarMaxResultNQ(
					SqlRepository.VERIFICAR_UK_EMAIL_EMPRESA.getSql(), params) >= 1 ? true: false;
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public void localizarEnderecoPeloCep(){				
		try {			
			//Aqui soh necessito de uma validacao (o campo cep nao pode ser nulo).
			if(cep == null || cep.equals("")){
				dialogBean.addMessage(FacesUtil.getMessage("MPS005"), DialogType.ERROR);
				return;
			}					
			
			//Busca o logradouro da pessoa baseado no cep.
			List<Object> params = new ArrayList<Object>();
			params.add(cep);
			
			Logradouro logradouro = logradouroFacade.recuperarNQ(new Logradouro(), 
					SqlRepository.RECUPERAR_ENDERECO__PELO_CEP.getSql(), params);
			
			//Se nao encontra o logradouro avisa e sai.
			if(logradouro == null){
				dialogBean.addMessage(FacesUtil.getMessage("MPS004"), DialogType.INFO_CLOSABLE);
				return;
			}
			
			/* Quando encontra o logradouro, encontra tambem:
			 * - A cidade;
			 * - Seta o id da cidade, forcando a renderizacao na cmbCidade;
			 * - A uf;
			 * - Seta o id da uf, forcando a renderizacao na cmbUf;
			 * - Obtem a lista de cidades da uf para popular os itens da cmbCidade;
			 * - Seta os dados do endereco localizado na pessoa que se estah editando. */
			
			cidade = logradouro.getBairro().getCidade();
			selectedIdCidade = cidade.getId();
			uf = cidade.getUf();
			selectedIdUf = uf.getId();
			cidades = uf.getCidades().stream().collect(Collectors.toList());			
			pessoa.setCep(cep);
			pessoa.setLogradouro(logradouro.getNome());
			pessoa.setBairro(logradouro.getBairro().getNome());
			pessoa.setCidade(cidade.getNome());			
			pessoa.setUf(uf.getSigla());
						
		} catch (DaoException e) {			
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
		}
	}
	
	public void confirmarExcluirPessoa(){					
		
		try {
			/* As instrucoes abaixo evitam a LazyInitializationException.
			 * Colocando pessoa em estado "managed" (isto pode ser necessario, caso o objeto esteja detach)
			 * Colocando os perfis do usuario em usuario (porque a sessao estende demais)*/
			pessoa = (Pessoa) pessoaFacade.recuperar(Pessoa.class, pessoa.getId());			
			List<Object> params = new ArrayList<Object>();
			if(pessoa.getUsuario() != null) {
				params.add(pessoa.getUsuario().getId());	
				
				pessoa.getUsuario().setPerfis(
						perfilFacade.listar("Perfil.porUsuario", params).stream().collect(Collectors.toSet()));
			}//------------------------------------------------------------------------------------------------
							
			//Unica restricao (se nao eh um dev logado, nao pode excluir um dev ou o adm)
			if(!userSessionInBean.isUsuarioDevLogado()) {//======>se nao eh um dev logado...				
				if	(pessoa.getUsuario() != null 
						&& (
								containsPerfil(pessoa.getUsuario().getPerfis(), 1L) //=====>se a pessoa a excluir eh dev
								|| containsPerfil(pessoa.getUsuario().getPerfis(), 2L) //==>ou se eh admim
							)
					){
					dialogBean.addMessage(FacesUtil.getMessage("MGL059"), DialogType.WARN);//==>nao deixa excluir
					return; //==>nao deixa excluir
				}
				
			}else {
				
				/* se o usuario eh um desenvolvedor, nao deixa excluir se existe apenas um usuario dev no cadastro.
				 * desde que esteja excluindo um usuario desenvolvedor */
				if(pessoa.getUsuario() != null && containsPerfil(pessoa.getUsuario().getPerfis(), 1L)) {
					int quantDev = quantUsuarioDev();
					if(quantDev <= 1) {
						dialogBean.addMessage(FacesUtil.getMessage("MPS023"), DialogType.WARN);//==>nao deixa excluir
						return; //==>nao deixa excluir
						
					}else {			
						
						dialogBean.addConfirmWarnMessage(FacesUtil.getMessage("MPS024", 
								new String[]{String.valueOf(quantDev)}), 
								"recursosHumanosBean.excluirPessoa", null, null);
						return;
					}				
				}
			}		
			
			dialogBean.addConfirmWarnMessage(FacesUtil.getMessage("MGL028"), 
					"recursosHumanosBean.excluirPessoa", null, null);
		
		} catch (DaoException e1) {
			e1.printStackTrace();
		}
		
	}

	public void excluirPessoa(){
		
		/* Regra: "ao excluir uma pessoa, apaga tambem o usuario respectivo e seus dependentes.
		 * Como existem fortes restricoes, a estrutura abaixo eh fortemente recomendada, 
		 * na sequencia em que se apresenta.
		 * Lembrando que isto conduz a uma exclusao imediata, portanto a regra deve ser repensada.*/
		try {			
			//Desassocia usuario de perfis e pessoa de usuario
			if(pessoa.getUsuario() != null) {
				pessoa.getUsuario().setPerfis(null);
				usuarioFacade.alterar(pessoa.getUsuario());				
				//Dessasocia pessoa de usuario e exclui usuario		
				pessoa.setUsuario(null);
				pessoaFacade.alterar(pessoa);
			}

			//Remove a pessoa da empresa e consequentemente a pessoa no banco de dados.
			Empresa empresa = empresaFacade.recuperar(Empresa.class, pessoa.getEmpresa().getId());
			empresa.getPessoas().remove(pessoa);
			empresaFacade.alterar(empresa);
			//atualiza a view
			pessoas.removeRow(pessoa); 			
			RequestContext context = RequestContext.getCurrentInstance();
			context.update("formPessoas:tablePessoas");			
			dialogBean.addMessage(FacesUtil.getMessage("MGL029"), DialogType.INFO_CLOSABLE);
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}
	
	//Este metodo possibilita dar um update apenas na linha da tabela pessoa.
	public void updateRow() {		
		FacesContext ctx = FacesContext.getCurrentInstance();		
		DataTable dataTable = (DataTable) ctx.getViewRoot().findComponent("formPessoas:tablePessoas");					
		RequestContext.getCurrentInstance().update(dataTable.getClientId(ctx)+ ":" + index + ":pnlNome");
		RequestContext.getCurrentInstance().update(dataTable.getClientId(ctx)+ ":" + index + ":pnlDataNasc");
		RequestContext.getCurrentInstance().update(dataTable.getClientId(ctx)+ ":" + index + ":pnlAcoes");
	}
	
	
	public void resetImage(){
		pessoa.setFoto(null);
		if(userSessionInBean.getUpload() != null) {
			userSessionInBean.getUpload().setScImage(null);	
			userSessionInBean.getUpload().setFile(null);
		}
		userSessionInBean.setScImage(null);		
		userSessionInBean.setFoto(null);	
	}
	
	public void excluirFoto(){
		pessoa.setFoto(null);
		if(userSessionInBean.getUpload() != null) {
			userSessionInBean.getUpload().setScImage(null);	
			userSessionInBean.getUpload().setFile(null);
		}
		userSessionInBean.setScImage(null);		
		userSessionInBean.setFoto(null);
	}
	/* ***************************************
	 * FIM DO UC MANTER O CADASTRAO DE PESSOAS
	 ****************************************/
	
	public String getLimitCharNotBlankSpace() {		
		return RegexUtil.getLimitCharNotBlankSpace(); //Tratamentode strings - limitacoes
	}
	
	boolean containsPerfil(Set<Perfil> perfis, Long idPerfil) {
		for(Perfil perfil:perfis) {
			if(idPerfil == perfil.getId()) {
				return true;
			}
		}
		return false;
	}
	
	Integer quantUsuarioDev() {
		
		//melhor buscar no BD...		
		try {
			return usuarioFacade.recuperarMaxResultNQ(SqlRepository.RECUPERAR_QUANTIDADE_USUARIOS_DEV.getSql());
			
		} catch (DaoException e) {			
			e.printStackTrace();
		}
		return null;
	}
	
	
	/*--------
	 * get/set
	 -------*/
	public void setPessoas(PessoaLazyList pessoas) {
		this.pessoas = pessoas;
	}
	public Pessoa getPessoa() {
		return pessoa;
	}
	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}
	public String getNomeLocalizar() {
		return nomeLocalizar;
	}
	public void setNomeLocalizar(String nomeLocalizar) {
		this.nomeLocalizar = nomeLocalizar;
	}
	public Date getDataNascLocalizar() {
		return dataNascLocalizar;
	}
	public void setDataNascLocalizar(Date dataNascLocalizar) {
		this.dataNascLocalizar = dataNascLocalizar;
	}
	public List<Empresa> getEmpresas() {
		return empresas;
	}
	public void setEmpresas(List<Empresa> empresas) {
		this.empresas = empresas;
	}
	public Long getSelectedIdEmpresa() {
		return selectedIdEmpresa;
	}
	public void setSelectedIdEmpresa(Long selectedIdEmpresa) {
		this.selectedIdEmpresa = selectedIdEmpresa;
	}
	public Uf getUf() {
		return uf;
	}
	public void setUf(Uf uf) {
		this.uf = uf;
	}
	public List<Uf> getUfs() {
		return ufs;
	}
	public void setUfs(List<Uf> ufs) {
		this.ufs = ufs;
	}
	public Long getSelectedIdUf() {
		return selectedIdUf;
	}
	public void setSelectedIdUf(Long selectedIdUf) {
		this.selectedIdUf = selectedIdUf;
	}
	public Cidade getCidade() {
		return cidade;
	}
	public void setCidade(Cidade cidade) {
		this.cidade = cidade;
	}
	public List<Cidade> getCidades() {
		return cidades;
	}
	public void setCidades(List<Cidade> cidades) {
		this.cidades = cidades;
	}
	public Long getSelectedIdCidade() {
		return selectedIdCidade;
	}
	public void setSelectedIdCidade(Long selectedIdCidade) {
		this.selectedIdCidade = selectedIdCidade;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
}
