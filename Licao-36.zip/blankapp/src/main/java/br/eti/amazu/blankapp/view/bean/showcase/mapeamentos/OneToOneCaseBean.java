package br.eti.amazu.blankapp.view.bean.showcase.mapeamentos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.log4j.Level;

import br.eti.amazu.blankapp.domain.infra.Empresa;
import br.eti.amazu.blankapp.domain.infra.Pessoa;
import br.eti.amazu.blankapp.domain.infra.Usuario;
import br.eti.amazu.blankapp.persistence.facade.IAppFacade;
import br.eti.amazu.blankapp.view.util.DomainObjectTest;
import br.eti.amazu.blankapp.view.util.FormatTest;
import br.eti.amazu.component.dialog.DialogBean;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.util.DateUtil;
import br.eti.amazu.util.log.Ansi;
import br.eti.amazu.util.log.Log;

@Named
@RequestScoped
public class OneToOneCaseBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Inject
	IAppFacade<Pessoa> pessoaFacade;
	
	@Inject
	IAppFacade<Usuario> usuarioFacade;
	
	@Inject
	DialogBean dialogBean;
	
	//LICAO 30 EM DIANTE
	@Inject
	IAppFacade<Empresa> empresaFacade;
		
	/* --------------------------------------------------
	 *  EXPERIMENTO 06 - Incluir somente na tabela PESSOA
	 ---------------------------------------------------*/
	// Simples inclusao. Se repetir o teste, mude os dados da pessoa...
	public void incluirPessoa(){
		
		FormatTest.printHeader("ONE TO ONE", "Experimento 06 - Incluir somente na tabela pessoa");		
		
		try {			
			Pessoa pessoa = DomainObjectTest.getPessoa(empresaFacade);
			pessoa.setNome("Pedro Manoel Silva da Silva");
			
			pessoaFacade.incluir(pessoa);
			
			Log.setLogger("", "incluiu " + pessoa.getNome().toUpperCase() + " com sucesso!", 
						Level.INFO,  Ansi.BLUE);
			
			FormatTest.printFooter();
				
		} catch (DaoException e) {
			e.printStackTrace();
		}			
	}
	
	/* -------------------------------------------
	 *  EXPERIMENTO 07 - Associar usuario a pessoa
	 -------------------------------------------*/
	/* Aqui a ideia eh inserir um registro apenas na tabela USUARIO. Como esta tabela (USUARIO) possui 
    * uma <pk><fk>, exigirah a existencia de um registro correspondente na tabela PESSOA. A estrategia 
    * eh buscar esse registro primeiro e, antes de fazer as associacoes, verificar se essa pessoa jah possui 
    * um usuario. Se possuir, a associacao poderah ser feita.*/
	public void associarUsuario(){		
		FormatTest.printHeader("ONE TO ONE", "Experimento 07 - Associar Usu�rio");
		
		try {			
			//Recupero a primeira pessoa da lista
			Pessoa pessoa = this.getPessoa();
			
			//Verifico se pessoa estah nula, se tiver, loga e sai...
			if(pessoa == null){
				
				//A pessoa estah nula (tabela nao possui registros)
				Log.setLogger("", "N�o encontrou pessoas na tabela.", Level.INFO, Ansi.RED);
				FormatTest.printFooter();
				return;
			}
			
			// Daqui para baixo, pessoa estah OK, posso alterar os seus dados.  Vou alterar o usuario...
			if(pessoa.getUsuario() != null){ //Verifico se a pessoa jah nao tem um usuario.
				
				//A pessoa tem um usuario, apenas loga.
				Log.setLogger("", "A pessoa " + pessoa.getNome().toUpperCase() + 
						" j� possui um usu�rio associado.",  Level.INFO, Ansi.RED);			
				
			}else{		
				//A pessoa nao tem um usuario - vai associar e inserir um.
				Usuario usuario = DomainObjectTest.getUsuario(); // Obtem novo usuario.
				usuario.setPessoa(pessoa); // Associa o novo usuario com pessoa.
				pessoa.setUsuario(usuario); // Associa a pessoa com o novo usuario.
				
				// Inclui o novo usuario associado a pessoa. Isto grava um registro na tabela USUARIO.
				usuarioFacade.incluir(usuario);
				
				Log.setLogger("", "Incluiu um novo usuario e o associou a " + pessoa.getNome().toUpperCase(), 
						Level.INFO, Ansi.RED);
			}
			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			
			/* Ao tentar alterar um usuario com um nome de usuario jah existente, ocorre a exception.
			 * Neste caso, o usuario nao serah alterado. */
			Log.setLogger("", "N�o foi poss�vel efetuar a opera��o.", Level.INFO, Ansi.RED_BOLD_YELLOWBG);						
			e.printStackTrace();
		}
	}

	/* -----------------------------------------------------
	 *  EXPERIMENTO 08 - Incluir pessoa e usuario em cascata
	 ------------------------------------------------------*/
	/* Aqui a ideia eh inserir um registro na tabela PESSOA e outro na
	* tabela USUARIO, ao mesmo tempo, persistindo em cima do objeto pessoa.*/
	public void incluirCascata(){
		
		FormatTest.printHeader("ONE TO ONE", "Experimento 08 - Incluir Pessoa e Usu�rio em cascata");
		
		try {			

			//Crio um objeto pessoa.
			Pessoa pessoa = DomainObjectTest.getPessoa(empresaFacade); //nesse instante, pessoa estah "new".
			pessoa.setNome("Maria da Silva"); //Um nome, apenas para diferenciar...
			
			//Crio um objeto pessoa.
			Usuario usuario = DomainObjectTest.getUsuario(); //nesse instante, usuario estah "new".
			usuario.setNomeUsuario("maria"); //Um nome de usuario, evitando o erro da chave unica...
			
			//Associando usuario a pessoa...
			pessoa.setUsuario(usuario);
			usuario.setPessoa(pessoa);
			
			//Incluindo pessoa (nesse instante, usuario tambem serah incluso, em cascata).
			pessoaFacade.incluir(pessoa);
			
			Log.setLogger("", "Incluiu pessoa e usu�rio, concomitantemente", Level.INFO, Ansi.BLUE);
			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			
			//Ao tentar incluir pela segunda vez, sem mudar o nome de usuario, ocorre a exception.
			Log.setLogger("", "N�o pode incluir nome de usu�rio duplicado.",
					Level.INFO, Ansi.RED_BOLD_YELLOWBG);
			
			e.printStackTrace();
		}

	}
	
	/* -----------------------------------
	 *  EXPERIMENTO 09 - Update em cascata
	 ------------------------------------*/
	public void updateCascata(){
		
		FormatTest.printHeader("ONE TO ONE", "Experimento 09 - Update em cascata");
		
		try {
			
			/* Inicialmente,  recupero um registro de pessoa (que pode ou nao conter um usuario).
			* A ideia aqui eh alterar os dados de pessoa e usuario, caso a pessoa possua mesmo um usuario.
			* O update pode ser feito em cima de pessoa, o efeito serah em cascata. */					
			Pessoa pessoa = this.getPessoa(); //Recupero a primeira pessoa da lista
			
			//Verifico se pessoa estah nula, se tiver, loga e sai...
			if(pessoa == null){
				
				//A pessoa estah nula (tabela nao possui registros)
				Log.setLogger("", "N�o encontrou pessoas na tabela.", Level.INFO, Ansi.RED);
				FormatTest.printFooter();
				return;
			}
			
			/* Daqui para baixo, pessoa estah OK, posso alterar os seus dados. Vou alterar o nome... */
			pessoa.setNome("Joaquim Jos� da Silva Xavier");
			
			//Agora vou verificar se a pessoa possui um usuario...
			if(pessoa.getUsuario() != null){ 
				
				//Aqui a pessoa tem usuario, vou alterar seu nome de usuario...
				pessoa.getUsuario().setNomeUsuario("tiradentes");
				pessoaFacade.alterar(pessoa); //Altera os dados nas duas tabelas.
				
				Log.setLogger("", "Opera��o efetuada com sucesso.", Level.INFO, Ansi.BLUE);
				
			}else{
				
				//Aqui a pessoa nao possui usuario, informo que nao foi possivel alterar, aviso isto...
				Log.setLogger("", 
						"Alterou apenas o nome da pessoa, pois a mesma n�o possu�a um usu�rio associado.",
								Level.INFO, Ansi.BLUE);
			}			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			
			/* Ao tentar alterar um usuario com um nome de usuario jah existente, ocorre a exception.
			 * Neste caso, nem pessoa, nem usuario serao alterados, pois as operacoes estao ocorrendo
			 * dentro de uma transacao. */
			Log.setLogger("", "N�o foi poss�vel efetuar a opera��o.", Level.INFO, Ansi.RED_BOLD_YELLOWBG);			
			e.printStackTrace();
		}
	}
	
	/* --------------------------------------
	 *  EXPERIMENTO 10 - Exclus�o de  usuario
	 ---------------------------------------*/
	public void  excluirUsuario(){
		
		FormatTest.printHeader("ONE TO ONE", "Experimento 10 - Exclus�o de Usu�rio");
		
		try {
			
			/*Soh funciona se gerenciar o objeto a ser excluido (mesma regra do update).
			 * Entao, primeiramente, busco a pessoa que quero excluir...
			 * /
			
			/* Recupero a primeira pessoa da lista que possui um usuario.
			 * Poderia recuperar qualquer uma, utilizo a primeira por mero acaso.
			 */
			Pessoa pessoa = this.getPessoaComUsuario();
			
			//Verifico se pessoa estah nula, se tiver, loga e sai...
			if(pessoa == null){
				
				//A pessoa estah nula (tabela nao possui registros)
				Log.setLogger("", "N�o encontrou pessoas na tabela.", Level.INFO, Ansi.RED);
				FormatTest.printFooter();
				return;
			}
			
			//Dessassocia o usuario de pessoa.
			pessoa.setUsuario(null);
			
			//Gravo a operacao (nesse instante o usuario associado serah excluido da tabela).
			pessoaFacade.alterar(pessoa);
			
			//Tudo OK, loga e sai.
			Log.setLogger("", "Opera��o efetuada com sucesso.", Level.INFO, Ansi.BLUE);						
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			e.printStackTrace();
		}		
	}
	
	/* -------------------------------------
	 *  EXPERIMENTO 11 - Exclus�o em cascata
	 --------------------------------------*/
	public void  excluirCascata(){		
		FormatTest.printHeader("ONE TO ONE", "Experimento 11 - Exclus�o em cascata");
		
		try {			
			//Soh funciona se gerenciar o objeto a ser excluido (mesma regra do update).
			Pessoa pessoa = this.getPessoaComUsuario(); //Entao, busco a pessoa que quero excluir... 
			
			if(pessoa == null){ //Verifico se pessoa estah nula, se tiver, loga e sai...
				
				//A pessoa estah nula (tabela nao possui registros)
				Log.setLogger("", "N�o encontrou pessoas que possuam usu�rio  na tabela.", Level.INFO, Ansi.RED);
				FormatTest.printFooter();
				return;
			}			
			pessoaFacade.excluir(pessoa);  //Exclusao de  pessoa (e tambem do usuario)			
			Log.setLogger("", "Opera��o efetuada com sucesso.", Level.INFO, Ansi.BLUE);							
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}
		
	/* ------------------------------------------------------
	 *  EXPERIMENTO 12 - Inclusao na tabela 1 com NativeQuery
	 -------------------------------------------------------*/
	public void  incluirTabelaUmNativeQuery(){		
		FormatTest.printHeader("ONE TO ONE", "Experimento 12 - Inclus�o na tabela 1 com NativeQuery");
		
		try {			
			/* Inicialmente, declaro e inicializo a SQL a ser executada (no caso, eh uma SQL de inclusao).
			 * Setamos apenas os campos obrigatorios (exceto o id que serah definido pela JPA).*/	
						
			//-------------------------------------------------------------------------------------------
			//LI��O 29 - LINHAS ABAIXO COMENTADAS A PARTIR DA LICAO 30
			//String sql = "INSERT INTO PWORLD.PESSOA (ID_PESSOA, NOME, DATA_NASCIMENTO, CPF, IDT) "+
			//"VALUES(  NEXTVAL('PWORLD.PESSOA_SEQ'),   :param0, :param1, :param2, :param3)";
			//-------------------------------------------------------------------------------------------
			
			/* ---------------------------------------------------------------------------------------------------------------------------
			 * ALTERA�AO DAS LINHAS ABAIXO, A PARTIR DA LICAO 30
			 * ---------------------------------------------------------------------------------------------------------------------------------
			 * EH NECESSARIO A INCLUSAO PREVIA DE UM REGISTRO NA TABELA EMPRESA
			 * Buscando uma pessoa, apenas para trazer a empresa*/
			Pessoa pessoa = DomainObjectTest.getPessoa(empresaFacade); //nesse instante, pessoa estah "new".
			Empresa empresa = pessoa.getEmpresa(); //pegando os dados da empresa
						
			String sql = "INSERT INTO PWORLD.PESSOA (ID_PESSOA, NOME, DATA_NASCIMENTO, CPF, IDT, ID_EMPRESA) " +
 					"VALUES(  NEXTVAL('PWORLD.PESSOA_SEQ'),   :param0, :param1, :param2, :param3, :param4)";
			
			/* Lista dos parametros da SQL.*/
			List<Object> params = new ArrayList<Object>();			
			params.add("Luis Alves de Lima e Silva"); //.................NOME: O parametro zero (:param0);
			params.add(DateUtil.getDate("25/08/1803"));//.........DATA_NASCIMENTO: O parametro um (:param1)
			params.add("888.888.888-10"); //...............................CPF: O parametro dois (:param2);
			params.add("9999-XX"); //...........................................IDT: O parametro tres (:param3);
			params.add(empresa.getId()); //..................................ID_EMPRESA: LICAO 30 EM DIANTE
			
			//Chamando o EntityManager e "desatachando" pessoa e empresa (evitando gravacoes desnecessarias)
			pessoaFacade.detach(pessoa);
			empresaFacade.detach(empresa);
			//--------------------------------------------------------------------------------------------------------------------------------------
			//FIM DE ALTERA�AO DAS LINHAS ...
			//--------------------------------------------------------------------------------------------------------------------------------------
			
			
			//Executa a SQL e loga.
			pessoaFacade.executarNQ(sql, params);					
			Log.setLogger("", "Opera��o efetuada com sucesso.", Level.INFO, Ansi.BLUE);			
			FormatTest.printFooter();		
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}

	
	/* ------------------------------------------------------
	 *  EXPERIMENTO 13 - Inclus�o na tabela 2 com NativeQuery
	 ------------------------------------------------------*/
	public void  incluirTabelaDoisNativeQuery(){
		
		/*A inclusao na tabela 2 (USUARIO) pressupoe a existencia do registro correspondente na tabela 1.
		 * Inicialmente, recupera-se a pessoa pelo id, passando-o como parametro para a nativeQuery,
		 * mas lembrando que a pessoa jah foi persistida em momento anterior, visto que nao podemos
		 * inserir os dois objetos ao mesmo tempo.*/
		
		FormatTest.printHeader("ONE TO ONE", "Experimento 13 - Inclus�o na tabela 2 com NativeQuery");
		
		try {
			
			//Recupero um registro pelo nome da pessoa			
			List<Object> params = new ArrayList<Object>();
			params.add("Luis Alves de Lima e Silva"); //desejo recuperar a pessoa que tem esse CPF
			
			/*Recupero em uma lista, pois pode ser que tenha mais de uma pessoa com este nome.
			 * A estrategia ideal nao eh recuperar pelo nome, mas sim por um campo da tabela que possua
			 * chave unica (no caso de PESSOA, somente o seu id possui essa chave). 
			 * O proposito eh a realizacao do experimento... */
			List<Pessoa> pessoas = pessoaFacade.listar("Pessoa.recuperarPeloNome", params);
			
			Pessoa pessoa = null; //Dclaro e inicializo pessoa.
			
			//Se a lista de pessoas for diferente de nula e se possui pelo menos um elemento...
			if(pessoas != null  && pessoas.size()>0){
				
				/* Pego a pessoa que possui o nome "Luis Alves de Lima e Silva".
				 * Na verdade, pego o primeiro da lista (para o meu experimento, eh o que interessa) */
				pessoa = pessoas.get(0);
				
			}else{
				
				//Nao encontrou um registro, loga e sai.
				Log.setLogger("", "N�o encontrou o registro que queria.", Level.INFO, Ansi.RED);
				FormatTest.printFooter();
				return;
			}
			
			/* Declaro e inicializo a SQL a ser executada (no caso, eh uma SQL de inclusao).
			 * Desta vez seto o ID.  Perceba a presenca dos parametros 0, 1,  2, 3, 4 e 5. */
			String sql = "INSERT INTO PWORLD.USUARIO ("+
										"ID_USUARIO, "+
										"BLOQUEADO, "+
										"DATA_PRIMEIRO_ACESSO, "+
										"NOME_USUARIO, "+
										"PRIMEIRO_ACESSO, "+
										"SENHA) "+
										"VALUES (:param0, :param1, :param2, :param3, :param4, :param5)";															
			
			/* Limpo a lista de parametro, e adiciono os parametros obedecendo, rigorosamente, 
			 * a ordem da expressao SQL criada, no caso,  0, 1, 2, 3, 4  e 5. */
			params.clear();
			params.add(pessoa.getId()); //......................ID_USUARIO - :param0
			params.add("F"); //.................................BLOQUEADO - :param1;
			params.add(new Date());//...........................DATA_PRIMEIRO_ACESSO - :param2
			params.add("caxias"); //............................NOME_USUARIO - :param3
			params.add("T"); //.................................PRIMEIRO_ACESSO - :param4
			params.add("minhaSenha"); //........................SENHA - :param5
			
			pessoaFacade.executarNQ(sql, params);		//Executa a SQL.
			
			Log.setLogger("", "Opera��o efetuada com sucesso.", Level.INFO, Ansi.BLUE);			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			
			//Ao tentar incluir pela segunda vez, sem mudar o nome de usuario, ocorre a exception.
			Log.setLogger("", "N�o pode incluir nome de usu�rio duplicado.", Level.INFO, Ansi.RED_BOLD_YELLOWBG);
			
			e.printStackTrace();
		}
	}

	/* ----------------------------------------
	 *  EXPERIMENTO 14 - Update com NativeQuery
	 ----------------------------------------*/
	public void updateNativeQuery(){		
		FormatTest.printHeader("ONE TO ONE", "Experimento 14 - Update com NativeQuery");
		
		try {			
			Pessoa pessoa = this.getPessoa(); //Recupero a primeira pessoa da lista
			
			if(pessoa == null){  //Verifico se pessoa estah nula, se tiver, loga e sai...
				
				//A pessoa estah nula (tabela nao possui registros)
				Log.setLogger("", "N�o encontrou pessoas na tabela.", Level.INFO, Ansi.RED);
				FormatTest.printFooter();
				return;
			}
			
			//Declaro e inicializo a SQL a ser executada
			String sql = "UPDATE PWORLD.PESSOA SET NOME = 'Fulano de Tal Alterado'  WHERE ID_PESSOA = :param0";
			
			List<Object> params = new ArrayList<Object>(); //Declarando os parametros da operacao...
			params.add(pessoa.getId()); //desejo recuperar a pessoa que tem esse id
			
			pessoaFacade.executarNQ(sql, params);	//Executa a SQL.
			
			Log.setLogger("", "Opera��o efetuada com sucesso.", Level.INFO, Ansi.BLUE);			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}
	
	/* ------------------------------------------
	 *  EXPERIMENTO 15 - Exclus�o com NativeQuery
	 ------------------------------------------*/
	public void excluirNativeQuery(){		
		
		/* ATENCAO ESPECIAL deve ser dada a essa abordagem.
		 * A exclusao usando Native Query nao realiza exclusao em cascata.
		 * Para evitar a existencia de registros orfaos na tabela USUARIO, tem de criar no banco
		 * a chave secundaria nessa tabela, com referencia ao ID_PESSOA da tabela PESSOA. */
		
		FormatTest.printHeader("ONE TO ONE", "Experimento 15 - Exclus�o com NativeQuery");
		
		try {
			
			//Recupero a primeira pessoa da lista que possui um usuario.
			Pessoa pessoa = this.getPessoaComUsuario();
			
			//Verifico se pessoa estah nula, se tiver, loga e sai...
			if(pessoa == null){
				
				//A pessoa estah nula (tabela nao possui registros)
				Log.setLogger("", "N�o encontrou pessoas que possuam usu�rio na tabela.", Level.INFO, Ansi.RED);
				FormatTest.printFooter();
				return;
			}
			
			//Declaro e inicializo a SQL a ser executada
			String sql = "DELETE FROM PWORLD.PESSOA WHERE ID_PESSOA = :param0";
			
			//Declarando os parametros da operacao...
			List<Object> params = new ArrayList<Object>();
			params.add(pessoa.getId()); //desejo excluir a pessoa que tem esse id
			
			//Executa a SQL.
			pessoaFacade.executarNQ(sql, params);		
			
			Log.setLogger("", "Opera��o efetuada com sucesso.", Level.INFO, Ansi.BLUE);			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			e.printStackTrace();
		}

	}	
	
	/* -----------------------------------------------------
	 *  EXPERIMENTO 16 - Recuperar pelo lado 1 da associa��o
	 -----------------------------------------------------*/
	public void recuperarLadoUm(){
		
		FormatTest.printHeader("ONE TO ONE", "Experimento 16 -  Recuperar pelo lado 1 da associa��o");
		
		try {
			
			//Para este experimento, abra o PG Amin e obtenha um numero de id da pessoa a recuperar
			Pessoa pessoa = pessoaFacade.recuperar(Pessoa.class, 1L); //Recuperando a pessoa de id=1
			
			//Verifico se pessoa estah nula, se tiver, loga e sai...
			if(pessoa == null){
				
				//A pessoa estah nula (tabela nao possui registros)
				Log.setLogger("", "N�o encontrou a pessoa pesquisada:", Level.INFO, Ansi.RED);
				FormatTest.printFooter();
				return;
			}
			
			if(pessoa.getUsuario() == null){
				
				//Se a pessoa nao possui usuario...
				Log.setLogger("", "Encontrou a pessoa pesquisada:\n" +
						"- " + pessoa.getNome().toUpperCase() + ";\n" +
						"- Seu nome de usu�rio �: N�o possui usu�rio.",						
						Level.INFO, Ansi.BLUE);
				
			}else{

				//Se a pessoa possui usuario...
				Log.setLogger("", "Encontrou a pessoa pesquisada:\n" +
				"- " + pessoa.getNome().toUpperCase() + ";\n" +
				"- Seu nome de usu�rio �: " + pessoa.getUsuario().getNomeUsuario(),						
				Level.INFO, Ansi.BLUE);
			}
			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			e.printStackTrace();
		}

	}	

	/* -----------------------------------------------------
	 *  EXPERIMENTO 17 - Recuperar pelo lado 2 da associa��o
	 -----------------------------------------------------*/
	public void recuperarLadoDois(){
		
		FormatTest.printHeader("ONE TO ONE", "Experimento 17 -  Recuperar pelo lado 2 da associa��o");
		
		try {
			
			//Para este experimento, abra o PG Amin e obtenha um numero de id do usuario a recuperar
			Usuario usuario = usuarioFacade.recuperar(Usuario.class, 1L); //Recuperando o usuario de id=1
			
			//Verifico se usuaio estah null, se tiver, loga e sai...
			if(usuario == null){
				
				//O usuario estah null (tabela nao possui registros)
				Log.setLogger("", "N�o encontrou o usu�rio pesquisado:", Level.INFO, Ansi.RED);
				FormatTest.printFooter();
				return;
			}
			
			if(usuario.getPessoa() == null){
				
				//Se o usuario nao possui pessoa... (esta situacao nunca vai ocorrer usando JPA)
				Log.setLogger("", "Encontrou o usu�rio pesquisado, mas ele � um registro �rf�o, n�o possui pessoa.",								
						Level.INFO, Ansi.RED);
				
			}else{

				//Se o usuario possui  pessoa...
				Log.setLogger("", "Encontrou o usu�rio pesquisado:\n" +
				"- " +usuario.getNomeUsuario() + ";\n" +
				"- Sua pessoa �: " + usuario.getPessoa().getNome().toUpperCase(),						
				Level.INFO, Ansi.BLUE);
			}
			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}	
	
	/* -------------------------------------------
	 *  EXPERIMENTO 18 - Recuperar com NativeQuery
	 -------------------------------------------*/
	public void recuperarNativeQuery(){
		
		FormatTest.printHeader("ONE TO ONE", "Experimento 18 -  Recuperar com NativeQuery");
		
		try {

			//Declaro e inicializo a SQL a ser executada
			String sql = "SELECT a.*  FROM PWORLD.PESSOA a WHERE a. ID_PESSOA = :param0";
			
			//Declarando definindo os parametros da operacao...
			List<Object> params = new ArrayList<Object>();
			params.add(1L); //desejo recuperar a pessoa que tem esse id
			
			Pessoa pessoa = pessoaFacade.recuperarNQ(new Pessoa(), sql, params);
			
			if( pessoa==null ){
				
				//objeto pessoa pode vir nulo...
				Log.setLogger("", "N�o encontrou a pessoa pesquisada.", Level.INFO, Ansi.RED);
				
			}else{
				Log.setLogger("", "Encontrou a pessoa " + pessoa.getNome(), Level.INFO, Ansi.BLUE);
				
				//Usuario pode estar nulo...
				if( pessoa.getUsuario() == null ){
					Log.setLogger("", "A pessoa n�o possui um usu�rio associado", Level.INFO, Ansi.RED);
					
				}else{
					Log.setLogger("", "Seu usuario �: "+ pessoa.getUsuario().getNomeUsuario(), Level.INFO, Ansi.BLUE);
				}				
			}
						
			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			e.printStackTrace();
		}

	}	

	/* -------------------------------
	 *  EXPERIMENTO 19 - Pesquisa like
	 -------------------------------*/
	public void pesquisar(){
		
		FormatTest.printHeader("ONE TO ONE", "Experimento 19 -  Pesquisar registros similares (like)");
		
		try {
			/* Isto eh uma consulta SQL usando a clausula like, entao seria bom passar os parametros entre
			* curingas %, conforme a natureza daquilo que se pretende. O parametro eh submetido a um filtro
			* que retira todos os acentos. Obviamente a consulta SQL tambem terah de se valer do mesmo
			* artificio: No banco (utilizando o PGAdmin), execute a sql abaixo para criar a funcao
			* "sem_acento", cuja finalidade eh filtrar acentos (se ela nao for criada, nao serah possivel
			* rodar este teste. 
			*
			* CREATE OR REPLACE FUNCTION PWORLD.sem_acento(text) RETURNS text AS
			* $BODY$ select
			* translate($1,'��������������������������������������������',
			* 'aaaaaeeeeiiiooooouuuuAAAAAEEEEIIIOOOOOUUUUcC'); $BODY$ LANGUAGE
			* 'sql' IMMUTABLE STRICT; 
			* Se estiver utilizando ORACLE, utilize uma fun��o especifica para ele, como mostrada no
              * ap�ndice C do livro. */
			
			//Definindo os parametros da operacao...
			List<Object> params = new ArrayList<Object>();
			params.add("%maria%"); //desejo recuperar as pessoas que se chamam maria
			
			List<Pessoa> pessoas = pessoaFacade.listar("Pessoa.similarPeloNome", params);
			
			//Se a lista de pessoas for diferente de nula e se possui pelo menos um elemento...
			if(pessoas != null  && pessoas.size()>0){
				
				//A pesquisa deu resultado positivo...
				Log.setLogger("", "Encontramos as seguintes pessoas:",  	Level.INFO, Ansi.BLACK_BOLD);
				
				for(Pessoa pessoa:pessoas){
					Log.setLogger("", pessoa.getNome(), 	Level.INFO, Ansi.BLUE);
				}
				
			}else{				
				//Nao encontrou um registro, loga.
				Log.setLogger("", "N�o encontramos os registros que o Sr queria.", 	Level.INFO, Ansi.RED);			
			}
			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}	

	/* ----------------------------------
	 *  EXPERIMENTO 20 - Listar registros
	 ----------------------------------*/
	public void listar(){
		
		FormatTest.printHeader("ONE TO ONE", "Experimento 20 -  Listar registros");
		
		try {
			
			/* Buscar uma lista de pessoas, sem filtro.
			 * Na pratica, nunca faca isto, pois inviabiliza a consulta com milhares de registros.
			 * Considere ter que realizar a consulta PAGINADA */
			List<Pessoa> pessoas = pessoaFacade.listar("Pessoa.all");
							
			//Se a lista de pessoas for diferente de nula e se possui pelo menos um elemento...
			if(pessoas == null){
				
				//a lista de pessoas estah nula (tabela nao possui registros)
				Log.setLogger("", "N�o encontrou pessoas na tabela.", Level.INFO, Ansi.RED);
				FormatTest.printFooter();
				return;				
			}
						
			Log.setLogger("", "Lista de pessoas:", Level.INFO, Ansi.BLACK_BOLD);
			
			//percorrendo a lista e logando...
			for(Pessoa pessoa:pessoas){
				Log.setLogger("", pessoa.getNome().toUpperCase(), Level.INFO, Ansi.BLUE);
			}
			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}

	/* ----------------------------------------
	 *  EXPERIMENTO 21 - Listar com NativeQuery
	 ----------------------------------------*/
	public void listarNativeQuery(){
		
		FormatTest.printHeader("ONE TO ONE", "Experimento 21 -  Listar com NativeQuery");
		
		try {
			
			//Declaro e inicializo uma expressao sql
			String sql = "SELECT p.* FROM PWORLD.PESSOA p ORDER BY p.NOME";
			
			/* Buscar uma lista de pessoas, sem filtro.
			 * Na pratica, nunca faca isto, pois inviabiliza a consulta com milhares de registros.
			 * Considere ter que realizar a consulta PAGINADA */
			List<Pessoa> pessoas = pessoaFacade.listarNQ(new Pessoa(), sql);
							
			//Se a lista de pessoas for diferente de nula e se possui pelo menos um elemento...
			if(pessoas == null){
				
				//a lista de pessoas estah nula (tabela nao possui registros)
				Log.setLogger("", "N�o encontrou pessoas na tabela.", Level.INFO, Ansi.RED);
				FormatTest.printFooter();
				return;				
			}
						
			Log.setLogger("", "Lista de pessoas:", Level.INFO, Ansi.BLACK_BOLD);
			
			//percorrendo a lista e logando...
			for(Pessoa pessoa:pessoas){
				Log.setLogger("", pessoa.getNome().toUpperCase(), Level.INFO, Ansi.BLUE);
			}
			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			e.printStackTrace();
		}

	}
		
	
	/*************************************
	 *  Metodos de apoio aos experimentos:
	 ************************************/
	
	/* ------------------------------------
	 *  Retorna um objeto pessoa gerenciado.
	 -------------------------------------*/	
	Pessoa getPessoa(){
		
		try{
			//Busco todas as pessoas no banco, vou pegar a primeira linha da lista, caso ela nao venha nula.			
			List<Pessoa> pessoas = pessoaFacade.listar("Pessoa.all");
			
			//Se a lista de pessoas for diferente de nula e se possui pelo menos um elemento...
			if(pessoas != null  && pessoas.size()>0){
				
				//A ideia eh pegar a primeira pessoa da lista para fazer o teste.
				return pessoas.get(0);				 
			}
			
		} catch (DaoException e) {
			e.printStackTrace();
		}	
		
		return null; //Reorna null se acontecer um erro.
		
	}
	
	/* -------------------------------------------------
	 *  Retorna um objeto pessoa com usuario gerenciado.
	 -------------------------------------------------*/
	Pessoa getPessoaComUsuario(){
		
		try{
			//Busco todas as pessoas no banco.	
			List<Pessoa> pessoas = pessoaFacade.listar("Pessoa.all");
			
			//Se a lista de pessoas for diferente de nula e se possui pelo menos um elemento...
			if(pessoas != null  && pessoas.size()>0){
				
				//Vou pegar a primeira pessoa que possua um usuario.		
				for(Pessoa pessoa:pessoas){
					if(pessoa.getUsuario() !=null){
						return pessoa;
					}
				}				
			}
						
		} catch (DaoException e) {
			e.printStackTrace();
		}	
		
		return null; //Retorna null se acontecer um erro.		
		
	}	
}

