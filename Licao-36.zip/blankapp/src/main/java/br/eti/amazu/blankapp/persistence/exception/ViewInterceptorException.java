package br.eti.amazu.blankapp.persistence.exception;

import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

import org.apache.log4j.Level;

import br.eti.amazu.component.dialog.DialogBean;
import br.eti.amazu.component.dialog.DialogType;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.component.pworld.persistence.exception.DaoMessage;
import br.eti.amazu.component.pworld.persistence.exception.InterceptorException;
import br.eti.amazu.component.pworld.persistence.exception.MailException;
import br.eti.amazu.util.log.Ansi;
import br.eti.amazu.util.log.Log;

public class ViewInterceptorException extends InterceptorException{
	
	@Inject
	DialogBean dialogBean;
	
	public ViewInterceptorException() {
		super();	
	}
		
	@AroundInvoke
    public Object trace(InvocationContext invocationContext) throws Exception{				
        try {
            return invocationContext.proceed();    
            
        } catch (Exception t) {            	        	
        	String msg = store(t);        	
        	Log.setLogger("PWORLD-10========================>",  
        			msg, Level.ERROR, Ansi.RED_BOLD_YELLOWBG );
       	
			if(DaoMessage.getKey(msg).equals("_eMail")){
				t.printStackTrace();
				dialogBean.addMessage(msg, DialogType.ERROR);
				throw new MailException(msg);
				
			}else{
				t.printStackTrace();
				dialogBean.addMessage(msg, DialogType.ERROR);
				throw new DaoException(msg);
			}
        }
	}	
}

