package br.eti.amazu.blankapp.view.util;

import java.util.ArrayList;
import java.util.List;


public class DefaultMenuModel {

	
	// instala menus default
	public static List<String[]> setupMenus() {
				
		/* 
		 * CONSTROI A SEGUINDE ARVORE DE MENUS (default):
		 *
		 * Administracao
		 * |
		 * |--- Ferramentas
		 * |           |--- Painel de Controle
		 * |           |--- Manter Menus
		 * |           '--- Show Case
		 * |
		 * '--- Recursos Humanos
		 *             |--- Cadastro de Pessoal
		 *             |--- Cadastro de Usuarios
		 *             '--- Manter Perfis
		 *             
		 * Download
		 * 
		 * Home Page
		 * 
		 * Login
		 * 
		 * Logout
		 * 
		 * Help
		 */
					
		List<String[]> menus = new ArrayList<String[]>();
				
		menus.add(
				new String[] {
					"mm_keyLabel_administracao", // .....	[0] label
					"edit_pen.gif", // ....................	[1] icon
					"0", // ...........................	...	[2] ordem
					"1", // ...............................	[3] tipo
					"F", // ..............................	[4] visibility
					null, // ..............................	[5] metodo
					null // ...............................	[6] funcionalidade				
				}
		);

		menus.add(new String[] { "mm_keyLabel_ferramentas", 
				"config.gif", "0", "1", "F", null, null });
			
		menus.add(new String[] { "mm_keyLabel_painelControle", "bloch.gif", "0", "2", "F", 
				"#{painelControleBean.iniciarPainelControle}",
				"/mm_keyLabel_administracao/mm_keyLabel_ferramentas/mm_keyLabel_painelControle"});
			
		menus.add(new String[] { "mm_keyLabel_manterMenus", "menu.gif", "1", "2", "F", 
			"#{manterMenusBean.iniciarManterMenus}",
			"/mm_keyLabel_administracao/mm_keyLabel_ferramentas/mm_keyLabel_manterMenus" });
		
		menus.add(new String[] { "mm_keyLabel_manterArquivos", "save_as.gif","2","2","F",
			"#{manterArquivosBean.iniciarManterArquivos}",
			"/mm_keyLabel_administracao/mm_keyLabel_ferramentas/mm_keyLabel_manterArquivos" });
		
		menus.add(new String[] { "mm_keyLabel_showCase", "java.gif", "3", "2", "F", 
			"#{menuBean.iniciarShowCase}",
			"/mm_keyLabel_administracao/mm_keyLabel_ferramentas/mm_keyLabel_showCase" });
		
		menus.add(new String[] { "mm_keyLabel_recursosHumanos", 
			"peoples_dif.gif", "1", "1", "F", null, null });
		
		menus.add(new String[] {"mm_keyLabel_cadastroPessoal", "peoples.gif", "0", "2", "F", 
			"#{recursosHumanosBean.iniciarManterCadPes}",
			"/mm_keyLabel_administracao/mm_keyLabel_recursosHumanos/"+ 
					"mm_keyLabel_cadastroPessoal" });
		
		menus.add(new String[] { "mm_keyLabel_cadastroUsuarios", "user.gif", "1", "2", "F", 
			"#{recursosHumanosBean.iniciarManterCadUs}",
			"/mm_keyLabel_administracao/mm_keyLabel_recursosHumanos/"+
				"mm_keyLabel_cadastroUsuarios" });
		
		menus.add(new String[] {"mm_keyLabel_manterPerfis", "activity.gif", "2", "2", "F", 
			"#{manterPerfisBean.iniciarManterPerfis}",
			"/mm_keyLabel_administracao/mm_keyLabel_recursosHumanos/"+
					"mm_keyLabel_manterPerfis" });
		
		menus.add(new String[] { "mm_keyLabel_download", "download.gif", "1", "2", "T", 
			"#{manterArquivosBean.iniciarPaginaDownloads}",
			"mm_keyLabel_download" });
		
		menus.add(new String[] { "mm_keyLabel_homePage", "home.gif", "2", "2", "T", 
			"#{menuBean.iniciarHomePage}",
			"/mm_keyLabel_homePage" });
		
		menus.add(new String[] { "mm_keyLabel_login", "key.gif", "3", "2", "T", 
			"#{realizarLoginBean.iniciarRealizarLogin}",
			"/mm_keyLabel_login" });
		
		menus.add(new String[] { "mm_keyLabel_logout", "logout.gif", "4", "2", "T", 
			"#{realizarLoginBean.iniciarRealizarLogout}",
			"/mm_keyLabel_logout" });
		
		menus.add(new String[] { "mm_keyLabel_help", "help.gif", "5", "2", "T", 
				"#{menuBean.getHelp}", "/mm_keyLabel_help" });
		
		return menus;
		
	}		
}

