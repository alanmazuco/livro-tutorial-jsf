package br.eti.amazu.blankapp.view.bean.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.log4j.Level;

import br.eti.amazu.blankapp.persistence.facade.IAppFacade;
import br.eti.amazu.blankapp.view.util.ClassUtil;
import br.eti.amazu.blankapp.view.vo.Config;
import br.eti.amazu.util.FacesUtil;
import br.eti.amazu.util.log.Log;

@Named
@ApplicationScoped
public class ConfigBean implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	IAppFacade<Object> appFacade;
	
	@Inject
	UserSessionInBean userSessionInBean;
	
	private Config config; //O objeto config contem as variaveis de configuracoes do sistema.	
	private String skinTheme;
	private String ambiente = "";
	
	//Armazena uma lista de idiomas suportados.
	private List<String> locales = new ArrayList<String>();
	
	 //Disponibiliza uma lista de todos as classes beans da aplicacao.	
	private static List<Class<?>> classBeans;
		
	public void setConfiguracoes(){
			
		config = new Config();
		try{
			FileInputStream fis = new FileInputStream(
					FacesUtil.getFullPath("WEB-INF/classes/config.properties"));  
	
			
			Properties props = new Properties();
			props.load(fis);
			
			/* TIPOS DE MENU: 
			 * - menuBar ---------	HORIZONTAL (default)
			 * - tiered ----------	VERTICAL
			 * - slide -----------  VERTICAL
			 * - panelMenu -------  VERTICAL*/		
			config.setMenuType(props.getProperty("menuType")); 
			
			/* SKIN
			 ----------*/
			config.setSkinFooter(props.getProperty("skinFooter")); 
			config.setSkinBackground(props.getProperty("skinBackground"));
			config.setSkinImageLogo(props.getProperty("skinImageLogo"));//o nome da logo
			config.setSkinLogo(props.getProperty("skinLogo")); //true ou false
			config.setSkinTextLogo(props.getProperty("skinTextLogo")); 
			config.setSkinColorTextLogo(props.getProperty("skinColorTextLogo"));			
			config.setAnimatedTop(props.getProperty("animatedTop"));			
			
			//O tema default eh o aristo.
			skinTheme=props.getProperty("skinTheme");	
			config.setSkinTheme("primefaces-" + skinTheme); 
						
			/* AMBIENTE
			 ------------------*/
			/* O aplicativo poderah rodar em varios ambientes. No nosso caso, apenas em dois:
			 * - Desevolvimento (DEV)  - Producao (PROD) --> Isto eh definido por um comando Maven.
			 * Aqui, captura o ambiente sendo executado, mostra o log no header da template... */
			config.setMvnVersion(props.getProperty("mvnVersion")); 
			config.setMvnVersionDate(props.getProperty("mvnVersionDate"));
			

			//Buscando a Unit Name ativada
			String unitName = (String) appFacade.getDao().getEntityManager().
					getEntityManagerFactory().getProperties().get("hibernate.session_factory_name");
			
			//Seta o nome do ambiente baseado no nome da Unit Name ativada
			if(unitName.contains("PWORLD-DEV")){
				config.setServerName("http://localhost:8080"); //sempre localhost
				config.setEnvironment("Ambiente de DESENVOLVIMENTO");
				Log.setLogger(ConfigBean.class, "Rodando o ambiente de DESENVOLVIMENTO", Level.INFO);			
			}		
	
			if(unitName.contains("PWORLD-PROD")){
				config.setServerName(props.getProperty("serverProduct"));
				config.setEnvironment("&#160;"); //nao renderizar o indicativo de ambiente de producao.
				Log.setLogger(ConfigBean.class, "Rodando o ambiente de PRODU��O", Level.INFO);
			}			
			

			//outros logs		
			Log.setLogger(ConfigBean.class, "Rodando o tema: " + config.getSkinTheme(), Level.INFO);
			Log.setLogger(ConfigBean.class, "Rodando o skin: " + config.getSkinBackground(), Level.INFO);
			Log.setLogger(ConfigBean.class, "Rodando o menu: " + config.getMenuType(), Level.INFO);
			
			//logando todos os beans da aplicacao
			String packageName = ClassUtil.getBeansPackage(this.getClass().getPackage());
						
			File directory = new File(FacesUtil.getFullPath(props.getProperty("localBeans")));
			
			try {
				classBeans = ClassUtil.findClasses(directory, packageName);				
				Log.setLogger(ConfigBean.class, "", Level.INFO);
				Log.setLogger(ConfigBean.class, "      " + "TODOS OS BEANS DA APLICACAO:", Level.INFO);
				Log.setLogger(ConfigBean.class, "      " + "--------------------------------------------", Level.INFO);
				for(Class<?> clazz:classBeans){
					Log.setLogger(ConfigBean.class, "      " + clazz.getName(), Level.INFO);
				}
				Log.setLogger(ConfigBean.class, "", Level.INFO);
				
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}			
			
		}catch(IOException e){
			e.printStackTrace();
		}
	}
		
	public void saveTheme(){
		config.setSkinTheme("primefaces-" + skinTheme);		
	}	
		
	public Config getConfig() {
		if(config == null){
			this.setConfiguracoes();
		}
		return config;
	}
	
	public List<String> getLocales() {
		
		//Utliza a classe FacesUtil para obter a lista de idiomas suportados.
		if(locales.isEmpty()){
			locales = FacesUtil.getLocales();
			
			//realiza apenas um log
			StringBuffer strb = new StringBuffer();
			strb.append("Linguagens suportadas: ");
			
			int i=1;
			for(String str:locales){				
				if(i == locales.size()){
					strb.append(str);
					
				}else{
					strb.append(str + ", ");
				}
				i++;
			}
			Log.setLogger(ConfigBean.class, strb.toString(), Level.INFO);
		}
		return locales;
	}

	/*---------
	 * get/set
	 ---------*/
	public String getSkinTheme() {
		return skinTheme;
	}
	public void setSkinTheme(String skinTheme) {
		this.skinTheme = skinTheme;
	}
	public String getAmbiente() {
		return ambiente;
	}
	public void setAmbiente(String ambiente) {
		this.ambiente = ambiente;
	}
	public static List<Class<?>> getClassBeans() {
		return classBeans;
	}
	public static void setClassBeans(List<Class<?>> classBeans) {
		ConfigBean.classBeans = classBeans;
	}
	public void setConfig(Config config) {
		this.config = config;
	}
	public void setLocales(List<String> locales) {
		this.locales = locales;
	}	
		
}