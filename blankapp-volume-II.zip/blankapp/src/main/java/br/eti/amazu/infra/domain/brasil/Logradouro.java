package br.eti.amazu.infra.domain.brasil;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.ForeignKey;

@Entity (name="Logradouro")
@Table (schema="PWORLD", name="LOGRADOURO")
@NamedQueries({	
	@NamedQuery(name="Logradouro.all",  query="select a from Logradouro a"	),
	@NamedQuery(
		name="Logradouro.peloCep", query="select a from Logradouro a where a.cep =:param0"
	)
})
public class Logradouro {

	@Id
	@Column (name="ID_LOGRADOURO")
	private Long id;
	
	@Column (name="CEP", columnDefinition="CHAR(9)")
	private String cep;
	
	@Column (name="NOME_LOGRADOURO", columnDefinition="CHARACTER VARYING(125)")
	private String nome;	
				
	@ManyToOne(
		targetEntity = Bairro.class,		
		fetch = FetchType.LAZY 
	)	
	@JoinColumn(name="ID_BAIRRO", foreignKey= @ForeignKey(name = "LOGRADOURO_BAIRRO_FK"))
	private Bairro bairro;

	
	/*--------
	 * get/set
	 ---------*/
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Bairro getBairro() {
		return bairro;
	}

	public void setBairro(Bairro bairro) {
		this.bairro = bairro;
	}	

}
