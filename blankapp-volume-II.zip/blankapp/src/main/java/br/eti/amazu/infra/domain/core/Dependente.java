package br.eti.amazu.infra.domain.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import br.eti.amazu.component.pworld.domain.AbstractEntity;

@Entity (name="Dependente")
@Table (schema="PWORLD", name="DEPENDENTE")
@NamedQueries({	
	@NamedQuery(name="Dependente.all", query="select a from Dependente a")
})
public class Dependente extends AbstractEntity<Long>{

	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(schema="PWORLD", allocationSize=1, initialValue=1,
			name="DEPENDENTE_SEQ",  sequenceName="DEPENDENTE_SEQ")

	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "DEPENDENTE_SEQ")	
	@Column (name="ID_DEPENDENTE")
	private Long id;
	
	@Column (name="NOME", columnDefinition = "CHARACTER VARYING(70)")
	private String nome;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "DATA_NASCIMENTO", columnDefinition = "DATE", nullable=false)	
	private Date dataNascimento;
	
	@Column (name="GRAU_PARENT", columnDefinition = "CHARACTER VARYING(15)")
	private String grauParent;
	

	/* Associacao *:1 com pessoa:
	 * ----------------------------------------------------------------
	 * 	LEITURA BIDIRECIONAL: 
	 *      			| ----------(LAZY)-------->	|
	 *			pessoa 	|                          	|  dependente
	 *   				|< -------(EAGER)--------	|
	 *-----------------------------------------------------------------
	 * 	dependente nao escreve em pessoa (sem anotacao de cascade aqui)
	 *---------------------------------------------------------------*/
	@ManyToOne(targetEntity = Pessoa.class,	fetch = FetchType.LAZY	)
	@JoinColumn(name="ID_PESSOA", 
			foreignKey= @ForeignKey(name = "DEPENDENTE_PESSOA_FK"))
	private Pessoa pessoa;	
	
	@Version
	@Column (name="VERSAO", columnDefinition="INTEGER DEFAULT 0")
	private Integer version;

	/*--------
	 * get/set
	 ---------*/
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Date getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getGrauParent() {
		return grauParent;
	}

	public void setGrauParent(String grauParent) {
		this.grauParent = grauParent;
	}

	public Pessoa getPessoa() {
		return pessoa;
	}

	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

}