package br.eti.amazu.infra.view.util;

import java.util.Date;

import br.eti.amazu.infra.domain.core.Empresa;
import br.eti.amazu.infra.domain.core.Pessoa;
import br.eti.amazu.infra.domain.core.Usuario;
import br.eti.amazu.infra.persistence.appfacade.IAppFacade;
import br.eti.amazu.infra.util.DateUtil;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;

public class DomainObjectTest {
	
	public static Pessoa getPessoa(IAppFacade<Empresa> empresaFacade) {
		
		Empresa empresa = getEmpresa(empresaFacade); //gera uma empresa
		empresaFacade.clear(); //limpa e EntityManager.
				
		Pessoa pessoa = new Pessoa();
		pessoa.setNome("Jos� da Silva");		
		pessoa.setDataNascimento(DateUtil.getDate("01/01/1979"));		
		pessoa.setCpf("999.999.999-99");
		pessoa.setIdt("101010-ES");	
		pessoa.setCep("70730510");	
		pessoa.setUf("DF");
		pessoa.setCidade("Bras�lia");;
		pessoa.setBairro("Asa Sul");
		pessoa.setLogradouro("SCLRN");		
		pessoa.setComplemento("Apto");
		pessoa.setNr("703");
		pessoa.setFone("(27)9999-0000");
		pessoa.setCelular("(27)8888-1111");
		pessoa.setEmail("nome@hot.com");		
		
		pessoa.setEmpresa(empresa); //populando empresa		
		
		return pessoa;
		
	}
	
	
	public static Usuario getUsuario() {
		Usuario usuario = new Usuario();
		usuario.setNomeUsuario("user500");
		usuario.setSenha("admin");
		usuario.setBloqueado("F");
		usuario.setDataPrimeiroAcesso(new Date());
		usuario.setPrimeiroAcesso("T");
		return usuario;
	}
	
	
	/* ---------------------------------------------
	 *  LICAO 30 EM DIATE
	 *  Retorna a empresa (cria uma, se nao existir)
	 *  Metodo criado para atender os experimentos
	 *  do mapeamento OneToMany.
	 ---------------------------------------------*/
	static Empresa getEmpresa(IAppFacade<Empresa> empresaFacade){
		
		try {
			
			Empresa empresa = empresaFacade.recuperar(Empresa.class, 1L);
			
			if(empresa == null) {
				empresa = new Empresa();
				empresa.setId(1L);
				empresa.setRazaoSocial("Minha Empresa LTDA.");
				empresa.setNomeFantasia("Minha Empresa");
				empresa.setCnpj("00.000.000/0001-00");
				empresaFacade.incluir(empresa);
			}
			
			return empresa;
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}
	
}
