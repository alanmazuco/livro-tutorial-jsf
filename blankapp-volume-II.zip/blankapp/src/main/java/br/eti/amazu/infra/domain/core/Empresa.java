package br.eti.amazu.infra.domain.core;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.Cascade;

import br.eti.amazu.component.pworld.domain.AbstractEntity;

@Entity(name = "Empresa")
@Table(schema = "PWORLD", name = "EMPRESA")

@NamedQueries({
	@NamedQuery(name = "Empresa.all", 
				query = "select a from Empresa a order by a.nomeFantasia"),
})
public class Empresa extends AbstractEntity<Long> {

	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(schema="PWORLD", allocationSize=1, 
			initialValue=1, name = "EMPRESA_SEQ", sequenceName = "EMPRESA_SEQ")	
	
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "EMPRESA_SEQ")
	@Column(name = "ID_EMPRESA")	
	private Long id;
	
	@Column(name = "RAZAO_SOCIAL", columnDefinition = "CHARACTER VARYING(70)", 
				nullable=false)
	private String razaoSocial;	
	
	@Column(name = "NOME_FANTASIA", columnDefinition = "CHARACTER VARYING(70)", nullable=false)
	private String nomeFantasia;
	
	@Column(name="CNPJ", columnDefinition = "CHAR(18)", nullable=false)
	private String cnpj;
	
	@Column(name = "UF", columnDefinition = "CHAR(2)")
	private String uf;
	
	@Column(name = "CIDADE", columnDefinition = "CHARACTER VARYING(70)")
	private String cidade;
	
	@Column(name = "BAIRRO", columnDefinition = "CHARACTER VARYING(70)")
	private String bairro;
	
	@Column(name = "LOGRADOURO", columnDefinition = "CHARACTER VARYING(125)")
	private String logradouro;
	
	@Column(name = "CEP", columnDefinition = "CHAR(9)")
	private String cep;
	
	@Column(name = "NR", columnDefinition = "CHARACTER VARYING(15)")
	private String nr;
	
	@Column(name = "COMPLEMENTO", columnDefinition = "CHARACTER VARYING(100)")
	private String complemento;
	
	@Column(name = "FONE", columnDefinition = "CHARACTER VARYING(15)")
	private String fone;
	
	@Column(name = "CELULAR", columnDefinition = "CHARACTER VARYING(15)")
	private String celular;
	
	@Column(name = "EMAIL", columnDefinition = "CHARACTER VARYING(40)")
	private String email;
	
	@Column(name = "CONTATO", columnDefinition = "CHARACTER VARYING(40)")
	private String contato;
	
	@Column(name = "CELULAR_CONTATO", columnDefinition = "CHARACTER VARYING(15)")
	private String celularContato;	
		
	
	/* *******************************************
	 * IMPLEMENTACAO DE DADOS E DE SKIN DA EMPRESA
	 ********************************************/	
	
	
	/* O tipo de menu admitindo os valores:
	 * - tiered
	 * - slide
	 * - menuBar
	 * - panelMenu*/
	@Column(name = "MENU_TYPE", columnDefinition = "CHARACTER VARYING(15)")
	private String menuType;
	
	//O tema do primeFaces
	@Column(name = "SKIN_THEME", columnDefinition = "CHARACTER VARYING(15)")
	private String skinTheme;

	//O texto que vai ao rodapeh da pagina
	@Column(name = "SKIN_FOOTER", columnDefinition = "CHARACTER VARYING(200)")
	private String skinFooter;
	
	//As imagens que compoem o fundo da pagina
	@Column(name = "SKIN_BACKGROUND", columnDefinition = "CHARACTER VARYING(15)")
	private String skinBackground;
		
	/* Se o topo terah ou nao o logotipo da empresa
	 admite 'T' ou 'F'*/
	@Column(name = "SKIN_LOGO", columnDefinition = "CHAR(1)")
	private String skinLogo;
	
	/* O logotipo da empresa.
	 Uma string que representa o arquivo de imagem da logomarca da empresa.*/
	@Column(name="SKIN_IMAGE_LOGO", columnDefinition = "CHARACTER VARYING(40)")
	private String skinImageLogo;
	
	/* Se o topo serah ou nao animado
	 admite 'T' ou 'F'*/
	@Column(name = "SKIN_ANIMATED_TOP", columnDefinition = "CHAR(1)")
	private String skinAnimatedTop;
	
	//O texto abaixo do logotipo da empresa
	@Column(name = "SKIN_TEXT_LOGO", columnDefinition = "CHARACTER VARYING(20)")
	private String skinTextLogo;
	
	//A cor do texto posicionado abaixo do logotipo da empresa
	@Column(name = "SKIN_COLOR_TEXT_LOGO", columnDefinition = "CHARACTER VARYING(15)")
	private String skinColorTextLogo;
	
	//Uma pagina contendo o HTML5 animado
	@Column(name = "SKIN_ANIMATED_HTML", columnDefinition = "CHARACTER VARYING(40)")
	private String skinAnimatedHtml;
	//------------------------------	
	
	/* Associacao 1:* com Pessoa:--------------------------------------------
	 * 	LEITURA BIDIRECIONAL: 
	 *      			| ----------(LAZY)-------->	|
	 *		empresa 	|                         	|  pessoa
	 *   				|< -------(EAGER)--------	|
	 *-----------------------------------------------------------------------
	 *		ESCRITA UNIDIRECINAL:
	 *		empresa 	|----------(write)-------->	|  pessoa
	 *  (A relacao eh unidirecional porque somente empresa escreve em pessoa)
	 *---------------------------------------------------------------------*/
	@OneToMany(
		fetch = FetchType.LAZY,
		orphanRemoval=true,
		targetEntity=Pessoa.class,
		mappedBy="empresa"		
	)	
	@Cascade (org.hibernate.annotations.CascadeType.ALL)
	private Set<Pessoa> pessoas;
	
	@Version
	@Column(name = "VERSAO", columnDefinition = "INTEGER DEFAULT 0")
	private Integer versao;

	
	/*--------
	 * get/set
	 ---------*/
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public String getNomeFantasia() {
		return nomeFantasia;
	}

	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getNr() {
		return nr;
	}

	public void setNr(String nr) {
		this.nr = nr;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getFone() {
		return fone;
	}

	public void setFone(String fone) {
		this.fone = fone;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(String celular) {
		this.celular = celular;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContato() {
		return contato;
	}

	public void setContato(String contato) {
		this.contato = contato;
	}

	public String getCelularContato() {
		return celularContato;
	}

	public void setCelularContato(String celularContato) {
		this.celularContato = celularContato;
	}

	public String getMenuType() {
		return menuType;
	}

	public void setMenuType(String menuType) {
		this.menuType = menuType;
	}

	public String getSkinTheme() {
		return skinTheme;
	}

	public void setSkinTheme(String skinTheme) {
		this.skinTheme = skinTheme;
	}

	public String getSkinFooter() {
		return skinFooter;
	}

	public void setSkinFooter(String skinFooter) {
		this.skinFooter = skinFooter;
	}

	public String getSkinBackground() {
		return skinBackground;
	}

	public void setSkinBackground(String skinBackground) {
		this.skinBackground = skinBackground;
	}

	public String getSkinLogo() {
		return skinLogo;
	}

	public void setSkinLogo(String skinLogo) {
		this.skinLogo = skinLogo;
	}

	public String getSkinImageLogo() {
		return skinImageLogo;
	}

	public void setSkinImageLogo(String skinImageLogo) {
		this.skinImageLogo = skinImageLogo;
	}

	public String getSkinAnimatedTop() {
		return skinAnimatedTop;
	}

	public void setSkinAnimatedTop(String skinAnimatedTop) {
		this.skinAnimatedTop = skinAnimatedTop;
	}

	public String getSkinTextLogo() {
		return skinTextLogo;
	}

	public void setSkinTextLogo(String skinTextLogo) {
		this.skinTextLogo = skinTextLogo;
	}

	public String getSkinColorTextLogo() {
		return skinColorTextLogo;
	}

	public void setSkinColorTextLogo(String skinColorTextLogo) {
		this.skinColorTextLogo = skinColorTextLogo;
	}

	public String getSkinAnimatedHtml() {
		return skinAnimatedHtml;
	}

	public void setSkinAnimatedHtml(String skinAnimatedHtml) {
		this.skinAnimatedHtml = skinAnimatedHtml;
	}

	public Set<Pessoa> getPessoas() {
		return pessoas;
	}

	public void setPessoas(Set<Pessoa> pessoas) {
		this.pessoas = pessoas;
	}

	public Integer getVersao() {
		return versao;
	}

	public void setVersao(Integer versao) {
		this.versao = versao;
	}	
	
}