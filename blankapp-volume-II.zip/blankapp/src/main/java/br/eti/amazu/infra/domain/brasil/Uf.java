package br.eti.amazu.infra.domain.brasil;

import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.ForeignKey;

@Entity (name="Uf")
@NamedQueries({	
	@NamedQuery(
		name="Uf.porPais",
	    query="select a from Uf a where a.pais.id =:param0 order by a.nome"
	)
})
@Table (schema="PWORLD", name="UF")
public class Uf {

	@Id
	@Column (name="ID_UF")
	private Long id;
		
	@Column(name = "NOME_UF", 
		columnDefinition = "CHARACTER VARYING(70)")
	private String nome;
	
	@Column (name="SIGLA", 
          columnDefinition="CHAR(2)")
	private String sigla;

	@ManyToOne(
		targetEntity = Pais.class,		
		fetch = FetchType.LAZY
	)
	@JoinColumn(name="ID_PAIS", foreignKey= @ForeignKey(name = "UF_PAIS_FK"))	
	private Pais pais;
	
	@OneToMany(			
		targetEntity=Cidade.class,
		mappedBy="uf",
		fetch = FetchType.LAZY
	)
	private Set<Cidade> cidades;
	
	
	/*---------
	 * get/set
	 ----------*/
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

	public Pais getPais() {
		return pais;
	}

	public void setPais(Pais pais) {
		this.pais = pais;
	}

	public Set<Cidade> getCidades() {
		return cidades;
	}

	public void setCidades(Set<Cidade> cidades) {
		this.cidades = cidades;
	}	
	
}
