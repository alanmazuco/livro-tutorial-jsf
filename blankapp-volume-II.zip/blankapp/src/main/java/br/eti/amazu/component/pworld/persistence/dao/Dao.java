package br.eti.amazu.component.pworld.persistence.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import br.eti.amazu.component.pworld.persistence.exception.DaoException;

public abstract class Dao<T> implements IDao<T> {
	
	private EntityManager entityManager;
	
	
	
	/**********
	 * NO QUERY
	 *********/

	/*--------------------------------
	 * Inserir - Alterar - Excluir
	 * -----------------------------*/
	@Override
	public void insert(T obj) throws DaoException {		
		entityManager.persist(obj);		
	}

	@Override
	public void delete(T obj) throws DaoException {		
		obj = entityManager.merge(obj);
		entityManager.remove(obj);
	}

	@Override
	public void update(T obj) throws DaoException {
		entityManager.merge(obj);
	}
   //---------------------------------------------------------------
	
	
	/*-----------------------------------------------------------
	 * Consulta de um unico resultado passando uma chave primaria
	 * pk somente do tipo Long, Integer e String
	 * --------------------------------------------------------*/
	@Override
	public T find(Class<T> t, Long pk) throws DaoException {
		return entityManager.find(t, pk);
	}
 
	@Override
	public T find(Class<T> t, Integer pk) throws DaoException {
		return entityManager.find(t, pk);
	}

	@Override
	public T find(Class<T> t, String pk) throws DaoException {
		return entityManager.find(t, pk);
	}
  //--------------------------------------------------------
	
	
	
	
	/*************
	 * NAMEDQUERY
	 *************/

	/*---------------------------------------
	 * Retorna uma lista de objetos.
	 * Lista tudo sem precisar de parametros.
	 * - Utilizando hql e namedQuery.
	 --------------------------------------*/
	@Override
	@SuppressWarnings("unchecked")
	public List<T> list(String namedQuery) throws DaoException {
		Query query = entityManager.createNamedQuery(namedQuery);		
		return query.getResultList();
	}
	
	/*------------------------------------------------------
	 * Retorna uma lista de objetos.
	 * Lista tudo (ou uma lista limitada)  usando parametros.
	 * - Utilizando hql e namedQuery.
	 ------------------------------------------------------*/
	@Override
	@SuppressWarnings("unchecked")
	public List<T> list(String namedQuery, List<Object> params) throws DaoException {
		Query query = entityManager.createNamedQuery(namedQuery);
		
		for (int i = 0; i < params.size(); i++) {
			if(params.get(i) instanceof ArrayList){				
				query.setParameter("param" + i, params.get(i));
			
			}else{
				query.setParameter("param" + i, params.get(i));
			}
		}

		return query.getResultList();
	}
	
	/*--------------------------------------------
	 * Consulta paginada com namedQuery- resultset	
	 * -----------------------------------------*/
	@SuppressWarnings("unchecked")
	public List<T> listPagination(String namedQuery, List<Object> params,
					int first, int pageSize) throws DaoException{		
		Query query = entityManager.createNamedQuery(namedQuery);		
		
		if (params != null && params.size() > 0) {
			for (int i = 0; i < params.size(); i++) {				
				if(params.get(i) instanceof ArrayList){
					query.setParameter("names", params.get(i));
				
				}else{
					query.setParameter("param" + i, params.get(i));
				}
			}
			
		}
		query.setFirstResult(first);
		query.setMaxResults(pageSize);		
		return query.getResultList();
	}	

	/*------------------------------------------------------------------
	 * Retorna um unico objeto
	 * - Utilizando hql e namedQuery.
	 * - O parametro da busca deverah ser feito por uma chave unica, 
	 *   ou na certeza de haver no banco um unico valor para o campo, se
	 *   isto nao for observado serah causado uma exception.
	 * - Utilizando hql e namedQuery.
	 -----------------------------------------------------------------*/
	@Override
	@SuppressWarnings("unchecked")
	public T singleResult(String namedQuery, List<Object> params) throws DaoException {
		Object object = new Object();
		Query query = entityManager.createNamedQuery(namedQuery);
		
		for (int i = 0; i < params.size(); i++) {
			query.setParameter("param" + i, params.get(i));
		}

		try {
			object = query.getSingleResult();

		} catch (NoResultException e) {
			return null;
		}

		return (T) object;
	}	
	
	/*---------------------------------------------------------------------------
	 * Traz o maximo de registros baseado em uma consulta.
	 * Pode ser usado em uma consulta paginada com namedQuery- total da paginacao	
	 * -------------------------------------------------------------------------*/
	public int maxResult(String namedQuery, List<Object> params) throws DaoException{
		Query query = entityManager.createNamedQuery(namedQuery);
		
		if (params != null && params.size() > 0) {
			for (int i = 0; i < params.size(); i++) {
				if(params.get(i) instanceof ArrayList){
					query.setParameter("names", params.get(i));
				
				}else{
					query.setParameter("param" + i, params.get(i));
				}
			}
		}
		return Integer.parseInt(query.getSingleResult().toString());
	}		
	
	/*---------------------------------------------
	 * Execute com hql e namedQuery.
	 --------------------------------------------*/
	@Override
	public boolean execute(String namedQuery, List<Object> params)
					throws DaoException {
		Query query = entityManager.createNamedQuery(namedQuery);
		
		for (int i = 0; i < params.size(); i++) {
			query.setParameter("param" + i, params.get(i)).toString();
			
		}
		
		return query.executeUpdate() == 1 ? true : false;
	}


	/*----------------------------------------------------------------
	 * Retorna um objeto unico de uma expressao HQL
	 * - quando queremos o ultimo registro baseado na expressao.
	 * - exemplo de uma namedQuery:
	 *   "from Pessoa p where p.bairro =:param0 order by p.nome DESC".
	 *   isto irah retornar a ultima pessoa de uma lista ordeada pelo
	 *   nome, que mora em um bairro passado no parametro.
	 ---------------------------------------------------------------*/
	@Override
	@SuppressWarnings("unchecked")
	public T minMaxFromExpression(String namedQuery, List<Object> params) throws DaoException {
		Object object = new Object();
		Query query = entityManager.createNamedQuery(namedQuery);
		
		for (int i = 0; i < params.size(); i++) {
			query.setParameter("param" + i, params.get(i));
		}
		
		query.setMaxResults(1);

		try {
			object = query.getSingleResult();

		} catch (NoResultException e) {
			return null;
		}

		return (T) object;
	}
	
	
		
	

	/*************
	 * NATIVEQUERY
	 *************/

	/*------------------------------------------------------------------
	 * Retorna uma lista de objetos. Utilizando sql nativa (nativeQuery).
	 * Lista tudo sem usar parametros - passando o Tipo
	 ------------------------------------------------------------------*/
	@Override
	@SuppressWarnings("unchecked")
	public List<T> listNQ(T t, String nativeQuery) throws DaoException {
		Query query = entityManager.createNativeQuery(nativeQuery, t.getClass());
		return query.getResultList();
	}
	
	/*-------------------------------------------------------------------
	 * Retorna uma lista de objetos.  Utilizando sql nativa (nativeQuery).
	 * Usando parametros - passando o Tipo
	 ------------------------------------------------------------------*/
	@Override
	@SuppressWarnings("unchecked")
	public List<T> listNQ(T t, String nativeQuery, List<Object> params) throws DaoException {
		Query query = entityManager.createNativeQuery(nativeQuery, t.getClass());
		List<T> lista;
		
		for (int i = 0; i < params.size(); i++) {
			query.setParameter("param" + i, params.get(i));
		}

		lista = query.getResultList();
		return lista;
	}
	
	/*-------------------------------------------------------------
	 * Retorna uma lista de objetos. Lista tudo sem usar parametros.
	 * Utilizando sql nativa (nativeQuery)
	 ------------------------------------------------------------*/
	@Override
	@SuppressWarnings("unchecked")
	public List<T> listNQ(String nativeQuery) throws DaoException {
		Query query = entityManager.createNativeQuery(nativeQuery);
		return query.getResultList();
	}
	
	/*---------------------------------------------------------------
	 * Retorna uma lista de objetos da classe passada como parametro.
	 * Utilizando sql nativa (nativeQuery).
	 --------------------------------------------------------------*/
	@Override
	@SuppressWarnings("unchecked")
	public List<T> listNQ(String nativeQuery, List<Object> params) throws DaoException {
		Query query = entityManager.createNativeQuery(nativeQuery);
		List<T> lista;
		
		for (int i = 0; i < params.size(); i++) {
			query.setParameter("param" + i, params.get(i));
		}

		lista = query.getResultList();
		return lista;
	}
	
	/* --------------------------------------------- 
	 * Consulta paginada com nativeQuery - resultset 
	 * -------------------------------------------*/
	@Override
	@SuppressWarnings("unchecked")
	public List<T> listPaginationNQ(T t, String nativeQuery, List<Object> params, 
				int first, int pageSize) throws DaoException{
		
		Query query = entityManager.createNativeQuery(nativeQuery, t.getClass());
		List<T> lista;		
		if (params != null && params.size() > 0) {
			for (int i = 0; i < params.size(); i++) {
				query.setParameter("param" + i, params.get(i));
			}
		}
		query.setFirstResult(first);
		query.setMaxResults(pageSize);
		lista = query.getResultList();
		return lista;
	}

	/*-------------------------------------------------------------------
	 * Retorna uma lista de objetos. Utilizando sql nativa (nativeQuery).	
	 ------------------------------------------------------------------*/
	@Override
	@SuppressWarnings("unchecked")
	public List<Object[]> listObjectNQ(String nativeQuery, List<Object> params) 
				throws DaoException {
		Query query = entityManager.createNativeQuery(nativeQuery);
		List<Object[]> lista;
		
		if(params != null && params.size() > 0){
			for (int i = 0; i < params.size(); i++) {
				query.setParameter("param" + i, params.get(i));
			}
		}
		lista = query.getResultList();
		return lista;
	}	
	
	/*---------------------------------------------------------------------------------------
	 * Consulta de unico resultado - retorna um objeto.  Utilizando sql nativa (nativeQuery).
	 * Passando o Tipo como parametro.
	 --------------------------------------------------------------------------------------*/
	@Override
	@SuppressWarnings("unchecked")
	public T singleResultNQ(T t, String nativeQuery, List<Object> params) 
				throws DaoException {

		Object object = new Object();
		Query query = entityManager.createNativeQuery(nativeQuery, t.getClass());
		
		for (int i = 0; i < params.size(); i++) {
			query.setParameter("param" + i, params.get(i));
		}

		try {
			object = query.getSingleResult();

		} catch (NoResultException e) {
			return null;
		}
		return (T) object;
	}

	/*-------------------------------------------------
	 * Consulta de unico resultado - retorna um objeto.	
  * Utilizando sql nativa (nativeQuery).
  * Sem utilizacao de par�metros.
	 ------------------------------------------------*/
	@Override
	@SuppressWarnings("unchecked")
	public T singleResultNQ(String nativeQuery) throws DaoException {
		Object object = new Object();
		Query query = entityManager.createNativeQuery(nativeQuery);		
		try {
			object = query.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
		return (T) object;
	}
	
	/*-------------------------------------------------------------------------------------
	 * Consulta de unico resultado - retorna um objeto.	Utilizando sql nativa (nativeQuery).
	 * Utilizando parametros para a consulta.
	 ------------------------------------------------------------------------------------*/
	@Override
	@SuppressWarnings("unchecked")
	public T singleResultNQ(String nativeQuery, List<Object> params) throws DaoException {
		Object object = new Object();
		Query query = entityManager.createNativeQuery(nativeQuery);
		
		for (int i = 0; i < params.size(); i++) {
			query.setParameter("param" + i, params.get(i));
		}
		try {
			object = query.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}

		return (T) object;
	}
	
	/*-------------------------------------
	 * Simples execute.
	 * Utilizando sql nativa (nativeQuery).	
	 ------------------------------------*/
	@Override
	public boolean executeNQ(String nativeQuery) throws DaoException {
		Query query = entityManager.createNativeQuery(nativeQuery);
		return query.executeUpdate() == 1 ? true : false;
	}
	
	/*-------------------------------------
	 * Inserir - Alterar - Excluir
	 * Utilizando sql nativa (nativeQuery).	
	 ------------------------------------*/
	@Override
	public boolean executeNQ(String nativeQuery, List<Object> params) throws DaoException {
		Query query = entityManager.createNativeQuery(nativeQuery);
		
		if (params != null) {
			for (int i = 0; i < params.size(); i++) {
				query.setParameter("param" + i, params.get(i));
			}
		}

		return query.executeUpdate() == 1 ? true : false;
	}

	/*-----------------------------------------------------
	 * Maximo de uma expressao: nativeQuery sem parametros. 
	 ----------------------------------------------------*/
	@Override
	public int maxResultNQ(String nativeQuery) throws DaoException{
		Query query = entityManager.createNativeQuery(nativeQuery);	
		return Integer.parseInt(query.getSingleResult().toString());
	}
	
	/*-----------------------------------------------------
	 * Maximo de uma expressao: nativeQuery com parametros. 
	 ----------------------------------------------------*/
	@Override
	public int maxResultNQ(String nativeQuery, List<Object> params) throws DaoException{
		Query query = entityManager.createNativeQuery(nativeQuery);
		
		if (params != null && params.size() > 0) {
			for (int i = 0; i < params.size(); i++) {
				query.setParameter("param" + i, params.get(i));
			}
		}
		return Integer.parseInt(query.getSingleResult().toString());
	}
			
	/*-----------------------------------
	 * Obtem a ultima sequence da tabela. 
	 ----------------------------------*/
	@Override
	public Long getSequenceNQ(String sequenceName) throws DaoException{
		Query query = entityManager.createNativeQuery("select " + sequenceName + ".nextval FROM DUAL");
		return Long.parseLong(query.getSingleResult().toString());
	}
	
	
	/**************************************************************
	 * MANIPULA��O DO ENTITY MANAGER - Apenas objetos persistentes.
	 *************************************************************/
	
	/*----------------------------------------------------------------
	 * Apagar todos os objetos que estao gerenciados no EntityManager.
	 * -------------------------------------------------------------*/
	@Override
	public void clear() {
		entityManager.clear();
	}
	
	/*--------------------------
	 * Atualizar o EntityManager
	 * -----------------------*/
	@Override
	public void refresh(Object obj) {
		if (entityManager.contains(obj)) entityManager.refresh(obj);
	}

	/*-----------------------------------------------------------
	 * Atualizar o EntityManager com lockModeType como parametro.
	 * --------------------------------------------------------*/
	@Override
	public void refresh(Object obj, LockModeType lockModeType) {
		if (entityManager.contains(obj)) entityManager.refresh(obj, lockModeType);
	}
	
	/*-----------------------------------------------------
	 * Verificar se um determinado objeto estah gerenciado.
	 * --------------------------------------------------*/
	@Override
	public boolean isManaged(Object obj) {
		return entityManager.contains(obj);
	}

	/*-------------------------------------------
	 * Bloquear/desbloquear um objeto para edi��o
	 * ----------------------------------------*/
	@Override
	public void lock(Object obj, LockModeType loModeType) {
		entityManager.lock(obj, loModeType);
	}

	/*-----------------------------------------------------
	 * Sincroniza objetos persistentes com o banco de dados.
	 * ---------------------------------------------------*/
	@Override
	public void flush() {
		entityManager.flush();
	}

	/*-------------------------------------
	 * Desassocia o objeto do entityManager.
	 * -----------------------------------*/
	@Override
	public void detach(Object obj) {
		entityManager.detach(obj);
	}

	/*------------------------
	 * Obtem um objeto managed.
	 * ----------------------*/
	@Override
	public Object get(Class<T> t, Object obj) {
		return entityManager.getReference(t, obj);
	}

	/*---------------------------------------
	 * Obtem uma referencia de entityManager.
	 * ------------------------------------*/
	@Override
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/*-----------------------------
	 * seta o objeto entityManager.
	 * --------------------------*/
	@Override
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}	
}

