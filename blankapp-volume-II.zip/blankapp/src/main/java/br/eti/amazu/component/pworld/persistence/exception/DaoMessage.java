package br.eti.amazu.component.pworld.persistence.exception;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

public class DaoMessage {

	/*Se for especificado o locale, traduz  a mensagem para  o locale especificado. 
   * Se nao for especificado o locale, assume o padrao do sistema operacional. */

	public static ResourceBundle BUNDLE_NAME = null;

	public DaoMessage(Locale locale) {
		BUNDLE_NAME = ResourceBundle.getBundle("messages", locale);
	}

	static void initInfoLocale() {
		Locale locale = Locale.getDefault();
		BUNDLE_NAME = ResourceBundle.getBundle("messages", locale);
	}

	public static ResourceBundle getResourceBundle() {
		Locale locale = Locale.getDefault();
		return ResourceBundle.getBundle("messages", locale);
	}

	/*---------------------------------------------------------------------------
	 * MENSAGENS SEM PARAMETROS
	 * Utilizado intensivamente no processo de internacionalizacao - DAO. Obtem o
	 * valor da mensagem do arquivo properties, passando a chave como parametro.	
	 --------------------------------------------------------------------------*/
	public static String getMessage(String key) {
		if (BUNDLE_NAME == null) initInfoLocale();
		return BUNDLE_NAME.containsKey(key) ? BUNDLE_NAME.getString(key) : ": invalid key";
	}

	/*------------------------------------------------------------------
	 * MENSAGENS COM PARAMETROS
	 * Utilizado intensivamente no processo de internacionalizacao - DAO
	 * Obtem o valor da mensagem do arquivo properties, passando a
	 * chave e uma lista de parametros.	
	 -----------------------------------------------------------------*/
	public static String getMessage(String key, String[] params) {
		if (BUNDLE_NAME == null) initInfoLocale();
		String msg;

		if (BUNDLE_NAME.containsKey(key)) {
			msg = BUNDLE_NAME.getString(key);

		} else {
			msg = ": invalid key";
		}

		for (int i = 0; i < params.length; i++) {
			String param = params[i];
			String regex = "{" + i + "}";
			msg = msg.replace(regex, param);
		}
		return msg;
	}

	/*------------------------------------------------------------
	 * RETORNA A KEY
	 * Passando o valor da key (nao o nome da key) como parametro.
	 -----------------------------------------------------------*/
	public static String getKey(String strValue) {
		Enumeration<String> keys = BUNDLE_NAME.getKeys();
		while (keys.hasMoreElements()) {
			String key = keys.nextElement();
			String value = BUNDLE_NAME.getString(key);
			if (value.equals(strValue)) return key;
		}

		return null;
	}

	/*--------------------------------------------------
	 * KEYS LABEL MENU
	 * Obtem uma lista de todas as keys de label de menu	
	 -------------------------------------------------*/
	public static List<String> getKeysLabelMenu() {
		List<String> listaKeysLabelMenu = new ArrayList<String>();
		Enumeration<?> keys = BUNDLE_NAME.getKeys();

		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			try {
				if (key.substring(0, 6).equals("mm_key")) listaKeysLabelMenu.add(key);
			} catch (StringIndexOutOfBoundsException e) {}
		}
		Collections.sort (listaKeysLabelMenu);
		return listaKeysLabelMenu;
	}
}

