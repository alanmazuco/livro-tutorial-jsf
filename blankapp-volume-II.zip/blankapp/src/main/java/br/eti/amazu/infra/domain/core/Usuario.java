package br.eti.amazu.infra.domain.core;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import br.eti.amazu.component.pworld.domain.AbstractEntity;

@Entity(name = "Usuario")

@Table(schema = "PWORLD", name = "USUARIO",  
	uniqueConstraints=@UniqueConstraint(		
			name="UK_USERNAME", columnNames={"NOME_USUARIO"}))

@NamedQueries({			
	@NamedQuery(name = "Usuario.recuperarPeloNome",  
			query = "select u from Usuario u where u.nomeUsuario =:param0"),	
			
	@NamedQuery(name="Usuario.excluirPeloNome",
		query="delete Usuario a where a.nomeUsuario=:param0") 
	
	

})
public class Usuario extends AbstractEntity<Long> {	
	
	private static final long serialVersionUID = 1L;

	@Id
	@GenericGenerator(name = "gerador", strategy = "foreign", 
			parameters = @Parameter(name = "property", value = "pessoa"))	
	
	@GeneratedValue(generator = "gerador")
	@Column(name = "ID_USUARIO") 	
	private Long id; 

	@Column(name = "NOME_USUARIO", columnDefinition = "CHARACTER VARYING(15)", nullable=false)
	private String nomeUsuario;

	@Column(name = "SENHA", columnDefinition = "CHARACTER VARYING(1000)", nullable=false)
	private String senha;

	@Column(name="BLOQUEADO", columnDefinition = "CHAR(1) DEFAULT 'F'",  nullable=false)
	private String bloqueado;

	@Temporal(TemporalType.DATE)
	@Column(name = "DATA_PRIMEIRO_ACESSO", columnDefinition = "DATE",  nullable=false)	
	private Date dataPrimeiroAcesso;

	@Column(name = "PRIMEIRO_ACESSO", columnDefinition = "CHAR(1) DEFAULT 'T'",nullable=false)
	private String primeiroAcesso;
	
	/* Associacao 1:1 com pessoa:
	 * -------------------------------------------------------------
	 * 	LEITURA BIDIRECIONAL: 
	 *		pessoa 	| <---------(EAGER)-------> 	|  usuario
	 *--------------------------------------------------------------
	 *		usuario nao escreve em pessoa (sem anotacao de cascade aqui)
	 *-------------------------------------------------------------*/
	@OneToOne(fetch = FetchType.LAZY,	optional=true)
	@PrimaryKeyJoinColumn()
	private Pessoa pessoa; /* A JPA nao gera a foreign_key no DB. */
	
	@Version
	@Column(name = "VERSAO", columnDefinition = "INTEGER DEFAULT 0")
	private Integer versao;

	/* 
	 * Associacao *:* com usuario: 
	 * -----------------------------------------
	 * 	LEITURA BIDIRECIONAL: 
	 *		   		|-------(LAZY)------->| 
	 * 		usuario	|                     |  perfil
	 *  			|<-------(LAZY)-------|  
	 *-----------------------------------------
	 *		ESCRITA BIDIRECIONAL:
	 *		usuario |<------(write)------>|  perfil
	 *-------------------------------------- */
	@ManyToMany(fetch=FetchType.LAZY)	
	@Cascade(org.hibernate.annotations.CascadeType.ALL)		
	@JoinTable(
		name = "USUARIO_PERFIL", schema="PWORLD",
		joinColumns = @JoinColumn(name = "ID_USUARIO", 
		foreignKey = @ForeignKey(name = "usu_perf_fk")),		
		inverseJoinColumns = @JoinColumn(name = "ID_PERFIL"),		
		uniqueConstraints = {
			@UniqueConstraint(
				name="UK_usuario_perfil",
				columnNames={"id_usuario","id_perfil"}
			)
		}			
	)
	private Set<Perfil> perfis;
	

	/*--------
	 * get/set
	 ---------*/
	public Set<Perfil> getPerfis() {
		return perfis;
	}

	public void setPerfis(Set<Perfil> perfis) {
		this.perfis = perfis;
	}
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeUsuario() {
		return nomeUsuario;
	}

	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getBloqueado() {
		return bloqueado;
	}

	public void setBloqueado(String bloqueado) {
		this.bloqueado = bloqueado;
	}

	public Date getDataPrimeiroAcesso() {
		return dataPrimeiroAcesso;
	}

	public void setDataPrimeiroAcesso(Date dataPrimeiroAcesso) {
		this.dataPrimeiroAcesso = dataPrimeiroAcesso;
	}

	public String getPrimeiroAcesso() {
		return primeiroAcesso;
	}

	public void setPrimeiroAcesso(String primeiroAcesso) {
		this.primeiroAcesso = primeiroAcesso;
	}

	public Pessoa getPessoa() {
		return pessoa;
	}

	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}

	public Integer getVersao() {
		return versao;
	}

	public void setVersao(Integer versao) {
		this.versao = versao;
	}
	
}

