package br.eti.amazu.infra.domain.brasil;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.ForeignKey;

@Entity (name="Cidade")
@Table (schema="PWORLD", name="CIDADE")

@NamedQueries({	
	@NamedQuery(name="Cidade.all", query="select a from Cidade a order by a.nome"),
	@NamedQuery(name="Cidade.porUf", query="select a from Cidade a where a.uf.id=:param0")
})
public class Cidade {

	@Id
	@Column (name="ID_CIDADE")
	private Long id;
	
	@Column (name="NOME_CIDADE", columnDefinition="CHARACTER VARYING(70)")
	private String nome;	
	
	@OneToMany(			
		targetEntity=Bairro.class,
		mappedBy="cidade",
		fetch = FetchType.LAZY
	)
	private Set<Bairro> bairros;
	
	@ManyToOne(
		targetEntity = Uf.class,		
		fetch = FetchType.LAZY 
	)
	@JoinColumn(name="ID_UF", foreignKey= @ForeignKey(name = "CIDADE_UF_FK"))
	private Uf uf;

	
	/*--------
	 * get/set
	 ---------*/
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Set<Bairro> getBairros() {
		return bairros;
	}

	public void setBairros(Set<Bairro> bairros) {
		this.bairros = bairros;
	}

	public Uf getUf() {
		return uf;
	}

	public void setUf(Uf uf) {
		this.uf = uf;
	}
	
}