package br.eti.amazu.infra.domain.core;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;
import org.hibernate.annotations.Cascade;
import javax.persistence.ForeignKey;

import br.eti.amazu.component.pworld.domain.AbstractEntity;

@Entity(name = "Funcionalidade")
@Table(name = "FUNCIONALIDADE", schema = "PWORLD")

@NamedQueries({
	@NamedQuery(name = "Funcionalidade.all", 
			query = "select a from Funcionalidade a order by a.label"),
	
	@NamedQuery(name = "Funcionalidade.nomeFuncionalidade", 
		query = "select a from Funcionalidade a where a.label =:param0"),
	
		@NamedQuery(name = "Funcionalidade.publicas", 
			query = "select a from Funcionalidade a where a.visibility ='T'"),
			
	@NamedQuery(name = "Funcionalidade.privadas", 
		query = "select a from Funcionalidade a where a.visibility ='F'") 
})
public class Funcionalidade extends AbstractEntity<Long>{

	
	/* 
	 * A funcionalidade deve ser persistida no instante da criacao de cada menu,
	 * em nenhum outro local mais, a nao ser no SETUP do sistema. Ao modificar,
	 * inserir ou excluir cada menu, reflete-se a acao para a funcionalidade
	 * correspondente: um label de menu eh igual a um label de funcionalidade.
	 * 
	 * Funcionalidade travada (desabilitada ou disabled) aparece desabilitada na
	 * lista de funcionalidades, no momento da criacao ou modificacao de um
	 * perfil. Assim sendo, o operador nao poderah atribuir ou retirar uma
	 * funcionalidade de um perfil se ela estiver travada.
	 */


	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(initialValue = 1,  name = "funcionalidade_seq", schema="PWORLD", 
		sequenceName = "funcionalidade_seq")	
	
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "funcionalidade_seq")
	@Column(name = "ID_FUNCIONALIDADE")
	private Long id;

	@Column(name = "LABEL", columnDefinition = "character varying(255)")
	private String label;

	@Column(columnDefinition = "char(1) default 'F'")
	private String disabled;

	@Column(columnDefinition = "char(1) default 'F'")
	private String visibility;
	/* Associacao *:* com funcionalidade: 
	 * -----------------------------------------------------
	 * 	LEITURA BIDIRECIONAL: 
	 *		   			|-------(LAZY)----------->	| 
	 * 	funcionalidade 	|                         	|  perfil
	 *  				|<-------(EAGER)--------	|  
	 *------------------------------------------------------
	 *		ESCRITA BIDIRECIONAL:
	 *		perfil 		|<--------(write)------->|  funcionalidade
	 *----------------------------------------------------*/
	@ManyToMany(fetch=FetchType.LAZY)
	@Cascade(org.hibernate.annotations.CascadeType.ALL)		
	@JoinTable(
		name = "PERFIL_FUNCIONALIDADE", schema="PWORLD",
		joinColumns = @JoinColumn(name = "ID_FUNCIONALIDADE", 
		foreignKey = @ForeignKey(name = "func_perf_fk")), 
		inverseJoinColumns = @JoinColumn(name = "ID_PERFIL"),
		uniqueConstraints = {
			@UniqueConstraint(
					name="UK_perfil_funcionalidade",
					columnNames={"id_perfil","id_funcionalidade"}
			)
		}			
	)	
	private Set<Perfil> perfis;
	
	@Version
	@Column(name = "VERSAO", columnDefinition = "Integer default 0")
	private Integer version;
	
	/*--------
	 * get/set
	 ---------*/
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getDisabled() {
		return disabled;
	}

	public void setDisabled(String disabled) {
		this.disabled = disabled;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public Set<Perfil> getPerfis() {
		return perfis;
	}

	public void setPerfis(Set<Perfil> perfis) {
		this.perfis = perfis;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

}	


