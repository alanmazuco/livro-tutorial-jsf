package br.eti.amazu.component.pworld.persistence.exception;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import org.hibernate.NonUniqueResultException;


public class InterceptorException {
	
	@AroundInvoke
 public Object trace(InvocationContext invocationContext) throws Exception{
				
   try {
	   return invocationContext.proceed();
            
   } catch (Exception t) {        	
	   String msg = store(t);

     	System.out.println("PWORLD-10==========>" +  msg);
        	
			 if(DaoMessage.getKey(msg).equals("_eMail")){
				  t.printStackTrace();
				  throw new MailException(msg);				
			 }else{
				  t.printStackTrace();
				  throw new DaoException(msg);
			 }
   		}
	}    
	
	public String store(Exception e)  {				
		if (e != null) {
			// chave: _eChav: duplica��o de registro.
			if (e.getCause() instanceof org.hibernate.exception.ConstraintViolationException) {					
				if(e.getCause().getCause().getMessage() != null && e.getCause().getCause().
						getMessage().contains("violates foreign key constraint")){					
					return DaoMessage.getMessage("_eVioC");
				}								
				return DaoMessage.getMessage("_eChav");
			}

			// chaves: _eConn e _eDbas - erro no banco de dados.
			if (e.getCause() instanceof org.hibernate.exception.GenericJDBCException
					|| e instanceof javax.persistence.PersistenceException) {	
			
				if(e.getCause().getCause().getMessage() != null && e.getCause().getCause().
						getMessage().contains("value too long for type char")){	
					
					return DaoMessage.getMessage("_eLong");
				}				
				if(e.getCause() instanceof org.hibernate.exception.JDBCConnectionException){
					return DaoMessage.getMessage("_eConn");					
				}					
				return DaoMessage.getMessage("_eDbas");				
			}

			// chave: _eCryp: erro ao criptografar/decriptografar dados.
			if (e.getCause() instanceof javax.crypto.IllegalBlockSizeException) {
				return DaoMessage.getMessage("_eCryp");
			}

			// chave: _eLock: outro usuario acessou o mesmo registro ao mesmo tempo.
			if (e instanceof javax.persistence.OptimisticLockException
					|| e.getCause() instanceof javax.persistence.OptimisticLockException) {
				return DaoMessage.getMessage("_eLock");
			}

			// chave: _eNore: era esperado um �nico conjunto de registros.
			if (e instanceof NonUniqueResultException) {
				return DaoMessage.getMessage("_eNore");
			}
						
			// chave: _eMail; erro no envio de email
			if (e instanceof org.apache.commons.mail.EmailException || 
					e.getCause() instanceof org.apache.commons.mail.EmailException || 
					e instanceof java.net.UnknownHostException ||
					e.getCause() instanceof java.net.UnknownHostException ) {
				e.printStackTrace();
				return DaoMessage.getMessage("_eMail");				
			}	

		}		
		// chave: _eFail: erro desconhecido.
		return DaoMessage.getMessage("_eFail");
	}	

}
