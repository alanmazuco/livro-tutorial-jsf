package br.eti.amazu.infra.persistence.appfacade;

import java.util.List;
import br.eti.amazu.component.pworld.persistence.exception.MailException;

public interface IAppMailFacade {	
	public void sendMail (String from, String to, String subject,String body, 
			List<String> filesPath) 
			throws MailException, Exception;	
}

