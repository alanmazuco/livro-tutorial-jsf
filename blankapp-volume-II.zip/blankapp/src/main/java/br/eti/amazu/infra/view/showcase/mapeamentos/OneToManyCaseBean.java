package br.eti.amazu.infra.view.showcase.mapeamentos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.log4j.Level;

import br.eti.amazu.component.dialog.DialogBean;
import br.eti.amazu.component.dialog.DialogType;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.infra.domain.core.Dependente;
import br.eti.amazu.infra.domain.core.Empresa;
import br.eti.amazu.infra.domain.core.Pessoa;
import br.eti.amazu.infra.persistence.appfacade.IAppFacade;
import br.eti.amazu.infra.util.DateUtil;
import br.eti.amazu.infra.util.log.Ansi;
import br.eti.amazu.infra.util.log.Log;
import br.eti.amazu.infra.view.util.DomainObjectTest;
import br.eti.amazu.infra.view.util.FormatTest;


@Named
@RequestScoped
public class OneToManyCaseBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Inject
	IAppFacade<Pessoa> pessoaFacade;
	
	@Inject
	IAppFacade<Empresa> empresaFacade;
	
	@Inject
	DialogBean dialogBean;
		
	/* ----------------------------------------------
	 *  EXPERIMENTO 22 - Incluir na tabela DEPENDENTE
	 ----------------------------------------------*/
	public void incluirDependente() {
		
		/* Existem duas maneiras de se incluir um registro na tabela DEPENDENTE:
		 * Utilizando a inje��o de uma fachada de dependente (IAppFacade<Dependente>), como 
		 * abaixo:
		 * Dependente dependente = new Dependente();					
				dependente.setPessoa(pessoa); //uma pessoa gerenciada pelo entityManager
				dependenteFacade.incluir(dependente);

	
		* A outra maneira eh utilizando o CascadeType (persistencia em cima do objeto 
	   * pessoa, que por cascata, iria inserir um registro na tabela DEPENDENTE), como 
	   * realizado neste experimento (abaixo): */		
		FormatTest.printHeader("ONE TO MANY", "Experimento 22 - Incluir dependente");		
		
		try {
			//Buscando uma pessoa com id conhecido			
			Pessoa pessoa = pessoaFacade.recuperar(Pessoa.class, 2L); 			
			if(pessoa != null) {
				
				//Criando um dependente da pessoa
				Dependente dependente = new Dependente();
				dependente.setDataNascimento(DateUtil.getDate("25/03/1964"));
				dependente.setGrauParent("Filho");
				dependente.setNome("Jos� Carlos Bl�");			
				dependente.setPessoa(pessoa);
				
				//adicionando o dependente na lista de dependentes da pessoa buscada
				pessoa.getDependentes().add(dependente);
										
				//Ao alterar pessoa, um registro na tabela DEPENDENTE serah incluido.		
				pessoaFacade.alterar(pessoa); 
				
				Log.setLogger("", "incluiu " + dependente.getNome().toUpperCase() + " de " 
							+ pessoa.getNome() + 	" com sucesso!", Level.INFO,  Ansi.BLUE);
				
			}else {
				dialogBean.addMessage("N�o encontoru a pessoa pesquisada." , DialogType.ERROR);
			}			
			FormatTest.printFooter();
				
		} catch (DaoException e) {
			e.printStackTrace();
		}			
	}
	
	
	
	/* ---------------------------------------
	 *  EXPERIMENTO 23 - Inclusoes simultaneas
	 ---------------------------------------*/
	public void incluirSimultaneo() {
		
		/* A ideia aqui eh incluir um registro na tabela PESSOA e
		 * varios registros na tabela DEPENDENTE, em cascata, 
		 * persistinho o objeto PESSOA */
		
		FormatTest.printHeader("ONE TO MANY", "Experimento 23 - Inclus�es simult�neas");
		
		try {
			
			//cria um objeto pessoa (novo)
			Pessoa pessoa = DomainObjectTest.getPessoa(empresaFacade);
			pessoa.setNome("Maria da Silva"); //dando outro nome, apenas para diferenciar
			
			//Criando o dependente1 - poderiamos criar o dependente2, 3, 4...
			Dependente dependente1 = new Dependente();
			dependente1.setDataNascimento(DateUtil.getDate("25/03/2012"));
			dependente1.setGrauParent("Filha");
			dependente1.setNome("Marta da Silva");			
			dependente1.setPessoa(pessoa);
			
			//adicionando o dependente na lista de dependentes da pessoa
			Set<Dependente> dependentes = new HashSet<Dependente>();
			dependentes.add(dependente1); //adicionariamos aqui outros dependentes alem do 1...
			pessoa.setDependentes(dependentes);		
		
			pessoaFacade.incluir(pessoa);
			
			Log.setLogger("", "incluiu " + pessoa.getNome() + " e " 
					+ dependente1.getNome().toUpperCase() + 
								" com sucesso!", Level.INFO,  Ansi.BLUE);
			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	/* -----------------------------------------------
	 *  EXPERIMENTO 24 - Exclusao na tabela 1 (PESSOA)
	 -----------------------------------------------*/
	public void excluirTabelaUm() {
		
		/* A ideia aqui eh excluir um registro na tabela PESSOA e
		 * todos os seus dependentes seriam tambem excluidos. */
		
		FormatTest.printHeader("ONE TO MANY", "Experimento 24 - Exclus�o na tabela 1 (PESSOA)");
		
		try {
			
			/*
			 * Inicialmente deve-se gerenciar o objeto a ser excluido.
			 * Busca-se o objeto pessoa incialmente, deixando-o gerenciado.
			 * Pressupoe a existencia de uma pessoa com id=1.
			 */			
			
			Pessoa pessoa = pessoaFacade.recuperar(Pessoa.class, 1L);
			
			if(pessoa != null) {
				
				//A exclusao de pessoa exclui tambem seus dependentes.
				pessoaFacade.excluir(pessoa);	
				
				Log.setLogger("", "Excluiu " + pessoa.getNome() + " e todos os seus dependentes."
						, Level.INFO,  Ansi.BLUE);	
				
				
			}else {
				Log.setLogger("", "N�o encontrou a pessoa pesquisada.", Level.INFO,  Ansi.BLUE);
			}		
			
			FormatTest.printFooter();	
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	/* ---------------------------------------------------
	 *  EXPERIMENTO 25 - Exclusao na tabela 2 (DEPENDENTE)
	 ---------------------------------------------------*/
	public void excluirTabelaDois() {
		
		/* A ideia aqui eh excluir todos os dependentes de uma pessoa. 
		 * Existem algumas maneiras de se fazer isto:
	   * uma boa ideia seria utilizando o CascadeType 
	   * (persistencia em cima do objeto pessoa, que por cascata,
		 * iria excluir os registros na tabela DEPENDENTE), 
		 * em conjunto com a instrucao "orphanRemoval=true",
		 * como realizado neste experimento (abaixo): */		
		
		FormatTest.printHeader("ONE TO MANY", "Experimento 25 - Exclus�o na tabela 2 (DEPENDENTE)");
		
		try {
			//Inicialmente deve-se gerenciar o objeto pessoa
			//Pressupoe a existencia de uma pessoa com id=4.
			Pessoa pessoa = pessoaFacade.recuperar(Pessoa.class, 4L);
			
			if(pessoa != null) {	
				
				//apaga todos os dependentes do objeto gerenciado
				pessoa.getDependentes().clear(); 
				
				//altera pessoa e excluui todos os seus dependentes no BD.
				pessoaFacade.alterar(pessoa); 
			
				Log.setLogger("", "Excluiu todos os dependentes de " + 
							pessoa.getNome(), Level.INFO,  Ansi.BLUE);
				
			}else {
				Log.setLogger("", "N�o encontrou a pessoa pesquisada.", Level.INFO,  Ansi.BLUE);
			}
			
			/* Para excluir simultaneamente (PESSOA e DEPENDENTES), bastar-se-ia executar:
			 * pessoaFacade.excluir(pessoa); */			
			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
		
	}
	
	
	/* ------------------------------------------------------
	 *  EXPERIMENTO 26 - Inclusao na tabela 1 com nativeQuery
	 ------------------------------------------------------*/	
	public void incluirTabelaUmNQ(){
		
		FormatTest.printHeader("ONE TO MANY / MANY TO ONE", 
				"Experimento 26 - Inclus�o na tabela 1 com Native Query");
		
		try{		

			//considere utilizar StringBuffer, ao inves de String
			String sql = "INSERT INTO PWORLD.PESSOA("
					+ "ID_PESSOA,"
					+ "CELULAR,"				
					+ "CPF,"
					+ "DATA_NASCIMENTO,"
					+ "EMAIL, "
					+ "FONE,"				
					+ "IDT,"
					+ "NOME,"
					+ "CEP,"
					+ "NR) "
					+ "VALUES ("
					+ "nextval('PWORLD.PESSOA_SEQ'), " 	//	ID_PESSOA
					+ "'(27)9999-9999', "	//	CELULAR
					+ "'999.999.999-99', " 		//	CPF					
					+ "'2000-03-01', "//		DATA_NASCIMENTO
					+ "'fulano@hot.com', "//	EMAIL
					+ "'(27)3333-3333', "//	FONE
					+ "'1110-ES/PT', "//	IDT
					+ "'Nome da Pessoa', "//	NOME
					+ "'31270570', "//	CEP
					+ "'55')";//	NR
								
			pessoaFacade.executarNQ(sql);						
			Log.setLogger("", "Opera��o conclu�da com sucesso!", Level.INFO, Ansi.BLUE);			
			dialogBean.addMessage("Opera��o conclu�da com sucesso!",  DialogType.INFO_CLOSABLE);				
			FormatTest.printFooter();
			
		}catch(DaoException e){		
			e.printStackTrace();			
		}

	}	

	

	/* ------------------------------------------------------
	 *  EXPERIMENTO 27 - Inclusao na tabela 2 com NativeQuery
	 ------------------------------------------------------*/
	public void incluirTabelaDoisNQ() {
		
		/* A ideia aqui eh incluir na tabela DEPENDENTE usando NativeQuery.*/		
		
		FormatTest.printHeader("ONE TO MANY", 
						"Experimento 27 - Inclus�o na tabela 2 com NativeQuery)");
		
		try {			

			//Escreve a SQL nativa.
			String sql = "INSERT INTO PWORLD.DEPENDENTE ("+
							"ID_DEPENDENTE, "+
							"NOME, "+
							"DATA_NASCIMENTO, "+
							"GRAU_PARENT, "+
							"ID_PESSOA) "+
						    "VALUES("+
							"NEXTVAL('PWORLD.DEPENDENTE_SEQ'), "+
							":param0, "+
							":param1, "+
							":param2, "+
							":param3)";
			
			/* Lista dos parametros da SQL.*/
			List<Object> params = new ArrayList<Object>();			
			params.add("Beto da Silva"); //................NOME::::::::::::: O parametro zero (:param0)
			params.add(DateUtil.getDate("25/08/1870"));//..DATA_NASCIMENTO:: O parametro um   (:param1)
			params.add("Filho"); //.....................  .GRAU_PARENT:::::::O parametro dois (:param2)
			params.add(4L); //...................... ......ID_PESSOA:::::::: O parametro tres (:param3)
			
			//Executa a SQL e loga.
			pessoaFacade.executarNQ(sql, params);					
			Log.setLogger("", "Opera��o efetuada com sucesso.", Level.INFO, Ansi.BLUE);			
			FormatTest.printFooter();			
			
		} catch (DaoException e) {
			e.printStackTrace();
		}

	}

	/* ---------------------------------------
	 *  EXPERIMENTO 28 - Recuperando registros
	 ---------------------------------------*/	
	public void recuperarRegistros(){			
		/* Listar todos os dados de todas as pessoas. Considere ter de fazer isto de forma paginada*/	
		FormatTest.printHeader("ONE TO MANY / MANY TO ONE", 	
						"Experimento 28 - Recuperando registros");
		
		try{	
			List<Pessoa> pessoas = pessoaFacade.listar("Pessoa.all");
			
			for(Pessoa pessoa:pessoas){
				System.out.println(pessoa.getCpf() + " - " + pessoa.getNome());				
				
				if(pessoa.getUsuario() != null){
					System.out.println("Nome de Usu�rio: " + pessoa.getUsuario().getNomeUsuario());
					
				}else{
					Log.setLogger("", "N�o � um usu�rio do sistema.", Level.INFO, Ansi.RED);
				}
								
				System.out.println(pessoa.getLogradouro() + "," + 
					pessoa.getBairro() + "," +
					pessoa.getCidade() + "," +
					pessoa.getUf());	
				
				if(pessoa.getDependentes() != null && pessoa.getDependentes().size() > 0 ){
					System.out.println("DEPENDENTES:");
					for(Dependente dp:pessoa.getDependentes()){
						System.out.println(dp.getNome() + "- "+ dp.getGrauParent());
					}					
				}		
				System.out.println("________________________________________________________");
			}
						
			Log.setLogger("", "Opera��o conclu�da com sucesso!", Level.INFO, Ansi.BLUE);			
			dialogBean.addMessage("Opera��o conclu�da com sucesso!",  DialogType.INFO_CLOSABLE);				
			FormatTest.printFooter();
			
		}catch(DaoException e){		
			e.printStackTrace();			
		}
	}



}

