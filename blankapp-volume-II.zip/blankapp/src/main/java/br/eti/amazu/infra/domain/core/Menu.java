package br.eti.amazu.infra.domain.core;

import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;
import br.eti.amazu.component.pworld.domain.AbstractEntity;

@Entity(name = "Menu")

@Table(schema = "PWORLD", name = "MENU", 
			uniqueConstraints=@UniqueConstraint(name="LABEL_UK", columnNames={"LABEL"}))

@NamedQueries({
	@NamedQuery(name = "Menu.allMenus", query = "select a from Menu a"),		
	
	@NamedQuery(name = "Menu.rootMenus", 
		query = "select a from Menu a where a.menu.id is null or a.menu.id=a.id "
				+ "order by a.ordem"),		
	
	@NamedQuery(name = "Menu.itensMenus", query = "select a from Menu a where a.tipo='2'"),
	
	@NamedQuery(name = "Menu.singleMenu", query = "select a from Menu a "
			+ "where a.label=:param0") 
})
public class Menu extends AbstractEntity<Long>{
	private static final long serialVersionUID = 1L;
	
	public Menu(){	}
	
	public Menu(Long id){
		this.id = id;
	}	
	public Menu(String label){
		this.label = label;
	}
	
	@Id	
	@SequenceGenerator(schema="PWORLD", allocationSize=1, initialValue=1, name="MENU_SEQ",
		sequenceName="MENU_SEQ")	
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "MENU_SEQ")
	@Column(name = "ID_MENU") //nao mapear o tipo do atributo ID (a JPA farah isto)!
	private Long id;

	@Column(name = "LABEL",columnDefinition = "CHARACTER VARYING(70)",nullable=false)
	private String label;
	
	

	@Column(name = "ICON", columnDefinition = "CHARACTER VARYING(30)", nullable=false)
	private String icon;
	
	@Column(name = "TITLE", columnDefinition = "CHARACTER VARYING(30)")
	private String title;

	@Column(name = "ORDEM", columnDefinition = "INTEGER DEFAULT 0", nullable=false )
	private Integer ordem;

	@Column(name = "METODO", columnDefinition = "CHARACTER VARYING(70)")
	private String metodo;
		
	@Column(columnDefinition = "CHAR(1) DEFAULT  '1'", nullable = false)
	private String tipo;  //tipo 0 = grupo, 1 = item
			
	@Column(name="VISIBILITY", columnDefinition = "CHAR(1) DEFAULT  'F'", nullable = false)
	private String visibility;  //se o menu serah publico(T) ou nao(F)
	
	@Column(name="DISABLED", columnDefinition = "CHAR(1) DEFAULT  'F'", nullable = false)
	private String disabled;  //se o menu serah desabilitado(T) ou nao(F)
	
	@Column(name = "SELECTABLE", columnDefinition = "CHAR(1) DEFAULT  'T'", nullable = false)
	private String selectable;  //se o menu serah selecionavel(T) ou nao(F)
	
	@Column(columnDefinition = "CHAR(1) DEFAULT  'F'", nullable = false)
	private String separator;  //se o menu terah (T) ou nao (F) um separador.
	
	/* Autorrelacionamento em Menu (1 : *)
	 * -------------------------------------------
	 * 	LEITURA BIDIRECIONAL: 
	 *		menu 	|  < -------(EAGER)-------->	|  menu
	 *--------------------------------------------
	 *		NAO POSSUI ESCRITA EM CASCATA
	 *------------------------------------------*/
	@ManyToOne(	targetEntity = Menu.class, fetch = FetchType.EAGER, optional=true)
	@JoinColumn(name = "ID_MENU_FK", foreignKey = @ForeignKey(name = "MENU_FK"))	
	private Menu menu;
		
	/* Autorrelacionamento em Menu (* : 1)
	 * --------------------------------------------
	 * 	LEITURA BIDIRECIONAL: 
	 *		menu 	|  < -------(EAGER)-------->	|  menu
	 *-------------------------------------------
	 *		NAO POSSUI ESCRITA EM CASCATA
	 *-----------------------------------------*/
	@OneToMany(	targetEntity = Menu.class, mappedBy = "menu",	fetch = FetchType.EAGER)	
	@OrderBy("ordem")
	private Set<Menu> menus;

	@Version
	@Column(name = "VERSAO", columnDefinition = "INTEGER DEFAULT 0")
	private Integer versao;

	/*----------
	 * get/set
	 ----------*/
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getOrdem() {
		return ordem;
	}

	public void setOrdem(Integer ordem) {
		this.ordem = ordem;
	}

	public String getMetodo() {
		return metodo;
	}

	public void setMetodo(String metodo) {
		this.metodo = metodo;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public String getDisabled() {
		return disabled;
	}

	public void setDisabled(String disabled) {
		this.disabled = disabled;
	}

	public String getSelectable() {
		return selectable;
	}

	public void setSelectable(String selectable) {
		this.selectable = selectable;
	}

	public String getSeparator() {
		return separator;
	}

	public void setSeparator(String separator) {
		this.separator = separator;
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

	public Set<Menu> getMenus() {
		return menus;
	}

	public void setMenus(Set<Menu> menus) {
		this.menus = menus;
	}

	public Integer getVersao() {
		return versao;
	}

	public void setVersao(Integer versao) {
		this.versao = versao;
	}

}
