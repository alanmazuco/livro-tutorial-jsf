package br.eti.amazu.infra.view.util;

import org.apache.log4j.Level;

import br.eti.amazu.infra.util.log.Ansi;
import br.eti.amazu.infra.util.log.Log;

public class FormatTest {
	
	public static void printHeader(String titulo, String subTitulo) {
		
		Log.setLogger("", "*************************************************************",  
				Level.INFO, Ansi.BLACK_YELLOWBG);
		
		Log.setLogger("",titulo, Level.INFO,  Ansi.BLACK_BOLD);
		
		Log.setLogger("", "*************************************************************",  
				Level.INFO, Ansi.BLACK_YELLOWBG);
		
		Log.setLogger("", subTitulo, Level.INFO, Ansi.BLACK_ITALIC);
		
		Log.setLogger("", "-------------------------------------------------------------",
				Level.INFO, Ansi.RED);
	}
	
	public static void printFooter() {
		Log.setLogger("", "-------------------------------------------------------------", 
				Level.INFO, Ansi.BLACK_YELLOWBG);
	}
	
	public static String getTab(){
		return String.format("%-51s", new Object[]{"\n"});
	}
	
}

