package br.eti.amazu.infra;

import br.eti.amazu.infra.util.Crypt;

public class TestCrypt {

	public static void main(String[] args) {
		
		//Gerar o hash para a password "admin"
		String hash = Crypt.getHash("admin");
		
		/*Tanto hash quanto salt 
		 *serao gravados no banco.*/
		System.out.println(hash);
	}
	
}
