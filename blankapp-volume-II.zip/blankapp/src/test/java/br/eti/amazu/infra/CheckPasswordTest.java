package br.eti.amazu.infra;

import br.eti.amazu.infra.util.Crypt;

public class CheckPasswordTest {

	public static void main(String[] args) {		
		System.out.println(
			Crypt.checkPassword("admin", 
					"6B930277F6+HASH+FE7408BC07A51C5F6ED09376AE8DC02311E84BA4EBB20C717EAE0E38CA8222BFB52D63E242317843B06100A8C2BA767A6D431ED9884D65D199AE91233CF96D11"));
	}
}

