package br.eti.amazu.blankapp.persistence.facade;

import java.util.List;
import br.eti.amazu.component.pworld.persistence.exception.MailException;

public interface IAppMailFacade {	
	public void sendMail (String from, String to, String subject,String body, List<String> filesPath) 
			throws MailException, Exception;	
}
