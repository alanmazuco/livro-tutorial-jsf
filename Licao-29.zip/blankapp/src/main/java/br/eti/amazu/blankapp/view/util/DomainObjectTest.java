package br.eti.amazu.blankapp.view.util;

import java.util.Date;
import br.eti.amazu.blankapp.domain.infra.Pessoa;
import br.eti.amazu.blankapp.domain.infra.Usuario;
import br.eti.amazu.util.DateUtil;

public class DomainObjectTest {
	public static Pessoa getPessoa() {
		Pessoa pessoa = new Pessoa();
		pessoa.setNome("Jos� da Silva");
		
		pessoa.setDataNascimento(
				DateUtil.getDate("01/01/1979"));
		
		pessoa.setCpf("999.999.999-99");
		pessoa.setIdt("101010-ES");	
		pessoa.setCep("70730510");	
		pessoa.setUf("DF");
		pessoa.setCidade("Bras�lia");;
		pessoa.setBairro("Asa Sul");
		pessoa.setLogradouro("SCLRN");		
		pessoa.setComplemento("Apto");
		pessoa.setNr("703");
		pessoa.setFone("(27)9999-0000");
		pessoa.setCelular("(27)8888-1111");
		pessoa.setEmail("nome@hot.com");
		return pessoa;
	}
	
	public static Usuario getUsuario() {
		Usuario usuario = new Usuario();
		usuario.setNomeUsuario("user500");
		usuario.setSenha("admin");
		usuario.setBloqueado("F");
		usuario.setDataPrimeiroAcesso(new Date());
		usuario.setPrimeiroAcesso("T");
		return usuario;
	}
}

