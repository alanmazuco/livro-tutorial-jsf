package br.eti.amazu.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import org.joda.time.DateTime;
import org.joda.time.Interval;
import org.joda.time.Period;
import org.joda.time.PeriodType;

public class DateUtil {

	/* Verifica se uma data eh valida, recebendo uma string.
	 ------------------------------------------------------------------------*/
	public static boolean isValidDate(String strDate) {		
		SimpleDateFormat formata = new SimpleDateFormat("dd/MM/yyyy");
		
		try {
			formata.setLenient(false);
			formata.parse(strDate);

		} catch (ParseException e) {
			return false;
		}
		return true;
	}

	/* Retorna uma string da hora atual no formato "HH:MM".
	 --------------------------------------------------------------------------*/
	public static String getStringNowTime() {		
		Date d = new Date();
		SimpleDateFormat format = new SimpleDateFormat("HH:MM");
		return format.format(d);
	}

	/* Retorna uma string do ano atual no formato "yyyy".
	 ---------------------------------------------------------------------*/
	public static String getStringAnoAtual() {		
		Date d = new Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyy");
		return format.format(d);
	}
	
	/* Retorna uma string da data atual no formato "dd/MM/yyyy".
	 -------------------------------------------------------------------------------*/
	public static String getStringNowDate() {		
		SimpleDateFormat in = new SimpleDateFormat("dd/MM/yyyy");
		return in.format(new Date());
	}
	
	/* Retorna uma string da data atual no formato "dd de MES de yyyy".
	 ---------------------------------------------------------------------------------------*/
	public static String getDataMesPorExtenso() {		
		SimpleDateFormat in = new SimpleDateFormat("dd 'de' MMMM 'de' yyyy");
		return in.format(new Date());
	}

	/* Devolve um Date, recebendo uma string "dd/MM/yyyy".
	 -------------------------------------------------------------------------*/
	public static Date getDate(String strDate) {		
		DateFormat formata = new SimpleDateFormat("dd/MM/yyyy");
		
		try {
			formata.setLenient(false);
			return formata.parse(strDate);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	/* Devolve uma string no formato "yyyy-MM-dd".
	-------------------------------------------------------------- */
	public static Date getDateNotFormat(String strDate) {		
		DateFormat formata = new SimpleDateFormat("yyyy-MM-dd");
		
		try {
			formata.setLenient(false);
			return formata.parse(strDate);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	/* Retorna uma string "dd/MM/yyyy", recebendo um Date.
	 --------------------------------------------------------------------------*/
	public static String getStringDate(Date date) {		
		SimpleDateFormat in = new SimpleDateFormat("dd/MM/yyyy");
		return in.format(date);
	}

	/* Verifica se a data informada eh maior que a data atual.
	 -------------------------------------------------------------------------*/
	public static boolean isDataInformadaMaiorDataAtual(Date date) {
		return date.after(new Date()) ? true : false;
	}

	/* Verifica se uma data A eh maior que uma data B.
	----------------------------------------------------------------- */
	public static boolean isDataUmMaiorDataDois(Calendar dataUm, Calendar dataDois) {
		return dataUm.after(dataDois) ? true : false;
	}
	
	/* Verifica se uma data A eh maior que uma data B.
	---------------------------------------------------------------- */
	public static boolean isDataUmMenorDataDois(Calendar dataUm, 	Calendar dataDois) {
		return dataUm.before(dataDois) ? true : false;
	}

	/* Devolve a data por extenso em pt_BR.
	--------------------------------------------------- */
	public static String getDataExtenso(Date data) {		
		SimpleDateFormat in = new SimpleDateFormat("d' de 'MMMM' de 'yyyy", new Locale("pt", "br"));
		return in.format(data);
	}

	/* Verifica a diferenca em dias, entre duas datas.
	------------------------------------------------------------ */
	public static int getDiferencaEntreDatas(Date dataInicial, Date dataFinal) {		
		Long d1 = dataInicial.getTime();
		Long d2 = dataFinal.getTime();
		return (int) Math.floor((d2 - d1) / 1000.0 / 86400.00);
	}
		
	/* Retorna a diferenca entre duas datas no formato "00d 00h 00m"
	------------------------------------------------------------------------------------- */
	public static String getDiferencaEntreDatasEmTempo(Date dataInicial, Date dataFinal){		
		DateTime start = new DateTime(dataInicial);
		DateTime end =  new DateTime(dataFinal);
		Interval interval = new Interval(start, end);
		Period period = interval.toPeriod(PeriodType.yearMonthDayTime());		
		StringBuilder sdate = new StringBuilder();
		
		sdate.append((period.getYears() == 0) ? "" : ((period.getYears() == 1) ? "1 ano " : 
			period.getYears() + " anos "));
		
		sdate.append((period.getMonths() == 0) ? "" : ((period.getMonths() == 1) ? "1 mes " : 
			period.getMonths() + " meses "));
		
		sdate.append((period.getDays() == 0) ? "" : ((period.getDays() == 1) ? "1 dia " : 
			period.getDays() + " dias "));
		
		sdate.append((period.getHours() == 0) ? "" : ((period.getHours() == 1) ? "1 hora " : 
			period.getHours() + " horas "));
		
		sdate.append((period.getMinutes() == 0) ? "" : ((period.getMinutes() == 1) ? "1 minuto " : 
			period.getMinutes() + " minutos "));
		
		sdate.append((period.getSeconds() == 0) ? "" : ((period.getSeconds() == 1) ? "1 segundo " : 
			period.getSeconds() + " segundos "));

		return sdate.toString();	
	}
	
	/* Verifica se uma data estah contida entre duas datas informadas.
	-------------------------------------------------------------------------------------- */
	public static boolean isDataInterpolada(Date dataAnterior, Date data, 	Date dataPosterior) {		
		
		return (data.equals(dataAnterior) || data.equals(dataPosterior))
				|| (data.after(dataAnterior) && data.before(dataPosterior)) ? true : false;
	}

	/* Soma tantos dias a uma data e devolve a nova data somada como String.
	------------------------------------------------------------------------------------------------ */
	public static Date somarDataComDias(Date data, int dias) {
		return getDate(data, dias);
	}	
	
	/* Soma tantos dias a uma data e devolve a nova data somada como Date.
	----------------------------------------------------------------------------------------------- */
	public static String somarDataComDiasReturnString(Date data, int dias) {
		Date novaData = getDate(data, dias);
		SimpleDateFormat in = new SimpleDateFormat("dd/MM/yyyy");
		return in.format(novaData);
	}

	/* Soma tantos anos a uma data e devolve a nova data somada.
	--------------------------------------------------------------------------------- */
	public static Date somarDataComAnos(Date data, int anos) {
		return getDate(data, anos + 365);
	}
	
	/* cronometro regressivo passando a quantidade de dias, uma data inicial e uma data atual
	--------------------------------------------------------------------------------------------------------------------- */
	public static String getCronometro(Date dataInicial, Date dataAtual, int quantDias){
		
		DateTime start = new DateTime(dataAtual);		
		Date dataFinal = DateUtil.somarDataComDias(dataInicial, quantDias);		
		DateTime end =  new DateTime(dataFinal);

		if(end.isBefore(start)) return "00 dias 00 horas e 00 segundos";
		
		Interval interval = new Interval(start, end);
		Period period = interval.toPeriod(PeriodType.yearMonthDayTime());		
		StringBuilder sdate = new StringBuilder();
		
		sdate.append((period.getYears() == 0) ? "" : 
			((period.getYears() == 1) ? "1 ano " : period.getYears() + " anos "));
		
		sdate.append((period.getMonths() == 0) ? "" : 
			((period.getMonths() == 1) ? "1 mes " : period.getMonths() + " meses "));
		
		sdate.append((period.getDays() == 0) ? "" : 
			((period.getDays() == 1) ? "1 dia " : period.getDays() + " dias "));
				
		return sdate.toString();
	}
	
	/* Metodo de apoio...
	 --------------------------*/
	static Date getDate(Date date, int dias) {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		calendar.add(Calendar.DATE, dias);
		Date novaData = calendar.getTime();
		return novaData;
	}
	
}
