package br.eti.amazu.blankapp.persistence.dao;

import br.eti.amazu.component.pworld.persistence.dao.IDao;

public interface IAppDao<T> extends IDao<T> {
	
	/*-------------------------------------------------------------------------------------------------------------------------------------
	 * DAQUI PARA BAIXO, ACRESCENTAR OUTROS METODOS, SE FOR O CASO (TALVEZ NUNCA PRECISE...)
	 -------------------------------------------------------------------------------------------------------------------------------------*/
}
