package br.eti.amazu.blankapp.persistence.facade;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.inject.Inject;
import javax.inject.Named;
import javax.interceptor.Interceptors;

import br.eti.amazu.blankapp.domain.infra.Menu;
import br.eti.amazu.blankapp.persistence.dao.IAppDao;
import br.eti.amazu.blankapp.persistence.exception.ViewInterceptorException;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.component.pworld.persistence.facade.Facade;

@Named
@Stateless
@Interceptors({ViewInterceptorException.class})
@TransactionManagement ( TransactionManagementType.CONTAINER )
@TransactionAttribute ( TransactionAttributeType.SUPPORTS )
public class AppFacade<T> extends Facade<T> implements IAppFacade<T> {
	
	@Inject
	private IAppDao<T> dao;
		
	@PostConstruct
	public void initDao(){
		super.setDao(dao);
	}

	/*-------------------------------------------------------------------------------------------------
	 * DAQUI PARA BAIXO, ACRESCENTAR OUTROS METODOS, SE FOR O CASO...
	 -------------------------------------------------------------------------------------------------*/	
	
	@SuppressWarnings("unchecked")
	@TransactionAttribute ( TransactionAttributeType.REQUIRED )
	public void demonstrarRollBack() throws DaoException{
		
		/* Atencao para o bloco try-catch de um metodo com varias idas ao banco.
		 * Quando  queremos que todas essas idas estejam dentro de uma transacao, deve-se lancar
		 * Exception com throw new DaoException, para que a exception possa ser interceptada. */
		try{
			
			//setando todos os outros atributos requeridos (eh um teste...).
			Menu menu1 = new Menu("Teste");
			menu1 = instancieMenu(menu1);
							
			//chama o metodo do dao para incluir o menu1.
			dao.insert((T) menu1);
			Menu menu2 = new Menu("Testeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
			
			//chama o metodo do dao para incluir o menu2 e loga.
			dao.insert((T) menu2);	
			
			//O 	metodo flush eh o "commit" da transacao. Ele deve ser a ultima linha do metodo transacional.
			dao.flush();						
			
		}catch(DaoException e){
			e.printStackTrace();
			
		}catch(Exception e){
			e.printStackTrace();				
			throw new DaoException(e.getMessage());		
		}
	}
	
	
	Menu  instancieMenu(Menu menu){
		
		//setando todos os outros atributos requeridos (eh um teste...).
		menu.setTipo("1"); //O tipo do menu
		menu.setOrdem(0); //a ordem do menu
		menu.setVisibility("F"); // O menu nao serah visivel a todos.
		menu.setDisabled("F"); // O menu nao  serah desabilitado.
		menu.setSelectable("T"); //O menu serah selecionavel.
		menu.setSeparator("F"); //O menu nao terah separador.
		
		// O icone que serah renderizado no menu - igual para todos (eh um teste...).
		menu.setIcon("edit_pen.gif"); 	
	
		return menu; //...e retorna o menu perfeitamente sincronizado com o banco de dados.
	}			

}
