package br.eti.amazu.blankapp.view.bean.showcase.mapeamentos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.apache.log4j.Level;
import br.eti.amazu.blankapp.domain.brasil.Logradouro;
import br.eti.amazu.blankapp.domain.brasil.Pais;
import br.eti.amazu.blankapp.domain.infra.Dependente;
import br.eti.amazu.blankapp.domain.infra.Funcionalidade;
import br.eti.amazu.blankapp.domain.infra.Perfil;
import br.eti.amazu.blankapp.domain.infra.Pessoa;
import br.eti.amazu.blankapp.domain.infra.Usuario;
import br.eti.amazu.blankapp.persistence.facade.IAppFacade;
import br.eti.amazu.blankapp.view.util.FormatTest;
import br.eti.amazu.component.dialog.DialogBean;
import br.eti.amazu.component.dialog.DialogType;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.util.log.Ansi;
import br.eti.amazu.util.log.Log;

@Named
@RequestScoped
public class ManyToManyCaseBean implements Serializable{

	private static final long serialVersionUID = 1L;
	@Inject
	IAppFacade<Perfil> perfilFacade;
	
	@Inject
	IAppFacade<Usuario> usuarioFacade;
	
	@Inject
	IAppFacade<Pessoa> pessoaFacade;
	
	@Inject
	IAppFacade<Funcionalidade> funcionalidadeFacade;
	
	@Inject
	IAppFacade<Logradouro> logradouroFacade;
	
	@Inject
	IAppFacade<Pais> paisFacade;
	
	@Inject
	DialogBean dialogBean;

		
	/* -----------------------------------------------
	 *  EXPERIMENTO 29 - Incluir lado Um da associa��o
	 ------------------------------------------------*/	
	public void incluirLadoUmDaAssociacao() {
		
		/* Para persistir Usuario, executar os experimentos da Licao 29.
		 * Neste experimento vamos incluir PERFIL que, embrora seja o lado Dois da associacao USUARIO-PERFIL,
		 * tambem eh o lado Um da associacao PERFIL-FUNCIONALIDADE.
		 * (muito embora na pratica nao se distingue esses lados).
		 * 
		 * Existe mais de uma forma de se incluir. Uma delas eh realizando a associacao com um objeto perfil em 
		 * estado NEW (ver o experimento 31), a outra eh simplesmente utlizando o objeto pessoa em estado 				
		 * NEW com uma fachada de perfil (perfilFacade).*/
		
		FormatTest.printHeader("MANY TO MANY", "Experimento 29 - Incluir e associar concomitantemente");				
		try {
		
			//Criando um novo perfil
			Perfil perfil = new Perfil();
			perfil.setNome("VISITANTE");
			perfil.setCodPerfil(35);
			
			perfilFacade.incluir(perfil); //apenas inclui
			
			Log.setLogger("", "incluiu " + perfil.getNome().toUpperCase() + 
					" com sucesso!", Level.INFO,  Ansi.BLUE);
			
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			e.printStackTrace();
		}

	}
	
	/* -------------------------------------------------
	 *  EXPERIMENTO 30 - Incluir lado Dois da associa��o
	 --------------------------------------------------*/	
	public void incluirLadoDoisDaAssociacao() {
		
		/* Neste experimento vamos incluir FUNCIONALIDADE que eh o lado Dois da associacao PERFIL-FUNCIONALIDADE.
		 * (muito embora na pratica nao se distingue esses lados).
		 * 
		 * Existe mais de uma forma de se incluir. Uma delas eh realizando a associacao com um objeto funcionalidade
		 * em estado NEW, a outra eh simplesmente utlizando o objeto funcionalidade em estado NEW com
		 * uma fachada de funcionalidade (funcionalidadeFacade).*/
		
		FormatTest.printHeader("MANY TO MANY", "Experimento 30 - Incluir e associar concomitantemente");		
		
		try {	
			
			//verifica se a funcionalidade jah existe.
			Funcionalidade funcionalidade = funcionalidadeFacade.recuperar(Funcionalidade.class, 1L);
			
			//se enconrou uma funcionalidade com o ID informado...
			if(funcionalidade != null){
				
				dialogBean.addMessage("J� existe a funcionalidade com id = " + funcionalidade.getId(), 
						DialogType.INFO_CLOSABLE);
				
				Log.setLogger("", "J� existe uma funcionalidade com id = " + funcionalidade.getId(), 
						Level.INFO, Ansi.RED);
				
				FormatTest.printFooter();			
				
				return;
			}
			
			//Nao encontrando uma funcionalidade igual, instancia uma nova...
			funcionalidade = new Funcionalidade();
			funcionalidade.setId(1L);
			funcionalidade.setLabel("/mm_keyLabel_login");
			funcionalidade.setDisabled("F");
			funcionalidade.setVisibility("F");
			
			//..,e inclui definitivo no banco de dados.
			funcionalidadeFacade.incluir(funcionalidade);
			
			dialogBean.addMessage("Incluiu a funcionalidade com sucesso!", DialogType.INFO_CLOSABLE);			
			Log.setLogger("", "Incluiu a funcionalidade com sucesso!", 	Level.INFO, Ansi.BLUE);			
			FormatTest.printFooter();
				
		} catch (DaoException e) {
			e.printStackTrace();
		}	
	}
	
	/* ------------------------------------------------------
	 *  EXPERIMENTO 31 - Incluir e associar concomitantemente
	 ------------------------------------------------------*/
	public void incluirAssociarConcomitante() {
		
		/* Incluir um registro na tabela PERFIL realizando o persist em cima do objeto usuario.
		 * Neste caso, recuperando o usuario pelo objeto pessoa (e persistindo em pessoa) ==> por cascata,
		 * haverah tambem a persistencia de um registro na tabela associativa USUARIO_PERFIL*/
		
		FormatTest.printHeader("MANY TO MANY", "Experimento 31 - Incluir e associar concomitantemente");		
		
		try {
			
			Pessoa pessoa = pessoaFacade.recuperar(Pessoa.class, 1L); //Buscando uma pessoa com id conhecido
			
			if(pessoa != null) {
				
				//Criando um novo perfil
				Perfil perfil = new Perfil();
				perfil.setNome("ALUNO");
				perfil.setCodPerfil(2);
												
				//adicionando o perfil na lista de perfis do usuario recuperado em pessoa que foi buscada
				pessoa.getUsuario().getPerfis().add(perfil);
										
				/* Ao alterar pessoa, um registro na tabela PERFIL serah incluido, e tambem um registro na	
				 * tabela associativa USUARIO_PERFIL. */
				pessoaFacade.alterar(pessoa); 
				
				Log.setLogger("", "incluiu " + perfil.getNome().toUpperCase() + " e o associou com o usu�rio " + 
						pessoa.getUsuario().getNomeUsuario() + " com sucesso!", Level.INFO,  Ansi.BLUE);
				
			}else {
				dialogBean.addMessage("N�o encontoru a pessoa pesquisada." , DialogType.ERROR);
			}
			
			FormatTest.printFooter();
				
		} catch (DaoException e) {
			e.printStackTrace();
		}			
	}
	
	/* ----------------------------
	 *  EXPERIMENTO 32 - Associando
	 -----------------------------*/	
	public void associar(){
		
	    /* Perceba que a leitura entre os dois objetos eh bidirecional:
		 * 
		 * perfil ---(EAGER)---> funcionalidade;
		 * perfil <---(LAZY)---- funcionalidade.
		 *
		 * Sempre ao carregar um perfil, todas as suas funcionalidades serao carregadas <EAGER>.
		 * Sempre ao carregar uma funcionalidade, seus perfis soh serao carregados se o 
		 * desenvolvedor quiser isto, pela primeira vez (LAZY).
		 *
		 * Perceba, tambem, que a escrita entre os dois objetos eh unidirecional:
		 * 
		 * perfil  ---(write)--> funcionalidade.
		 *
		 * - Entao, a verdadeira persistencia de objetos manyToMany se resume em 
		 *  uma simples atualizacao na  tabela associativa (apenas "update" em um dos
		 *  lados da associacao).	
		 * 
		 * Assim:
		 *
		 * UPDATE: Fa�a a associa��o entre os dois objetos:
		 * 
		 *        1) recupere o objeto perfil;
		 *        
		 *        2) recupere o objeto funcionalidade;
		 *        
		 *        3) adicione a funcionalidade na lista de funcionalidades de perfil, assim:
		 *            perfil.getListaFuncionalidades().add(funcionalidade);
		 *                  
		 *        4) faca um update em cima de perfil;
		 *        
		 *        5) o resultado final eh a inclusao de um registro na tabela 
		 *            PERFIL_FUNCIONALIDADE.
		 *
	     * - PARA REALIZAR ESTE TESTE, ABRA A TABELA PERFIL_FUNCIONALIDADE E 
		 *   APAGUE TODOS OS REGISTROS,   
		 *   ou use a instrucao "delete from PERFIL_FUNCIONALIDADE" (usando o pgAdmin).
		 * 
		 * EH NECESSARIO UM REGISTRO NA TABELA PERFIL E OUTRO NA TABELA
		 * FUNCIONALIDADE. */
		
		FormatTest.printHeader("MANY TO MANY", "Experimento 32 - Associando");		
		
		try {						
			// Recupera o perfil: entre com o id de um perfil.
			Perfil perfil = perfilFacade.recuperar(Perfil.class, 1L);	
			
			// Recupera a funcionalidade: Entre com o id de uma funcionalidade.
			Funcionalidade funcionalidade = funcionalidadeFacade.recuperar(Funcionalidade.class, 1L);			

			
			//se perfil e funcionalidades forem diferentes de nulo...
			if (perfil != null && funcionalidade != null) {
			
				//antes, verifica se o perfil recuperado nao possui funcionalidade...
				if (!perfil.getFuncionalidades().isEmpty()) {
					
					for (int i = 0; i < perfil.getFuncionalidades().size(); i++) {
						
						/* O perfil possuia funcionalidades. Entao, nao deixa adicionar as
						 * que ele jah possui. 
						 * */						
						if (perfil.getFuncionalidades().contains(funcionalidade)) {
							
							dialogBean.addMessage("Os dois objetos j� estavam associados.", 
									DialogType.INFO_CLOSABLE);
							
							Log.setLogger("", "Os dois objetos j� estavam associados.", 
									Level.INFO, Ansi.RED);
							
							FormatTest.printFooter();
							
							return;
						}
					}	
				}			
			
				//Adiciona somente as funcionalidades que o perfil nao possui.
				perfil.getFuncionalidades().add(funcionalidade);
				
				//insere um registro na tabela PERFIL_FUNCIONALIDADE.
				perfilFacade.alterar(perfil); 
				
				dialogBean.addMessage("Associou a funcionalidade " + 
						funcionalidade.getLabel() + "\n ao perfil " + perfil.getNome(), 
						DialogType.INFO_CLOSABLE);
				
				Log.setLogger("", "Associou a funcionalidade " + 
						funcionalidade.getLabel() + "\n ao perfil " + perfil.getNome(), 
						Level.INFO, Ansi.BLUE);
			
			} else {
				dialogBean.addMessage("Est� faltando um dos lados da ssocia��o ", 
						DialogType.INFO_CLOSABLE);
				
				Log.setLogger("", "Est� faltando um dos lados da ssocia��o", 
						Level.INFO, Ansi.RED);
			}
		
			FormatTest.printFooter();
			
		} catch (DaoException e) {
			e.printStackTrace();
		}		
	
	}

	/* -------------------------------
	 *  EXPERIMENTO 33 - Desassociando
	 --------------------------------*/	
	public void desassociar(){
		
		/*A desassocia��o entre os objetos implica na exclus�o automatica
		* dentro da tabela associativa (no exemplo, PERFIL_FUNCIONALIDADE, que eh a tabela associativa). */
		
		FormatTest.printHeader("MANY TO MANY", "Experimento 33 - Desassociando");		
		
		try {								
			
			Perfil perfil = perfilFacade.recuperar(Perfil.class, 1L); // Recupera o perfil.
			
			// Recupera a funcionalidade.
			Funcionalidade funcionalidade = funcionalidadeFacade.recuperar(Funcionalidade.class, 1L);
									
			if (perfil != null && funcionalidade != null) { //Se encontrou...
								
				if (perfil.getFuncionalidades().isEmpty()) { // Verifica se perfil estah associado.					
					dialogBean.addMessage("Perfil n�o possui nenhuma associa��o com funcionalidade.", 
							DialogType.INFO_CLOSABLE);
					
					Log.setLogger("", "Perfil n�o possui nenhuma associa��o com funcionalidade.", 
							Level.INFO, Ansi.BLUE);
					
				} else {					
					perfil.getFuncionalidades().remove(funcionalidade); //Desassocia.
					perfilFacade.alterar(perfil); // persiste.
					
					dialogBean.addMessage("Desassociou a funcionalidade \n"
							+ funcionalidade.getLabel() + "\n" + "do perfil " + perfil.getNome(), 
							DialogType.INFO_CLOSABLE);
					
					Log.setLogger("", "Desassociou a funcionalidade \n"
								+ funcionalidade.getLabel() + "\n" + "do perfil " + perfil.getNome(), 
							Level.INFO, Ansi.BLUE);
				}								
				
			} else {
				dialogBean.addMessage("Est� faltando um dos lados da ssocia��o ", 
						DialogType.INFO_CLOSABLE);
				
				Log.setLogger("", "Est� faltando um dos lados da ssocia��o", 
						Level.INFO, Ansi.RED);
			}			
			FormatTest.printFooter();
				
		} catch (DaoException e) {
			e.printStackTrace();
		}			
	}
	
	/* --------------------------------------------
	 *  EXPERIMENTO 34 - Modificando as Associacoes
	 --------------------------------------------*/	
	public void modificarAssociacoes(){
		
		/* Isto aqui pode ser feito de varias formas:
		 * - Recuperar uma lista de funcionalidades de um perfil e nela, adicionar novas
		 * funcionalidades;
		 * - Apagar completamente a lista de funcionalidades de um perfil e adicionar uma nova;
		 * - etc.
		 * Neste exemplo estamos recuperando todas as funcionalidades do sistema e associando-as
		 * ao perfil do DESENVOLVEDOR. */
			
		FormatTest.printHeader("MANY TO MANY", "Experimento 34 - Modificando Associa��es");		
		
		try {		
						
			// Recupera o perfil: entre com o id de um perfil.
			Perfil perfil = perfilFacade.recuperar(Perfil.class, 1L);
			
			//Se encontrou o perfil  procurado...
			if (perfil != null) {
				@SuppressWarnings("unchecked")
				Set<Funcionalidade> funcionalidades = (Set<Funcionalidade>) funcionalidadeFacade.listar("Funcionalidade.all");
				perfil.setFuncionalidades(funcionalidades);
				
				/* Neste caso apagando todas as funcionalidades do perfil (se eh
				 * que ele possuia alguma) e criando outra nova, tudo atualizando,
				 * criando ou excluindo na tabela PERFIL_FUNCIONALIDADE.
				 * Veja o log SQL no console do Eclipse como ocorre os deletes, depois os inserts...*/
				perfilFacade.alterar(perfil);
						
				dialogBean.addMessage("Opera��o efetuada com sucesso.", 
						DialogType.INFO_CLOSABLE);
				
				Log.setLogger("", "Opera��o efetuada com sucesso", Level.INFO, Ansi.RED);
				
			} else {
				dialogBean.addMessage("Est� faltando um dos lados da ssocia��o ", 
						DialogType.INFO_CLOSABLE);
				
				Log.setLogger("", "Est� faltando um dos lados da ssocia��o", 
						Level.INFO, Ansi.RED);
			}
			
			FormatTest.printFooter();
				
		} catch (DaoException e) {
			e.printStackTrace();
		}			

	}
	
	/* -----------------------------
	 *  EXPERIMENTO 35 - Listar tudo 
	 -----------------------------*/	
	public void listarTudo(){	
		
		/* Listando tudo - providencie massa de dados, se for o caso, agindo
		 * diretamente no banco de dados com o PGAdmin.
		 */
		
		try{
			
			Logradouro logradouro = null;						
			FormatTest.printHeader("MANY TO MANY", "Experimento 35 - Listar tudo");
			
			//Recupera uma pessoa de id conhecido.
			Pessoa pessoa = pessoaFacade.recuperar(Pessoa.class, 1L);										
			
			if (pessoa == null) {
				Log.setLogger("", "A consulta retornou nula. Forne�a um id v�lido", Level.INFO, Ansi.RED);
								
			}else {	
				
				//Recupera o endereco da pessoa baseada em seu CEP (agir no banco de dados - providencie os dados).
				List<Object> params = new ArrayList<Object>();
				params.add(pessoa.getCep());
				logradouro = logradouroFacade.recuperar("Logradouro.peloCep", params);	
				
				if(logradouro != null) {
					
					Log.setLogger("", "NOME" + pessoa.getNome().toUpperCase()+ ": ", Level.INFO, Ansi.BLUE);
										
					Log.setLogger("", 	logradouro.getNome()+ "," + 
										logradouro.getBairro().getNome()+ "," + 
										logradouro.getBairro().getCidade().getNome() + "," +
										logradouro.getBairro().getCidade().getUf().getSigla(), 
										Level.INFO, Ansi.BLUE);
					
				}else {
					Log.setLogger("", "N�o existe um logradouro para o CEP informado.", Level.INFO, Ansi.RED);
				}
				
				if (pessoa.getUsuario() != null) {
					
					Log.setLogger("", "USU�RIO: " + pessoa.getUsuario().getNomeUsuario(), Level.INFO, Ansi.BLUE);
					Log.setLogger("", "SENHA: " + pessoa.getUsuario().getSenha(), Level.INFO, Ansi.BLUE);
										
					//listando os perfis do usuario
					if (pessoa.getUsuario().getPerfis() != null) {
						for(Perfil perfil:pessoa.getUsuario().getPerfis()) {
							Log.setLogger("", "PERFIL: " + perfil.getNome(), Level.INFO, Ansi.BLUE);
							
							
							//listando as funcionalidades que possui o perfil da pessoa buscada
							if(perfil.getFuncionalidades() != null && perfil.getFuncionalidades().size() > 0) {
								
								//loga todas as funcionalidades de cada perfil do usuario
								for(Funcionalidade funcionalidade : perfil.getFuncionalidades()) {
									Log.setLogger("", funcionalidade.getLabel(), Level.INFO, Ansi.BLUE);									
								}
								
							}else {
								Log.setLogger("", "O perfil deste usu�rio est� sem funcionalidades.", 
										Level.INFO, Ansi.RED);
							}
						}		
						
					}else {
						Log.setLogger("", "O usu�rio pesquisado est� sem Perfil.", Level.INFO, Ansi.RED);
					}
					
				} else {
					Log.setLogger("", "USUARIO: n�o � usu�rio do sistema", Level.INFO, Ansi.RED);
				}	
				
				Log.setLogger("", "DEPENDENTES: ", Level.INFO, Ansi.BLUE);			
								
				if (!pessoa.getDependentes().isEmpty()) {
					
					//Loga cada dependente da pessoa.
					for (Dependente dependente : pessoa.getDependentes()) {
						Log.setLogger("", dependente.getNome(), Level.INFO, Ansi.BLUE);						
					}			
					
				} else {
					Log.setLogger("", "Esta pessoa n�o possui dependentes.", Level.INFO, Ansi.RED);		
				}								
			} 				
			
		} catch (DaoException e) {
			e.printStackTrace();
		}		
		FormatTest.printFooter();		
	}	
	
}