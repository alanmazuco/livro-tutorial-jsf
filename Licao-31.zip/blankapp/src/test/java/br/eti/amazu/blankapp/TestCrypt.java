package br.eti.amazu.blankapp;

import br.eti.amazu.util.Crypt;

public class TestCrypt {

	public static void main(String[] args) {
		
		//Gerar o hash para a password "admin"
		String hash = Crypt.getHash("admin");
		
		/*Tanto hash quanto salt 
		 *serao gravados no banco.*/
		System.out.println(hash);
	}
	
}
