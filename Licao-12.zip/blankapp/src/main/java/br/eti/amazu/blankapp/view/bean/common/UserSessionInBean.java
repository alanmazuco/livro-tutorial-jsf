package br.eti.amazu.blankapp.view.bean.common;

import java.io.Serializable;
import java.util.Locale;

import br.eti.amazu.util.FacesUtil;

import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named
@SessionScoped
public class UserSessionInBean implements Serializable {

	private static final long serialVersionUID = -2765013996497920460L;
	
	//Dados de usuario comum do sistema
	private String senhaAdmPostgreSQL;	
	private String pessoaLogged;
	private String userLogged;
	private Integer codPerfilUserLogged;
	
	private Locale locale;
	
	public UserSessionInBean(){
		
		/* Locale */
		this.setLocale(FacesUtil.getLocale()); //Obtem o idioma local (do Sistema Operacional).	
	}
   
	/* Um botao de acao de uma pagina qualquer pode mudar o idioma,
	 * mas tem de passar um parametro para qual idioma a ser mudado.
	 *------------------------------------------------------------*/
	public void mudarIdioma(){
		String localeStr = FacesUtil.getParam("locale");
		if(localeStr.length() == 2){
			locale = new Locale(localeStr);
			
		}else{			
			locale = new Locale(localeStr.substring(0,2), localeStr.substring(3));
		}
		FacesUtil.setLocale(locale);		
		System.out.println(FacesUtil.getMessage("MGL064",new String[]{localeStr}));
	}
	
	/*--------
	 * get/set
	 --------*/
			
	public void returnHomePage(){
		FacesUtil.redirect("/pages/home/homePage");
	}	
	public void reload(){		
		FacesUtil.redirect(FacesUtil.getUrlInView());
	}
	public String getSenhaAdmPostgreSQL() {
		return senhaAdmPostgreSQL;
	}
	public void setSenhaAdmPostgreSQL(String senhaAdmPostgreSQL) {
		this.senhaAdmPostgreSQL = senhaAdmPostgreSQL;
	}
	public String getPessoaLogged() {
		return pessoaLogged;
	}
	public void setPessoaLogged(String pessoaLogged) {
		this.pessoaLogged = pessoaLogged;
	}
	public String getUserLogged() {
		return userLogged;
	}
	public void setUserLogged(String userLogged) {
		this.userLogged = userLogged;
	}
	public Integer getCodPerfilUserLogged() {
		return codPerfilUserLogged;
	}
	public void setCodPerfilUserLogged(Integer codPerfilUserLogged) {
		this.codPerfilUserLogged = codPerfilUserLogged;
	}
	public Locale getLocale() {
		return locale;
	}
	public void setLocale(Locale locale) {
		this.locale = locale;
	}	
}
