package br.eti.amazu.blankapp.view.bean.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import br.eti.amazu.blankapp.view.vo.Config;
import br.eti.amazu.util.FacesUtil;

import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named
@SessionScoped
public class ConfigBean implements Serializable{
	
	private static final long serialVersionUID = -6663659948453061860L;
	
	//O objeto config contem as variaveis de configuracoes do sistema.
	private Config config;
	
	private String skinTheme;
	
	//Armazena uma lista de idiomas suportados.
	private List<String> locales = new ArrayList<String>();
	
	public void setConfiguracoes(){
		
		/* Aqui carregando parametros defalt, a titulo de demonstracao.
		 * Posteriormente esses dados serao obtidos de um arquivo de configuracoes. */
			
		config = new Config();
		
		/* TIPOS DE MENU: 
		 * - menuBar -------------	HORIZONTAL (default)
		 * - tiered --------------	VERTICAL
		 * - slide ---------------  VERTICAL
		 * - panelMenu -----------  VERTICAL */	
		config.setMenuType("menuBar"); //O menu default eh menuBar (horizontal).	

		//Setando os diversos parametros de skin para o aplicativo.
		config.setAnimatedTop("F"); //O topo default eh "nao-animado".				
		config.setSkinBackground("vetruvian"); //O skin default eh o vetruvian.
		config.setSkinImageLogo("amazuLogo"); //O nome da imagem logotipo da empresa.
		config.setSkinLogo("T"); //O topo default contem o logotipo da empresa.
		config.setSkinTextLogo("Tecnologia Java"); //O texto default do logotipo eh "Tecnologia Java".
		config.setSkinColorTextLogo("13f02d"); //A cor default do texto do logotipo eh verde;	
		
		//Isto eh o que serah escrito no rodapeh da pagina.
		config.setSkinFooter("Privacy Policy | Amazu Technology | Copyright \u00A9 2018 - All rights reserved");
				
		//O tema default eh o aristo.
		skinTheme="aristo";	
		config.setSkinTheme("primefaces-" + skinTheme); 
			
		//logs
		System.out.println("Rodando o tema: " + config.getSkinTheme());
		System.out.println("Rodando o skin: " + config.getSkinBackground());
		System.out.println("Rodando o menu: " + config.getMenuType());				
	}
	
	/*--------
	 * get/set
	 -------*/	
	public Config getConfig() {
		if(config == null){
			this.setConfiguracoes();
		}

		return config;
	}
	
	public void setConfig(Config config) {
		this.config = config;
	}		
	public String getSkinTheme() {
		return skinTheme;
	}
	public void setSkinTheme(String skinTheme) {
		this.skinTheme = skinTheme;
	}
	public List<String> getLocales() {
		
		//Utliza a classe FacesUtil para obter a lista de idiomas suportados.
		if(locales.isEmpty()){
			locales = FacesUtil.getLocales();
			
			//realiza apenas um log
			StringBuffer strb = new StringBuffer();
			strb.append("Linguagens suportadas: ");
			
			int i=1;
			for(String str:locales){				
				if(i == locales.size()){
					strb.append(str);
					
				}else{
					strb.append(str + ", ");
				}
				i++;
			}
			System.out.println(strb.toString());
		}
		return locales;
	}
	
	public void setLocales(List<String> locales) {
		this.locales = locales;
	}
	
}
