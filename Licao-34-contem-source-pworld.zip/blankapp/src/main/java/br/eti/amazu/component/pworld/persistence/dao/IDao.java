package br.eti.amazu.component.pworld.persistence.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;

import br.eti.amazu.component.pworld.persistence.exception.DaoException;

public abstract interface IDao<T> {

	
	/**********
	 * NO QUERY
	 *********/
	public void insert(T obj) throws DaoException;	
	public void delete(T obj) throws DaoException;	
	public void update(T obj) throws DaoException;
	
	public T find(Class<T> t, Long pk) throws DaoException;	
	public T find(Class<T> t, Integer pk) throws DaoException;	
	public T find(Class<T> t, String pk) throws DaoException ;
	
	
	/*************
	 * NAMEDQUERY
	 *************/	
	public List<T> list(String namedQuery) throws DaoException;
	public List<T> list(String namedQuery, List<Object> params) throws DaoException;	
	
	public List<T> listPagination(String namedQuery, List<Object> params, int first, int pageSize)
				throws DaoException;
	
	public T singleResult(String namedQuery, List<Object> params) throws DaoException;
	public int maxResult(String namedQuery, List<Object> params) throws DaoException;
	public boolean execute(String namedQuery, List<Object> params) throws DaoException;	
	public T minMaxFromExpression(String namedQuery, List<Object> params) throws DaoException;
			
	
	/*************
	 * NATIVEQUERY
	 *************/
	public List<T> listNQ(T t, String nativeQuery) throws DaoException;
	public List<T> listNQ(T t, String nativeQuery, List<Object> params) throws DaoException;
	public List<T> listNQ(String nativeQuery) throws DaoException;	
	public List<T> listNQ(String nativeQuery, List<Object> params) throws DaoException;	
	
	public List<T> listPaginationNQ(T t, String nativeQuery, List<Object> params, int first, int pageSize) 
				throws DaoException;
	
	public List<Object[]> listObjectNQ(String nativeQuery, List<Object> params)  throws DaoException;
	
	public T singleResultNQ(T t, String nativeQuery, List<Object> params) throws DaoException;		
	public T singleResultNQ(String nativeQuery) throws DaoException;
	public T singleResultNQ(String nativeQuery, List<Object> params) throws DaoException;	
	
	public boolean executeNQ(String nativeQuery) throws DaoException;
	public boolean executeNQ(String nativeQuery, List<Object> params) throws DaoException;	
		
	public int maxResultNQ(String nativeQuery) throws DaoException;	
	public int maxResultNQ(String nativeQuery, List<Object> params) throws DaoException;
	
	public Long getSequenceNQ(String sequenceName) throws DaoException;
	
	
	/********************************************************
	 * MANIPULA��O DO ENTITY MANAGER - Apenas objetos persistentes.
	 ********************************************************/	
	public void clear();
	
	public void refresh(Object obj);
	public void refresh(Object obj, LockModeType lockModeType);	
	
	public boolean isManaged(Object obj);
	public void lock(Object obj, LockModeType loModeType);
	public void flush();
	public void detach(Object obj);
	public Object get(Class<T> t, Object obj) ;
	public EntityManager getEntityManager() ;
	public void setEntityManager(EntityManager entityManager);

}

