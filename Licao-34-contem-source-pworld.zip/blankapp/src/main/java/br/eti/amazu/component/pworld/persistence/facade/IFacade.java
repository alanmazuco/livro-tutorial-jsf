package br.eti.amazu.component.pworld.persistence.facade;

import java.util.List;

import javax.persistence.LockModeType;

import br.eti.amazu.component.pworld.persistence.dao.IDao;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;

public abstract interface IFacade<T> {
	
	/**********
	 * NO QUERY
	 *********/
	public void incluir(T obj) throws DaoException;	
	public void excluir(T obj) throws DaoException;	
	public void alterar(T obj) throws DaoException;
	
	public Object alterarAtualizar(T obj) throws DaoException;
	
	public T recuperar(Class<T> t, Long pk) throws DaoException;	
	public T recuperar(Class<T> t, Integer pk) throws DaoException;	
	public T recuperar(Class<T> t, String pk) throws DaoException ;
		
	
	/*************
	 * NAMEDQUERY
	 *************/
	public List<T> listar(String namedQuery) throws DaoException;
	public List<T> listar(String namedQuery, List<Object> params) throws DaoException;	
	
	public List<T> listartPaginado(String namedQuery, List<Object> params, int first, int pageSize)
				throws DaoException;
	
	public T recuperar(String namedQuery, List<Object> params) throws DaoException;
	public int recuperarMaxResult(String namedQuery, List<Object> params) throws DaoException;
	public boolean executar(String namedQuery, List<Object> params) throws DaoException;	
	public T recuperarMinMax(String namedQuery, List<Object> params) throws DaoException;
	

			
	/*************
	 * NATIVEQUERY
	 *************/
	public List<T> listarNQ(T t, String nativeQuery) throws DaoException;
	public List<T> listarNQ(T t, String nativeQuery, List<Object> params) throws DaoException;
	public List<T> listarNQ(String nativeQuery) throws DaoException;	
	public List<T> listarNQ(String nativeQuery, List<Object> params) throws DaoException;	
		
	public List<T> listarPaginadorNQ(T t, String nativeQuery, List<Object> params, int first, int pageSize) 
				throws DaoException;
	
	public List<Object[]> listarObjetosNQ(String nativeQuery, List<Object> params) 	throws DaoException;
	
	public T recuperarNQ(T t, String nativeQuery, List<Object> params) throws DaoException;		
	public T recuperarNQ(String nativeQuery) throws DaoException;
	public T recuperarNQ(String nativeQuery, List<Object> params) throws DaoException;	
	
	public boolean executarNQ(String nativeQuery) throws DaoException;
	public boolean executarNQ(String nativeQuery, List<Object> params) throws DaoException;	
		
	public int recuperarMaxResultNQ(String nativeQuery) throws DaoException;	
	public int recuperarMaxResultNQ(String nativeQuery, List<Object> params) throws DaoException;
	
	public Long recuperarSequenceNQ(String sequenceName) throws DaoException;	
	
	
		
	/**************************************************************
	 * MANIPULA��O DO ENTITY MANAGER - Apenas objetos persistentes.
	 *************************************************************/	
	public void clear();
	public void refresh(Object obj, LockModeType lockModeType);
	public void refresh(Object obj);
	public boolean isManaged(Object obj);
	public void lock(Object obj, LockModeType loModeType);
	public void flush();
	public void detach(Object obj);
	public Object get(Class<T> t, Object obj) ;
	public IDao<T> getDao();
	public void setDao(IDao<T> dao);
	
}

