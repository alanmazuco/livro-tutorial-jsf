package br.eti.amazu.blankapp.persistence.facade;

import java.io.Serializable;
import java.util.List;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.annotation.Resource;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.inject.Named;
import javax.interceptor.Interceptors;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.apache.log4j.Level;
import br.eti.amazu.component.pworld.persistence.exception.InterceptorException;
import br.eti.amazu.component.pworld.persistence.exception.MailException;
import br.eti.amazu.util.log.Log;

@Named
@Stateless
@Interceptors({InterceptorException.class})
public class AppMailFacade implements IAppMailFacade, Serializable {
	private static final long serialVersionUID = 5621369769880979458L;
	
	@Resource(name = "java:jboss/mail/blankappMail") //Nome do Recurso que criamos no Wildfly
    private Session mailSession; //Objeto que vai representar uma sess�o de email
		
	@Override
	@Asynchronous
	public void sendMail(String from, String to, String subject, String body, List<String> filesPath) 
					throws MailException, Exception {
    	    	    			
        Log.setLogger("", "Sending mail..." , Level.INFO);
        try {
        	
            //Criacao de uma mensagem simples
            Message message = new MimeMessage(mailSession);
                                    
            //Cabecalho do Email
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to));            
            message.setSubject(subject);             
            MimeBodyPart textPart = new MimeBodyPart();
            textPart.setContent(body, "text/plain");
            Multipart mps = new MimeMultipart();
            
            //Adicionando arquivos anexos
            if(filesPath != null && filesPath.size()>0){
          	  
	              for (int index = 0; index < filesPath.size(); index++) {                  
	                  MimeBodyPart attachFilePart = new MimeBodyPart();	                  
	                  FileDataSource fds =   new FileDataSource(filesPath.get(index));	                  
	                  attachFilePart.setDataHandler(new DataHandler(fds));
	                  attachFilePart.setFileName(fds.getName());                 
	                  mps.addBodyPart(attachFilePart, index);
	              }	              
            }

           //adicionando o corpo da mensagem
           mps.addBodyPart(textPart);

           //adiciona a mensagem e anexo
           message.setContent(mps);

           //Envia a mensagem             
           Transport.send(message);
           Log.setLogger("", "Send mail - Done!", Level.INFO);                        
            
        } catch (MessagingException e) {
           e.printStackTrace();
        }
	}		
}

