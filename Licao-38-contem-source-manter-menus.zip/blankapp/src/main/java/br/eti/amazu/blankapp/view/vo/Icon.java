package br.eti.amazu.blankapp.view.vo;

public class Icon {

	private String icon;
	private String iconName;
	
	/*---------
	 * get/set
	---------*/
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public String getIconName() {
		return iconName;
	}
	public void setIconName(String iconName) {
		this.iconName = iconName;
	}
	
}