package br.eti.amazu.blankapp.view.vo;

import java.util.List;
import br.eti.amazu.component.pworld.domain.AbstractEntity;

public class Path extends AbstractEntity<Long> {

	private static final long serialVersionUID = -2394480364072444859L;
		
	private Long id;
	private String name;	
	private List<Arquivo> listaArquivos;
	
	public Path() {
		super();
	}
	
	public Path(Long id) {
		super();
		this.id = id;
	}
	
	/*--------
	 * get/set
	 ---------*/
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Arquivo> getListaArquivos() {
		return listaArquivos;
	}
	public void setListaArquivos(List<Arquivo> listaArquivos) {
		this.listaArquivos = listaArquivos;
	}
	
}