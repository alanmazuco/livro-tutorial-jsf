package br.eti.amazu.component.manterMenus.vo;

public class KeysMenu {
	private String key;
	private String menu;	

	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
}
