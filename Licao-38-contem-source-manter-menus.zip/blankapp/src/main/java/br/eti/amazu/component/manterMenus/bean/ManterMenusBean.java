package br.eti.amazu.component.manterMenus.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.faces.event.ActionEvent;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.context.RequestContext;

import br.eti.amazu.blankapp.domain.infra.Funcionalidade;
import br.eti.amazu.blankapp.domain.infra.Menu;
import br.eti.amazu.blankapp.domain.infra.Perfil;
import br.eti.amazu.blankapp.persistence.facade.IAppFacade;
import br.eti.amazu.blankapp.view.bean.common.ConfigBean;
import br.eti.amazu.blankapp.view.bean.common.MenuBean;
import br.eti.amazu.blankapp.view.util.ClassUtil;
import br.eti.amazu.blankapp.view.vo.Icon;
import br.eti.amazu.component.dialog.DialogBean;
import br.eti.amazu.component.dialog.DialogType;
import br.eti.amazu.component.manterMenus.persistence.IManterMenusFacade;
import br.eti.amazu.component.manterMenus.util.LocaleMenu;
import br.eti.amazu.component.manterMenus.util.MountFeature;
import br.eti.amazu.component.manterMenus.vo.KeysMenu;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.component.pworld.util.CompoundMenu;
import br.eti.amazu.util.FacesUtil;

@Named
@ViewScoped
public class ManterMenusBean implements Serializable{

	private static final long serialVersionUID = 1L;

	@Inject
	DialogBean dialogBean;
	
	@Inject
	MenuBean menuBean;
	
	@Inject
	ConfigBean configBean;
	
	@Inject
	IManterMenusFacade<Menu> manterMenusFacade;
	
	@Inject
	IAppFacade<Funcionalidade> funcionalidadeFacade;
	
	@Inject
	IAppFacade<Perfil> perfilFacade;
	
	private List<Menu> listaMenus;	
	private Menu menu = new Menu();		
	private String labelMenuConcatenado;
	private String labelMenuConcatenadoKey;
	private Menu menuNavega = new Menu();	
	private Integer index;	
	private Icon icon = new Icon();
	private String keyLabelBackup; //Guarda o valor de campo unique Key do BD 
	private List<Icon> listaIcons;
		
	@CompoundMenu
	public String iniciarManterMenus(){
		FacesUtil.resetBeans(null);		
		return "/resources/components/manterMenus/pages/adm/listaMenus?faces-redirect=true";
	}
		
	public String listarMenus(){
		menu = null;		
		listaMenus = menuBean.getListaMenus();
		labelMenuConcatenado = FacesUtil.getMessage("CGL156");	
		labelMenuConcatenadoKey = "CGL156";
		return "/resources/components/manterMenus/pages/adm/listaMenus?faces-redirect=true";
	}
	
	public void setarLabelBackup(AjaxBehaviorEvent event){		
		Map<String, Object> map = event.getComponent().getAttributes();
		if( map.get("value") != null){				
			keyLabelBackup = (String) map.get("value");				
		}		
	}
	
	public void atualizarNavegacao(){	
		try{
			String paramVoltar = FacesUtil.getParam("voltar");
						
			if(paramVoltar != null &&paramVoltar.equals("true")){				
				int pos = labelMenuConcatenado.lastIndexOf("-");
				int pos1 = labelMenuConcatenadoKey.lastIndexOf("-");
				labelMenuConcatenado = labelMenuConcatenado.substring(0, pos);
				labelMenuConcatenadoKey = labelMenuConcatenadoKey.substring(0, pos1);
				menuNavega = menuNavega.getMenu();
								
				if(menuNavega == null){
					listaMenus = manterMenusFacade.listar("Menu.rootMenus");
					
				}else{					
					listaMenus = menuNavega.getMenus().stream().collect(Collectors.toList());				
				}			
			
			}else{
				listaMenus = menuNavega.getMenus().stream().collect(Collectors.toList());
				
				labelMenuConcatenado = labelMenuConcatenado + "-" + 
						FacesUtil.getMessage(menuNavega.getLabel());	
				
				labelMenuConcatenadoKey = labelMenuConcatenadoKey + "-" + menuNavega.getLabel();
			}
			
		} catch (DaoException e) {			
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
		}		
	}
	
	public void checarChaveProperties(){
		dialogBean.addMessage(FacesUtil.getMessage(menu.getLabel()), DialogType.INFO_CLOSABLE);
	}
	
	public void moverParaCima(){

		index = Integer.valueOf(FacesUtil.getParam("index"));
		Menu menuClicado = menu;
		Menu menuSuperior = listaMenus.get(index-1);

		try {			
			menuClicado.setOrdem(menuSuperior.getOrdem());
			menuSuperior.setOrdem(menuClicado.getOrdem()+1);
						
			listaMenus.set(index,(Menu) manterMenusFacade.alterarAtualizar(menuSuperior));
			listaMenus.set(index-1,(Menu) manterMenusFacade.alterarAtualizar(menuClicado));
			
		} catch (DaoException e) {			
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);			
			
		} catch (Exception e) {
			e.printStackTrace();
		}								
	}
	
	public void moverParaBaixo(){

		index = Integer.valueOf(FacesUtil.getParam("index"));
		Menu menuClicado = menu;
		Menu menuInferior = listaMenus.get(index+1);
		
		try {				
			menuClicado.setOrdem(menuInferior.getOrdem());
			menuInferior.setOrdem(menuClicado.getOrdem()-1);
						
			listaMenus.set(index,(Menu) manterMenusFacade.alterarAtualizar(menuInferior));
			listaMenus.set(index+1,(Menu) manterMenusFacade.alterarAtualizar(menuClicado));
			
		} catch (DaoException e) {		
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
						
		} catch (Exception e) {
			e.printStackTrace();
		} 								
	}

	public void reloaderMenu(){		
		menuBean.criarMenu();						
	}
		
	public void setarIcon(){		
		menu.setIcon(icon.getIcon());		
	}
	
	public void salvarMenu(){		
			
		try{
						
			//Verifica se selecionou um icone
			if(icon == null || icon != null && icon.getIcon() == null){
				dialogBean.addMessage("Voc� n�o selecionou um �cone.", DialogType.WARN);
				return;
			}
			
			if(menu.getSeparator() == null) {
				dialogBean.addMessage("Voc� precisa definir se o menu ter� ou n�o um separador.", DialogType.WARN);
				return;
			}
			
			//Verifica se jah existe um label igual no BD
			List<Object> params = new ArrayList<Object>();
			params.add(menu.getLabel());
			Menu menuLocalizado = manterMenusFacade.recuperar("Menu.singleMenu", params);
			
			//tipo 0 = grupo, 1 = item
			if((menu.getMetodo() == null || (menu.getMetodo() != null && 
					menu.getMetodo().length()==0))  && menu.getTipo().equals("1")) 
						menu.setMetodo("#{nao_implementado.implemente}");
			
			if(menu.getId() == null){
				
				//Precisa disto: voce pode ter escolhido uma chave contendo erros no arquivo messages. 
				if(!menu.getLabel().isEmpty() && !menu.getLabel().substring(0,12).equals("mm_keyLabel_")){
						
					dialogBean.addMessage("O in�cio da chave de menu deve come�ar com os caracteres "+
							"\"mm_keyLabel_\". Em seguida, n�o se esque�a de incluir essa chave "+
								"nos arquivos message.properties.", DialogType.WARN);
					return;
				}
				menu.setDisabled("F");
				menu.setSelectable("T");
				
				//soh deixa incluir separador se o menu nao for da raiz
				if(menu.getMenu() == null){
					menu.setSeparator("F");
				}
				
				manterMenusFacade.incluirMenuComFuncionalidade(menu);								
				listaMenus.add(menu);		
				menuNavega.getMenus().add(menu);
				
			}else{
				if(menuLocalizado != null && keyLabelBackup!=null && 
						!keyLabelBackup.equals(menu.getLabel())){
					
					dialogBean.addMessage("J� existe um menu com esta chave.", DialogType.WARN);
					menuLocalizado = null;
					return;
				}								
				listaMenus.set(index,(Menu) manterMenusFacade.alterarAtualizar(menu));
			}
						
			if(menu.getVisibility().equals("F")){
			
				/*Aplicando permissoes de menus nao publicos aos usuarios dev e admin.
				 * Atente para aplicar permissoes para outros usuarios, se for o caso, o que
				 * eh a tarefa do Administrador e nao do dev. 
				 * Para o admin, nao aplica permissoes ref a ShowCase e ManterMenus. */
							
				if(menu.getTipo().equals("1")){
					String funcionalidade = new MountFeature().storeMenu(menu);
					params = new ArrayList<Object>();
					params.clear();
					params.add(funcionalidade);
					
					Funcionalidade f = funcionalidadeFacade.recuperar(
							"Funcionalidade.nomeFuncionalidade", params);

					//Associando ao perfil admin... (excluindo se for showCase e manterMenus).
					if(f != null && f.getLabel() != null){
						if(!f.getLabel().contains("showcase") && !f.getLabel().contains("manterMenus")){			
							params.clear();
							params.add("ADM");
							Perfil perfilAdmin = perfilFacade.recuperar("Perfil.peloCod", params);
							
							if(!perfilAdmin.getFuncionalidades().contains((f))){								
								
								perfilAdmin.getFuncionalidades().add(f);
								perfilFacade.alterar(perfilAdmin);		
								icon = new Icon();
								
								dialogBean.addActionMessage("�XITO! Salvou o menu e a funcionalidade " + 
										"respectiva. Considere associar essa funcionalidade aos perfis de usu�rio "+
										"em um momento posterior.", "manterMenusBean.retornarAtualizar", ":formListaMenus:tableMenus");
								return;
							}
						}
					}
					
				}else{
					icon = new Icon();
					dialogBean.addActionMessage("�XITO! Salvou o grupo de menu.", 
							"manterMenusBean.retornarAtualizar", ":formListaMenus:tableMenus");
					return;
				}
			}
			
			icon = new Icon();			
									
			dialogBean.addActionMessage("�XITO! Salvou o menu e a funcionalidade respectiva. "+
					"Considere associar essa funcionalidade aos perfis de usu�rio em um momento posterior.", 
						"manterMenusBean.retornarAtualizar", ":formListaMenus:tableMenus");
							
		}catch(DaoException e){
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);			
		}	
	}
	
	public void confirmarExclusao(){
		dialogBean.addConfirmMessage("Tem certeza de que deseja excluir " + menu.getLabel() + "\"",
				"manterMenusBean.excluirMenu", null, ":formListaMenus:tableMenus");
	}
	
	public void excluirMenu(){
		try {
			manterMenusFacade.excluirMenuComFuncionalidade(menu);
			listaMenus.remove(menu);
			menuNavega.getMenus().remove(menu);
			
		} catch (DaoException e) {			
			dialogBean.addMessage(e.getMessage(),DialogType.ERROR);
		}		
	}
	
	public void retornarAtualizar(){
		RequestContext context = RequestContext.getCurrentInstance();		
		context.execute("PF('dlgLoader').hide()");
		context.execute("PF('dlgFixMenu').hide()");		
	}
	
	public void showFixMenu(ActionEvent actionEvent) {		
		
		String op = FacesUtil.getParam("op");
		
		if(op.equals("incluir")){
		
			menu = new Menu();		
			menu.setTipo("0");
			menu.setVisibility("F");		
			menu.setIcon("blank.gif");
			menu.setSeparator("F");
			int nrOrdem = 0;
		
			if(menuNavega != null && menuNavega.getId() != null) menu.setMenu(menuNavega);
		
			if(listaMenus != null && listaMenus.size() > 0){								
				nrOrdem = listaMenus.get(listaMenus.size()-1).getOrdem() + 1;
				index = nrOrdem - 1;
				
			}else{
				menu.setOrdem(0);	
				index = 0;
			}
			menu.setOrdem(nrOrdem);	
		
		}else{
			index = Integer.valueOf(FacesUtil.getParam("index"));
			menu = listaMenus.get(index);
			icon.setIcon(menu.getIcon());
			icon.setIconName(menu.getIcon());
			keyLabelBackup = menu.getLabel();
		
		}
			
		this.populeIcons();
		RequestContext context = RequestContext.getCurrentInstance();		
		context.execute("PF('dlgFixMenu').show()");
		context.update("formFixMenu");
	}
	
	public void populeIcons(){		
		listaIcons = ClassUtil.getIconsInFrameworkJar(FacesUtil.getFullPath("/WEB-INF/lib/icons-1.3.jar"));	
	}
	
	public List<Menu> getListaMenus() {
		if(listaMenus == null){
			menu = null;		
			listaMenus = menuBean.getListaMenus();
			labelMenuConcatenado = FacesUtil.getMessage("CGL156");	
			labelMenuConcatenadoKey = "CGL156";
		}
		return listaMenus;	
	}

	public List<KeysMenu> getListaKeysLocaleMenus() {				
		return LocaleMenu.getKeysLocaleMenus();
	}
	
	public List<String> getCompoundMenus() {
		return ClassUtil.getMethodNameMakeMenu(ConfigBean.getClassBeans());		
	}
	
	/*--------
	* get/set
	---------*/		
	public void setListaMenus(List<Menu> listaMenus) {
		this.listaMenus = listaMenus;
	}
	public Menu getMenu() {
		return menu;
	}
	public void setMenu(Menu menu) {
		this.menu = menu;
	}
	public String getLabelMenuConcatenado() {
		return labelMenuConcatenado;
	}
	public void setLabelMenuConcatenado(String labelMenuConcatenado) {
		this.labelMenuConcatenado = labelMenuConcatenado;
	}
	public String getLabelMenuConcatenadoKey() {
		return labelMenuConcatenadoKey;
	}
	public void setLabelMenuConcatenadoKey(String labelMenuConcatenadoKey) {
		this.labelMenuConcatenadoKey = labelMenuConcatenadoKey;
	}
	public Menu getMenuNavega() {
		return menuNavega;
	}
	public void setMenuNavega(Menu menuNavega) {
		this.menuNavega = menuNavega;
	}
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	public Icon getIcon() {
		return icon;
	}
	public void setIcon(Icon icon) {
		this.icon = icon;
	}	
	public List<Icon> getListaIcons() {
		return listaIcons;
	}
	public void setListaIcons(List<Icon> listaIcons) {
		this.listaIcons = listaIcons;
	}
	public String getKeyLabelBackup() {
		return keyLabelBackup;
	}
	public void setKeyLabelBackup(String keyLabelBackup) {
		this.keyLabelBackup = keyLabelBackup;
	}
}
