package br.eti.amazu.component.manterMenus.persistence;

import br.eti.amazu.blankapp.domain.infra.Menu;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.component.pworld.persistence.facade.IFacade;

public interface IManterMenusFacade<T> extends IFacade<T> {	
	public void incluirMenuComFuncionalidade(Menu menu) throws DaoException;
	public void excluirMenuComFuncionalidade(Menu menu) throws DaoException;
	public void alterarMenuComFuncionalidade(Menu menu) throws DaoException;
}
