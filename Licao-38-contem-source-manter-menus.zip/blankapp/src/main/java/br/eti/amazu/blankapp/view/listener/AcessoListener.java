package br.eti.amazu.blankapp.view.listener;

import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import javax.inject.Inject;
import br.eti.amazu.blankapp.view.bean.common.UserSessionInBean;
import br.eti.amazu.util.FacesUtil;

public class AcessoListener implements PhaseListener {
		
	private static final long serialVersionUID = 1L;
	
	@Inject
	UserSessionInBean userSessionInBean;
	
	@Override
	public void afterPhase(PhaseEvent phaseEvent) {
		PhaseId phaseid = phaseEvent.getPhaseId();		
		FacesContext ctx = phaseEvent.getFacesContext();

		if ((phaseid == PhaseId.RESTORE_VIEW )) {										
			String viewRoot = ctx.getViewRoot().getViewId();
						
			// Se o usuario nao estah logado, nao pode acessar a pasta /adm e pasta /showcase.
			if(userSessionInBean.getPerfisLogado() == null ) {
				
				//verificando se estah tentando acessar um recurso proibido (pastas adm e showcase)
				if(viewRoot.contains("/pages/adm/") || viewRoot.contains("/pages/showcase/")){				
					FacesUtil.redirect("/pages/realizarLogin/login");
					return;
				}					
			}
		}
	}
	
	@Override
	public void beforePhase(PhaseEvent event) {}
	
	@Override
	public PhaseId getPhaseId() {
		return PhaseId.RESTORE_VIEW;
	}	

}
