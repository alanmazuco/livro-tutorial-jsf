package br.eti.amazu.component.manterMenus.persistence;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.inject.Inject;
import javax.inject.Named;
import javax.interceptor.Interceptors;
import br.eti.amazu.blankapp.domain.infra.Funcionalidade;
import br.eti.amazu.blankapp.domain.infra.Menu;
import br.eti.amazu.blankapp.persistence.dao.IAppDao;
import br.eti.amazu.blankapp.persistence.exception.ViewInterceptorException;
import br.eti.amazu.component.manterMenus.util.MountFeature;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.component.pworld.persistence.facade.Facade;

@Named
@Stateless
@Interceptors({ViewInterceptorException.class })
@TransactionManagement ( TransactionManagementType.CONTAINER )
@TransactionAttribute ( TransactionAttributeType.SUPPORTS )
public class ManterMenusFacade<T> extends Facade<T> implements IManterMenusFacade<T> {

	@Inject
	private IAppDao<T> dao;
		
	@PostConstruct
	public void initDao(){
		super.setDao(dao);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void incluirMenuComFuncionalidade(Menu menu) throws DaoException {
		
		// Verifica se jah possui o menu...
		List<Object> params = new ArrayList<Object>();
		params.clear();
		params.add(menu.getLabel());
				
		dao.insert((T) menu); //Insere o menu.
		if (menu.getTipo().equals("1")) { // Se eh item de menu...
			
			//busca a funcionalidade do menu e insere.
			params.clear();
			String labelFuncionalidade = new MountFeature().storeMenu(menu);
			params.add(labelFuncionalidade);	
			
			Funcionalidade funcionalidade = (Funcionalidade) 
					dao.singleResult("Funcionalidade.nomeFuncionalidade", params);
			
			if (funcionalidade == null) { // Funcionalidade nao existe - inclui.						
				funcionalidade = new Funcionalidade();
				funcionalidade.setVisibility(menu.getVisibility()); //A visibilidade eh a mesma do menu.
				funcionalidade.setLabel(labelFuncionalidade);				
				if (funcionalidade.getLabel() != null) dao.insert((T)funcionalidade);
			}										
		}		
	}
	
	@Override
	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void excluirMenuComFuncionalidade(Menu menu) throws DaoException {
		if (menu.getTipo().equals("1")) {
			String strFunc = new MountFeature().storeMenu(menu);
			List<Object> params = new ArrayList<Object>();
			params.add(strFunc);
	
			Funcionalidade funcionalidade = (Funcionalidade) 
					dao.singleResult("Funcionalidade.nomeFuncionalidade", params);
	
			/* Nao interessa perfis aqui, entao seta-o para null, o que irah 
			 * evitar a exception "deleted entity passed to persist".
			 * A funcionalidade serah excluida e o seu relacionamento na tabela
			 * perfil_funcionalidade tambem serah...*/
			if (funcionalidade != null) {
				funcionalidade.setPerfis(null);
			}
	
			dao.delete((T) menu);
	
			if (funcionalidade != null) {
				dao.delete((T) funcionalidade);
			}
			
		} else {
			dao.delete((T) menu);
		}
		
	}
	
	@Override
	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void alterarMenuComFuncionalidade(Menu menu) throws DaoException {		
		
		/* Inclua uma regra assim na sua view:
		 * "Se for um menu RAIZ nao pode mudar para um do tipo NAO RAIZ e vice-versa." */		
		if (menu.getTipo().equals("1")) { // Se eh item de menu...
			List<Object> params = new ArrayList<Object>();
			params.clear();
			String labelFuncionalidade = new MountFeature().storeMenu(menu);			
			params.add(labelFuncionalidade);	
			
			Funcionalidade funcionalidade = (Funcionalidade) 
					dao.singleResult("Funcionalidade.nomeFuncionalidade", params);
			
			if (funcionalidade != null) {
				funcionalidade.setLabel(labelFuncionalidade);
				funcionalidade.setVisibility(menu.getVisibility());				 
				dao.update((T) funcionalidade);
			}
	
		}
	
		dao.update((T) menu);		
	}
}
