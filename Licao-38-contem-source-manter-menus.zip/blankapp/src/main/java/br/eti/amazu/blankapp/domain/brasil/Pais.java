package br.eti.amazu.blankapp.domain.brasil;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity (name="Pais")
@Table(schema = "PWORLD", name = "PAIS")

@NamedQueries({	
	@NamedQuery(
		name="Pais.all",
	    query="select a from Pais a"
	)
})
public class Pais {
	
	@Id
	@Column (name="ID_PAIS")
	private Long id;
	
	@Column(name = "NOME_PAIS", 
			columnDefinition = "CHARACTER VARYING(70)")
	private String nome;	
	
	@OneToMany(			
		targetEntity=Uf.class,
		mappedBy="pais",
		fetch = FetchType.LAZY
	)
	private Set<Uf> ufs;

	
	/*---------
	 * get/set
	 ----------*/
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Set<Uf> getUfs() {
		return ufs;
	}
	public void setUfs(Set<Uf> ufs) {
		this.ufs = ufs;
	}	
}
