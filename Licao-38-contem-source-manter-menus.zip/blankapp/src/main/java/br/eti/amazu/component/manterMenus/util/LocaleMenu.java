package br.eti.amazu.component.manterMenus.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.faces.context.FacesContext;
import org.apache.commons.lang.builder.CompareToBuilder;
import br.eti.amazu.component.manterMenus.vo.KeysMenu;

public class LocaleMenu {

	/* Obtem uma lista de todos as keys de menus "mm_keyLabel_".
	 * Utilizado no bean manterMenusBean.
	 ------------------------------------------------------------------------*/
	public static List<KeysMenu> getKeysLocaleMenus(){
		FacesContext ctx = FacesContext.getCurrentInstance();
		Locale locale=ctx.getViewRoot().getLocale();
		ResourceBundle rs = ResourceBundle.getBundle("messages",locale);
		List<KeysMenu> lista = new ArrayList<KeysMenu>();
		Enumeration<?> keys = rs.getKeys();		
		while (keys.hasMoreElements()) {			
		    String key = (String) keys.nextElement();
		    try{
		    	
			    if(key.substring(0,12).equals("mm_keyLabel_")) {
			    	KeysMenu keysMenu = new KeysMenu();
			    	keysMenu.setKey(key);
			    	keysMenu.setMenu(getMessage(key));
			    	lista.add(keysMenu);
			    }
			    
		    }catch(StringIndexOutOfBoundsException e){}
		}
		
		Collections.sort(lista, new Comparator<KeysMenu>() {
			@Override
			public int compare(KeysMenu p1, KeysMenu p2) {
				return new CompareToBuilder().append(p1.getMenu(), p2.getMenu()).toComparison();
			}
		});
		
		return lista;		
	}
	
	/* MENSAGENS SEM PARAMETROS
	 * Utilizado intensivamente no processo de internacionalizacao. 
	 * Obtem o valor da mensagem do arquivo properties, passando a chave como parametro.	
	 ---------------------------------------------------------------------------------*/
	public static String getMessage(String key){				
		ResourceBundle rs = ResourceBundle.getBundle("messages",
				FacesContext.getCurrentInstance().getViewRoot().getLocale());		
		if(rs.containsKey(key)) return rs.getString(key);
		return key + ": invalid key";
	}
}
