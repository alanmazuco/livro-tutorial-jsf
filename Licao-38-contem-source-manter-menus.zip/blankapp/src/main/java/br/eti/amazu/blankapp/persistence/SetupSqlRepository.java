package br.eti.amazu.blankapp.persistence;

public enum SetupSqlRepository {

	//=============================================
	QTD_RECORDS_IN_MENU_IN_SETUP(getRecordsInMenu()),
	CRIAR_FUNCAO_REMOVE_ACENTOS_IN_SETUP(criarFuncaoRemoveAcentos()),
	//===============================================================
	
	//menus======================================
	GET_IDS_MENUS_DEFAULT_IN_SETUP(getIdsMenus()),	
	CRIAR_MENUS_RAIZ_DEFAULT_IN_SETUP(criarAlterarMenus(1, "raiz")),
	CRIAR_MENUS_NAO_RAIZ_DEFAULT_IN_SETUP(criarAlterarMenus(1, "nao raiz")),
	ALTERAR_MENUS_RAIZ_DEFAULT_IN_SETUP(criarAlterarMenus(2, "raiz")),
	ALTERAR_MENUS_NAO_RAIZ_DEFAULT_IN_SETUP(criarAlterarMenus(2, "nao raiz")),
	INCREMENTAR_SEQUENCE_MENU_DEFAULT_IN_SETUP(incrementarSequence(1)),
	//========================================================================
	
	//enderecos======================================
	GET_ID_PAIS_DEFAULT_IN_SETUP(getIdPaisDefault()),
	GET_ID_UF_DEFAULT_IN_SETUP(getIdUfDefault()),
	GET_ID_CIDADE_DEFAULT_IN_SETUP(getIdCidadeDefault()),
	GET_ID_BAIRRO_DEFAULT_IN_SETUP(getIdBairroDefault()),
	GET_ID_LOGRADOURO_DEFAULT_IN_SETUP(getIdLogradouroDefault()),
	CRIAR_PAIS_DEFAULT_IN_SETUP(criarAlterarPaisDefault(1)),
	ALTERAR_PAIS_DEFAULT_IN_SETUP(criarAlterarPaisDefault(2)),
	CRIAR_UF_DEFAULT_IN_SETUP(criarAlterarUfDefault(1)),
	ALTERAR_UF_DEFAULT_IN_SETUP(criarAlterarUfDefault(2)),
	CRIAR_CIDADE_DEFAULT_IN_SETUP(criarAlterarCidadeDefault(1)),
	ALTERAR_CIDADE_DEFAULT_IN_SETUP(criarAlterarCidadeDefault(2)),
	CRIAR_BAIRRO_DEFAULT_IN_SETUP(criarAlterarBairroDefault(1)),
	ALTERAR_BAIRRO_DEFAULT_IN_SETUP(criarAlterarBairroDefault(2)),
	CRIAR_LOGRADOURO_DEFAULT_IN_SETUP(criarAlterarLogradouroDefault(1)),
	ALTERAR_LOGRADOURO_DEFAULT_IN_SETUP(criarAlterarLogradouroDefault(2)),
	//====================================================================
	
	//funcionalidades================================================
	GET_IDS_FUNCIONALIDADES_DEFAULT_IN_SETUP(getIdsFuncionalidades()),
	CRIAR_FUNCIONALIDADES_DEFAULT_IN_SETUP(criarAlterarFuncionalidades(1)),
	ALTERAR_FUNCIONALIDADES_DEFAULT_IN_SETUP(criarAlterarFuncionalidades(2)),
	INCREMENTAR_SEQUENCE_FUNCIONALIDADE_DEFAULT_IN_SETUP(incrementarSequence(2)),
	//===========================================================================
	
	//perfis========================================
	GET_IDS_PERFIS_DEFAULT_IN_SETUP(getIdsPerfis()),
	CRIAR_PERFIS_DEFAULT_IN_SETUP(criarAlterarPerfis(1)),
	ALTERAR_PERFIS_DEFAULT_IN_SETUP(criarAlterarPerfis(2)),
	INCREMENTAR_SEQUENCE_PERFIL_DEFAULT_IN_SETUP(incrementarSequence(3)),
	//===================================================================
		
	//perfis/funcionalidades=================================================================
	DELETAR_PERFIS_FUNCIONALIDADES_DEFAULT_IN_SETUP(associarPerfisComFuncionalidades(1)),
	ASSOCIAR_PERFIS_COM_FUNCIONALIDADES_DEFAULT_IN_SETUP(associarPerfisComFuncionalidades(2)),
	//=======================================================================================
		
	//perfis/funcionalidades========================
	GET_ID_EMPRESA_DEFAULT_IN_SETUP(getIdEmpresa()),
	CRIAR_EMPRESA_DEFAULT_IN_SETUP(criarAlterarEmpresa(1)),
	ALTERAR_EMPRESA_DEFAULT_IN_SETUP(criarAlterarEmpresa(2)),
	INCREMENTAR_SEQUENCE_EMPRESA_DEFAULT_IN_SETUP(incrementarSequence(4)),
	//====================================================================
	
	//pessoas=========================================
	GET_IDS_PESSOAS_DEFAULT_IN_SETUP(getIdsPessoas()),
	CRIAR_PESSOAS_DEFAULT_IN_SETUP(criarAlterarPessoas(1)),
	ALTERAR_PESSOAS_DEFAULT_IN_SETUP(criarAlterarPessoas(2)),
	INCREMENTAR_SEQUENCE_PESSOA_DEFAULT_IN_SETUP(incrementarSequence(5)),
	//===================================================================
	
	//usuarios==========================================
	GET_IDS_USUARIOS_DEFAULT_IN_SETUP(getIdsUsuarios()),
	CRIAR_USUARIOS_DEFAULT_IN_SETUP(criarAlterarUsuarios(1)),
	ALTERAR_USUARIOS_DEFAULT_IN_SETUP(criarAlterarUsuarios(2)),
	//=========================================================
	
	//usuarios/perfis=====================================================
	DELETAR_PERFIS_USUARIOS_DEFAULT_IN_SETUP(associarUsuariosComPerfis(1)),
	ASSOCIAR_USUARIOS_COM_PERFIS_DEFAULT_IN_SETUP(associarUsuariosComPerfis(2)),
	//=========================================================================	
	;
	
	private String sql;
	
	//Construtor
	SetupSqlRepository(String sql) {
		this.sql = sql;
	}

	/* =============================================
	 * Contagem de registros na abela MENU
	 * Permite habilitar/desabilitar o link do SETUP.
	 * -------------------------------------------*/
	static String getRecordsInMenu() {
		StringBuffer buff = new StringBuffer();
		buff.append("SELECT COUNT(ID_MENU) AS QTD FROM PWORLD.MENU");
		return buff.toString();
	}

	// Eh uma funcao que retira todos os acentos (util para pesquisas do tipo like).
	static String criarFuncaoRemoveAcentos() {
		StringBuffer buff = new StringBuffer();		
		buff.append("CREATE OR REPLACE FUNCTION PWORLD.sem_acento(text) RETURNS text AS ");
		buff.append("$BODY$ select ");
		buff.append("translate($1,'��������������������������������������������',");
		buff.append("'aaaaaeeeeiiiooooouuuuAAAAAEEEEIIIOOOOOUUUUcC'); $BODY$ LANGUAGE ");
		buff.append("'sql' IMMUTABLE STRICT"); 
		return buff.toString();
	}//========================
				
	/*=========================================
	 * Seleciona todos os IDs dos menus default
	 ----------------------------------------*/
	static String getIdsMenus() {
		StringBuffer buff = new StringBuffer();
		buff.append("SELECT a.ID_MENU FROM PWORLD.MENU a WHERE a.ID_MENU <= 13");		
		return buff.toString();
	}	
	
	/*======================================
	 * Cria ou altera todos os menus default
	 * -----------------------------------*/
	static String criarAlterarMenus(int op, String modo) {
		StringBuffer buff = new StringBuffer();
				
		if(op == 1) {
			
			buff.append("INSERT INTO PWORLD.MENU(ID_MENU, DISABLED, ICON, LABEL, METODO, ORDEM, ");
			
			if (modo.equals("raiz")) { // ultimo parametro eh nulll
				buff.append("SELECTABLE, SEPARATOR, TIPO, TITLE, VISIBILITY) ");
				buff.append("VALUES (:param0, 'F', :param1, :param2, :param3, :param4, 'T', 'F', "
						+ ":param5, :param6, :param7)");
		
			} else {// ultimo paramentro eh not null
				buff.append("SELECTABLE, SEPARATOR, TIPO, TITLE, VISIBILITY, ID_MENU_FK) ");
				buff.append("VALUES (:param0, 'F', :param1, :param2, :param3, :param4, 'T', 'F', "
						+ ":param5, :param6, :param7, :param8)");
			}
			
		}else {
			if (modo.equals("raiz")) { // ultimo parametro eh nulll
				buff.append("UPDATE PWORLD.MENU SET DISABLED='F', ICON=:param1, "
						+ "LABEL=:param2,METODO= :param3, "
						+ "ORDEM=:param4, SELECTABLE='T', SEPARATOR='F', TIPO=:param5, TITLE=:param6, "
						+ "VISIBILITY=:param7 WHERE ID_MENU=:param0");
			
			}else {// ultimo paramentro eh not null
				buff.append("UPDATE PWORLD.MENU SET DISABLED='F', ICON=:param1, LABEL=:param2,"
						+ "METODO= :param3, ORDEM=:param4, SELECTABLE='T', SEPARATOR='F', TIPO=:param5, "
						+ "TITLE=:param6, VISIBILITY=:param7, ID_MENU_FK=:param8 WHERE ID_MENU=:param0");
			}
		}
		return buff.toString();
	}//========================
		
	/*==================================================
	 * busca id de pais, uf, cidade, bairro e logradouro
	 * ------------------------------------------------*/
	static String getIdPaisDefault() {
		StringBuffer buff = new StringBuffer();		
		buff.append("SELECT a.ID_PAIS FROM PWORLD.PAIS a WHERE a.ID_PAIS=55");		
		return buff.toString();
	}
	static String getIdUfDefault() {
		StringBuffer buff = new StringBuffer();		
		buff.append("SELECT a.ID_UF FROM PWORLD.UF a WHERE a.ID_UF=7");		
		return buff.toString();
	}	
	
	static String getIdCidadeDefault() {
		StringBuffer buff = new StringBuffer();		
		buff.append("SELECT a.ID_CIDADE FROM PWORLD.CIDADE a WHERE a.ID_CIDADE=8");		
		return buff.toString();
	}	
	
	static String getIdBairroDefault() {
		StringBuffer buff = new StringBuffer();		
		buff.append("SELECT a.ID_BAIRRO FROM PWORLD.BAIRRO a WHERE a.ID_BAIRRO=5");		
		return buff.toString();
	}	
	static String getIdLogradouroDefault() {
		StringBuffer buff = new StringBuffer();		
		buff.append("SELECT a.ID_LOGRADOURO FROM PWORLD.LOGRADOURO a WHERE a.ID_LOGRADOURO=1");		
		return buff.toString();
	}//========================
	
	/*=====================================================
	 * Cria ou altera pais, uf, cidade, bairro e logradouro
	 * --------------------------------------------------*/
	static String criarAlterarPaisDefault(int op) {
		StringBuffer buff = new StringBuffer();		
		if(op == 1) {
			buff.append("INSERT INTO PWORLD.PAIS (ID_PAIS, NOME_PAIS) VALUES (55, 'Brasil')");
		}else {
			buff.append("UPDATE PWORLD.PAIS SET NOME_PAIS = 'Brasil' WHERE ID_PAIS = 55");
		}
		return buff.toString();
	}		
	static String criarAlterarUfDefault(int op) {
		StringBuffer buff = new StringBuffer();		
		if(op == 1) {
			buff.append("INSERT INTO PWORLD.UF (ID_UF,NOME_UF,SIGLA,ID_PAIS) "
					+ "VALUES (7,'Distrito Federal','DF',55)");
			
		}else {
			buff.append("UPDATE PWORLD.UF SET NOME_UF='Distrito Federal', "
					+ "SIGLA='DF', ID_PAIS=55 WHERE ID_UF=7");
		}
		return buff.toString();
	}		
	static String criarAlterarCidadeDefault(int op) {
		StringBuffer buff = new StringBuffer();		
		if(op == 1) {
			buff.append("INSERT INTO PWORLD.CIDADE (ID_CIDADE, NOME_CIDADE, ID_UF) "
					+ "VALUES (8, 'Bras�lia', 7)");
			
		}else {
			buff.append("UPDATE PWORLD.CIDADE SET NOME_CIDADE = 'Bras�lia', ID_UF = 7 "
					+ "WHERE ID_CIDADE = 8");
		}
		return buff.toString();
	}			
	static String criarAlterarBairroDefault(int op) {
		StringBuffer buff = new StringBuffer();		
		if(op == 1) {
			buff.append("INSERT INTO PWORLD.BAIRRO (ID_BAIRRO, NOME_BAIRRO, ID_CIDADE) "
					+ "VALUES (5, 'Asa Sul', 8)");			
	
			
		}else {
			buff.append("UPDATE PWORLD.BAIRRO SET NOME_BAIRRO = 'Asa Sul', ID_CIDADE = 8 "
					+ "WHERE ID_BAIRRO = 5");
		}
		return buff.toString();
	}		
	static String criarAlterarLogradouroDefault(int op) {
		StringBuffer buff = new StringBuffer();		
		if(op == 1) {
			buff.append("INSERT INTO PWORLD.LOGRADOURO (ID_LOGRADOURO, CEP, NOME_LOGRADOURO, "
					+ "ID_BAIRRO) VALUES (1, '70730510', 'SCLRN', 5)");
			
		}else {
			buff.append("UPDATE PWORLD.LOGRADOURO SET CEP = '70730510', "
					+ "NOME_LOGRADOURO = 'SCLRN', ID_BAIRRO = 5 WHERE ID_LOGRADOURO = 1");
		}
		return buff.toString();
	}//========================		
	
	/*===================================================
	 * Seleciona todos os IDs das funcionalidades default
	 --------------------------------------------------*/
	static String getIdsFuncionalidades() {
		StringBuffer buff = new StringBuffer();
		
		buff.append("SELECT a.ID_FUNCIONALIDADE FROM PWORLD.FUNCIONALIDADE a "
				+ "WHERE a.ID_FUNCIONALIDADE <= 10");	
		
		return buff.toString();
	}
	
	/*================================================
	 * Cria ou altera todas as funcionalidades default
	 * ---------------------------------------------*/
	static String criarAlterarFuncionalidades(int op) {
		StringBuffer buff = new StringBuffer();
		if(op == 1) {
			
			buff.append("INSERT INTO PWORLD.FUNCIONALIDADE (ID_FUNCIONALIDADE, LABEL, "
					+ "VISIBILITY, DISABLED) "
					+ "VALUES (:param0, :param1, :param2, :param3)");	
			
		}else {
			buff.append("UPDATE PWORLD.FUNCIONALIDADE SET LABEL= :param1, VISIBILITY= :param2 , "
					+ "DISABLED= :param3 WHERE ID_FUNCIONALIDADE = :param0");	
		}			
		return buff.toString();
	}
	
	/*==========================================
	 * Seleciona todos os IDs dos perfis default
	 ------------------------------------------*/
	static String getIdsPerfis() {
		StringBuffer buff = new StringBuffer();
		buff.append("SELECT a.ID_PERFIL FROM PWORLD.PERFIL a WHERE a.ID_PERFIL <= 5");		
		return buff.toString();
	}
	
	/*=======================================
	 * Cria ou altera todos os perfis default
	 * -------------------------------------*/
	static String criarAlterarPerfis(int op) {
		StringBuffer buff = new StringBuffer();
		if(op == 1) {
			buff.append("INSERT INTO PWORLD.PERFIL (ID_PERFIL, NOME, "
					+ "CARACTERISTICAS, COD_PERFIL) "
					+ "VALUES (:param0, :param1, :param2, :param3)");	
			
		}else {
			buff.append("UPDATE PWORLD.PERFIL SET NOME= :param1, CARACTERISTICAS= :param2 , "
					+ "COD_PERFIL= :param3 WHERE ID_PERFIL = :param0");	
		}			
		return buff.toString();
	}
	
	/*====================================
	 * Associar perfis com funcionalidades
	 * ---------------------------------*/
	static String associarPerfisComFuncionalidades(int op) {
		StringBuffer buff = new StringBuffer();
		
		if(op == 1) {
			buff.append("DELETE FROM PWORLD.perfil_funcionalidade WHERE ID_PERFIL = :param0 "
				+ "AND ID_FUNCIONALIDADE = :param1");
			
		}else {
			buff.append("INSERT INTO PWORLD.perfil_funcionalidade("
					+ "ID_PERFIL, ID_FUNCIONALIDADE) VALUES(:param0,:param1)");
		}
		return buff.toString();
	}
		
	/*==================================
	 * Seleciona o id da empresa default	
	 ---------------------------------*/
	static String getIdEmpresa() {
		StringBuffer buff = new StringBuffer();		
		buff.append("SELECT a.ID_EMPRESA FROM PWORLD.EMPRESA a WHERE a.ID_EMPRESA=1");		
		return buff.toString();
	}//------------------------
	
	/*==================================
	 * Criar ou alterar empresa default	
	 ---------------------------------*/
	static String criarAlterarEmpresa(int op) {
		StringBuffer buff = new StringBuffer();
		if(op == 1) {			
			buff.append("INSERT INTO PWORLD.EMPRESA ("
					+ "ID_EMPRESA, CNPJ, NOME_FANTASIA, RAZAO_SOCIAL) ");			
			buff.append("VALUES (1, '00.000.000/0001-99', 'Amazu Tecnologia', "
					+ "'Amazu Tecnologia Ltda')");
			
		}else {
			buff.append("UPDATE PWORLD.EMPRESA SET CNPJ='00.000.000/0001-99', "
					+ "NOME_FANTASIA = 'Amazu Tecnologia', "
					+ "RAZAO_SOCIAL='Amazu Tecnologia Ltda' WHERE ID_EMPRESA = 1");		
		}
		return buff.toString();
	}//-----------------------

	/*===================================
	 * Seleciona todos os IDs das pessoas
	 -----------------------------------*/
	static String getIdsPessoas() {
		StringBuffer buff = new StringBuffer();
		buff.append("SELECT a.ID_PESSOA FROM PWORLD.PESSOA a WHERE a.ID_PESSOA <= 5");		
		return buff.toString();
	}//------------------------
	
	/*========================================
	 * Cria ou altera todas as pessoas default
	 * --------------------------------------*/
	static String criarAlterarPessoas(int op) {				
		StringBuffer buff = new StringBuffer();
		if(op == 1) {
			buff.append("INSERT INTO PWORLD.PESSOA (ID_PESSOA, CPF, "
					+ "DATA_NASCIMENTO, IDT, NOME, CEP, ID_EMPRESA) "
					+ "VALUES (:param0, :param1, :param2, :param3, :param4, :param5, :param6)");	
			
		}else {
			buff.append("UPDATE PWORLD.PESSOA SET CPF= :param1, "
					+ "DATA_NASCIMENTO= :param2 , IDT= :param3, "
					+ "NOME=:param4, CEP =:param5, ID_EMPRESA=:param6 WHERE ID_PESSOA = :param0");	
		}			
		return buff.toString();
	}//------------------------
	
	/*====================================
	 * Seleciona todos os IDs dos usuarios
	 -----------------------------------*/
	static String getIdsUsuarios() {
		StringBuffer buff = new StringBuffer();
		buff.append("SELECT a.ID_USUARIO FROM PWORLD.USUARIO a WHERE a.ID_USUARIO <= 5");		
		return buff.toString();
	}//------------------------
	
	/*=========================================
	 * Cria ou altera todas os usuarios default
	 * ---------------------------------------*/
	static String criarAlterarUsuarios(int op) {				
		StringBuffer buff = new StringBuffer();
		if(op == 1) {
			buff.append("INSERT INTO PWORLD.USUARIO (ID_USUARIO, BLOQUEADO, "
					+ "DATA_PRIMEIRO_ACESSO, NOME_USUARIO, "
					+ "PRIMEIRO_ACESSO, SENHA) VALUES (:param0, :param1, "
					+ ":param2, :param3, :param4, :param5)");	
			
		}else {
			buff.append("UPDATE PWORLD.USUARIO SET BLOQUEADO =:param1, "
					+ "DATA_PRIMEIRO_ACESSO =:param2, "
					+ "NOME_USUARIO =:param3, PRIMEIRO_ACESSO =:param4, "
					+ "SENHA =:param5 WHERE ID_USUARIO=:param0");	
		}			
		return buff.toString();
	}//------------------------	
	
	/*=====================================
	 * Associar usuarios com perfis default
	 * -----------------------------------*/
	static String associarUsuariosComPerfis(int op) {
		StringBuffer buff = new StringBuffer();
		
		if(op == 1) {
			buff.append("DELETE FROM PWORLD.USUARIO_PERFIL WHERE ID_USUARIO "
				+ "= :param0 AND ID_PERFIL = :param1");
			
		}else {
			buff.append("INSERT INTO PWORLD.USUARIO_PERFIL(ID_USUARIO, ID_PERFIL) "
					+ "VALUES(:param0,:param1)");
		}
		return buff.toString();
	}	
		
	/*===========================
	 * 	Incrementar as sequencias
	---------------------------*/	
	static String incrementarSequence(int op) {
		StringBuffer buff = new StringBuffer();		
		switch(op) {
			case 1:buff.append("SELECT setval('PWORLD.MENU_SEQ',"
					+ "(SELECT last_value FROM PWORLD.MENU_SEQ)+1,true);");break;
			
			case 2:buff.append("SELECT setval('PWORLD.FUNCIONALIDADE_SEQ',"
					+ "(SELECT last_value FROM PWORLD.FUNCIONALIDADE_SEQ)+1,true);");break;
			
			case 3:buff.append("SELECT setval('PWORLD.PERFIL_SEQ',"
					+ "(SELECT last_value FROM PWORLD.PERFIL_SEQ)+1,true);");break;
					
			case 4:buff.append("SELECT setval('PWORLD.EMPRESA_SEQ'"
					+ ",(SELECT last_value FROM PWORLD.EMPRESA_SEQ)+1,true);");break;
					
			case 5:buff.append("SELECT setval('PWORLD.PESSOA_SEQ'"
					+ ",(SELECT last_value FROM PWORLD.PESSOA_SEQ)+1,true);");break;
		}					
		return buff.toString();
	}//------------------------
	
	/*--------
	 * get/set
	 ---------*/
	public String getSql() {		
		return sql;
	}	
	
}

