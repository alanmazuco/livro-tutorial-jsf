package br.eti.amazu.component.manterMenus.util;

import java.util.ArrayList;
import java.util.List;

import br.eti.amazu.blankapp.domain.infra.Menu;

public class MountFeature {
	static int i = 0;
	static List<String> lista;

	public MountFeature() {		
		i = 0;
		lista = new ArrayList<String>();		
	}

	//opa! Depende de br.eti.amazu.blankapp.domain.Menu
	public String storeMenu(Menu menu) {

		// Recebe um menu e retorna algo como
		// "/Administracao/Ferramentas/Painel de controle"
		if (menu != null) {
			i++;
			lista.add(menu.getLabel());
			storeMenu(menu.getMenu());
		}
		
		String feature = "";
		
		for (int a = lista.size() - 1; a != -1; a--) {
			feature = feature + "/" + lista.get(a);
		}		
		return feature;		
	}

	public static String traduzFeature(String kFeat) {
		
		/*
		 * Recebe uma string contendo keys de features e devolve algo como
		 * /Administracao/Ferramentas/Painel de controle
		 */
		
		String keysFeature = kFeat.substring(1);

		String keyFeatures[] = keysFeature.split("/");
		String features = "";
		
		for (String str : keyFeatures) {
			features = features + "/" + LocaleMenu.getMessage(str);
		}
		return features;		
	}	

}
