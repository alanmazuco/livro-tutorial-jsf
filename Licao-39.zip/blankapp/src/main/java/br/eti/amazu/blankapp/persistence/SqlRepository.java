package br.eti.amazu.blankapp.persistence;

public enum SqlRepository {
	
	//UC - Realizar Login=================================================
	RECUPERAR_PESSOA_PELO_NOME_DATA_NASC(recuperaPessoaPorNomeDataNasc());
	//====================================================================
	
	private String sql;
	
	//Construtor
	SqlRepository(String sql) {
		this.sql = sql;
	}
	
	static String recuperaPessoaPorNomeDataNasc() {
		StringBuffer buff = new StringBuffer();
		buff.append("SELECT * FROM PWORLD.PESSOA WHERE UPPER(NOME) = UPPER(:param0) ");
		buff.append("AND DATA_NASCIMENTO =:param1 AND EMAIL =:param2");
		return buff.toString();
	}
	
	/*--------
	 * get/set
	 ---------*/
	public String getSql() {		
		return sql;
	}	
}
