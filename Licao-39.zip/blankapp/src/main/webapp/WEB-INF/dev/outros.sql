/*empresa*/
INSERT INTO pworld.empresa (id_empresa, cnpj, nome_fantasia, razao_social)
	VALUES (1, '99.999.999/0001-99', 'amazu', 'Alan Mazuco Ltda');

/*pessoa*/
INSERT INTO pworld.pessoa (id_pessoa, cpf, data_nascimento, idt, nome, cep, id_empresa)
	VALUES (1, '999.999.999-99', '1964-02-02', '1235-ssp', 'Manoel da Silva', '31270570', 1);

/*dependente*/
INSERT INTO pworld.dependente (id_dependente, data_nascimento, grau_parent, nome, id_pessoa) VALUES (1, '1964-03-01', 'esposa', 'Maria da Silva', 1);
INSERT INTO pworld.dependente (id_dependente, data_nascimento, grau_parent, nome, id_pessoa) VALUES (2, '1990-06-01', 'filho', 'Jos� da Silva', 1);
INSERT INTO pworld.dependente (id_dependente, data_nascimento, grau_parent, nome, id_pessoa) VALUES (3, '2016-03-06', 'neto', 'Joaquim da Silva', 1);

/*usuario*/
INSERT INTO pworld.usuario (id_usuario, bloqueado, data_primeiro_acesso, nome_usuario, 
	primeiro_acesso, senha)  VALUES (1, 'F', '2015-01-01', 'silvas', 'T', '123456');
	
/*perfil*/
INSERT INTO pworld.perfil (id_perfil, cod_perfil, nome)  VALUES (2, 2, 'ADMINISTRADOR');

/*usuario_perfil*/
INSERT INTO pworld.usuario_perfil (id_usuario,id_perfil)  VALUES (1, 2);

/*funcionalidade*/
INSERT INTO pworld.funcionalidade (id_funcionalidade, disabled, label, visibility)  
			VALUES (1, 'F', '/mm_keyLabel_login', 'F');

/*perfil_funcionalidade*/
INSERT INTO pworld.perfil_funcionalidade(id_perfil, id_funcionalidade)  VALUES (2, 1);	
