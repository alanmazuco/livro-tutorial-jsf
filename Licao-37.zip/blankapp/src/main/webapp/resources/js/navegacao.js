/*Esta funcao permite bloquear o botao 'return' dos browsers. Eh necessario
 * insercao do dlgButtonBack.xhtml (layout). Adaptado de Stackoverflow.com*/
(function(window) { 
	'use strict'; 
 	var noback = { 	 
		version: '0.0.1', 
		history_api : typeof history.pushState !== 'undefined', 		 
		init:function(){ 
			window.location.hash = '#no-back'; 
			noback.configure(); 
		}, 		 
		hasChanged:function(){ 
			if (window.location.hash == '#no-back' ){ 
				window.location.hash = '#app';
				PF('dlgButtonBack').show();
			} 
		}, 		 
		checkCompat: function(){ 
			if(window.addEventListener) { 
				window.addEventListener("hashchange", 
						noback.hasChanged, false); 
			}else if (window.attachEvent) { 
				window.attachEvent("onhashchange", 
						noback.hasChanged); 
			}else{ 
				window.onhashchange = 
						noback.hasChanged; 
			} 
		}, 		 
		configure: function(){ 
			if ( window.location.hash == '#no-back' ) { 
				if ( this.history_api ){ 
					history.pushState(null, '', '#app'); 
				}else{  
					window.location.hash = '#app';
					PF('dlgButtonBack').show();
				} 
			} 
			noback.checkCompat(); 
			noback.hasChanged(); 
		}
	}; 
	 
	if (typeof define === 'function' && define.amd) { 
		define( function() { return noback; } ); 
	}else if (typeof module === 'object' && module.exports) { 
		module.exports = noback; 
	}else { window.noback = noback; } 
	noback.init();
}(window)); 

/* Criptografar no browser do client. Nao garante seguranca.
 *- Qualquer hacker que conheca o algoritmo eh capaz de descriptografar.
 *  Entretando, pode gerar desconforto ao hacker.*/
function encrypt(value){
	var encrypted = CryptoJS.AES.encrypt(
			value, 
			
			//qualquer string com 16 caracteres (sua chave publica)
			CryptoJS.enc.Utf8.parse('encrypt-crypto-h'), { 
				iv: CryptoJS.enc.Utf8.parse('encrypt-crypto-h')
			}
	);
	
	return encrypted.ciphertext;
}

/* Abre popup centralizado.*/
function abrirPopup(url,w,h) {
	var newW = w + 100;
	var newH = h + 100;
	var left = (screen.width-newW)/2;
	var top = (screen.height-newH)/2;	
	var newwindow = window.open(url, 'name', 'width='+newW+',height='+newH+',left='+left+',top='+top);	
	
	if(newwindow == null){
		alert('Popup bloqueado. Faça o desbloqueio nas configurações do browser.')
		return false;
	}
	
	newwindow.resizeTo(newW, newH);

	//posiciona o popup no centro da tela
	newwindow.moveTo(left, top);
	newwindow.focus();
	return false;
}

/*verificar se a tecla capslock está ligada*/
function checar_caps_lock(ev) {
	var e = ev || window.event;	
	codigo_tecla = e.keyCode?e.keyCode:e.which;
	tecla_shift = e.shiftKey?e.shiftKey:((codigo_tecla == 16)?true:false);
	
	if(((codigo_tecla >= 65 && codigo_tecla <= 90) && !tecla_shift) ||
			((codigo_tecla >= 97 && codigo_tecla <= 122) && tecla_shift)) {
		
		document.getElementById('aviso_caps_lock').style.visibility = 'visible';
		
	}else {
		document.getElementById('aviso_caps_lock').style.visibility = 'hidden';
	}
}





