package br.eti.amazu.blankapp.persistence.facade;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.inject.Inject;
import javax.inject.Named;
import javax.interceptor.Interceptors;

import br.eti.amazu.blankapp.persistence.dao.IAppDao;
import br.eti.amazu.component.pworld.persistence.exception.InterceptorException;
import br.eti.amazu.component.pworld.persistence.facade.Facade;

@Named
@Stateless
@Interceptors({InterceptorException.class })
@TransactionManagement ( TransactionManagementType.CONTAINER )
@TransactionAttribute ( TransactionAttributeType.SUPPORTS )
public class AppFacade<T> extends Facade<T> implements IAppFacade<T> {
	
	@Inject
	private IAppDao<T> dao;
		
	@PostConstruct
	public void initDao(){
		super.setDao(dao);
	}

	/*---------------------------------------------------------------
	 * DAQUI PARA BAIXO, ACRESCENTAR OUTROS METODOS, SE FOR O CASO...
	 --------------------------------------------------------------*/		
}

