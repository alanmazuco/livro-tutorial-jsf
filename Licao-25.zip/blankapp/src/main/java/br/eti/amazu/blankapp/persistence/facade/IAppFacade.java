package br.eti.amazu.blankapp.persistence.facade;

import br.eti.amazu.component.pworld.persistence.facade.IFacade;

public interface IAppFacade<T> extends IFacade<T> {	
	
	/*--------------------------------------------------------------
	 * DAQUI PARA BAIXO, ACRESCENTAR OUTROS METODOS, SE FOR O CASO...
	 --------------------------------------------------------------*/	
}
