package br.eti.amazu.blankapp.view.bean.showcase;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.apache.log4j.Level;
import org.primefaces.context.RequestContext;
import br.eti.amazu.blankapp.persistence.SetupSqlRepository;
import br.eti.amazu.blankapp.persistence.facade.IAppFacade;
import br.eti.amazu.component.dialog.DialogBean;
import br.eti.amazu.component.progressbar.ProgressBean;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;
import br.eti.amazu.util.Crypt;
import br.eti.amazu.util.DateUtil;
import br.eti.amazu.util.log.Log;

	/* -------------------------------------------------------------------------------------------------------
	 *               	                            |                    QUEM ACESSA       			          |
	 *         MENU / FUNCIONALIDADE                 ---------------------------------------------------------
	 *                                              |  DEV	    |	ADM     |  OPM 		|  OPS 		|   VIS   |
	 * -------------------------------------------------------------------------------------------------------
	 * 	- Administracao                          	| 			|	 		|			|			|	 	  |			
	 *		 - Ferramentas                      	|	 		|			|			|			|		  |
	 *					-  Manter Menus          	|	 (*)	|	 		|			|			|	      |	
	 *					-  Showcase               	|	 (*)	|			|			|			|	 	  |
	 *		 - Recursos Humanos       				|			|			|			|			|		  |
	 *					- Cadastro de Pessoal 		|	 (*)	|	  x		|	 x		|	 x		|	 	  |
	 *					- Cadastro de Usuarios 	    |	 (*)	|	  x		|	 x		|			|		  |
	 *					- Manter Perfis	         	|	 (*)	|	  x		|			|			|		  |
	 *------------------------------------------------------------------------------------------------------- |
	 *	- Download									|	(**)	|	(**)	|	(**)	|	(**)	|	(**)  |
	 *	- Home Page 								|	(**)	|	(**)	|	(**)	|	(**)	|	(**)  |
	 *	- Login 									|	(**)	|	(**)	|	(**)	|	(**)	|	(**)  |
	 *	- Logout									|	(**)	|	(**)	|	(**)	|	(**)	|	(**)  |
	 *  - Help                                      |   (**)    |   (**)    |   (**)    |   (**)    |   (**)  |
	 *	------------------------------------------------------------------------------------------------------
	 * (*) 	O Desenvolvedor possui acesso a todas as funcionalidades.
	 * (**)	Funcionalidades publicas --> todos teem acesso.* 
	 * Essa confluencia irah culminar em 6 registros na tabela PERFIL_FUNCIONALIDADE. 
	 * 
	 * USUARIOS E PERFIS
	 * -----------------
	 * DEV ==> POSSUI TODOS OS PERFIS, SEM PRECISAR LANCAR REGISTROS NA TABELA USUARIO_PERFIL
	 * ADM ==> ADM, OP MASTER e OP SENIOR (Produz tres registros na tabela USUARIO_PERFIL)
	 * OPM ==> OP MASTER
	 * OPS ==> OP SENIOR
	 * VIS ==> VISITANTE
	 * Essa confluencia irah culminar em 10 registros na tabela USUARIO_PERFIL. */	

@Named
@ViewScoped
public class SetupCaseBean implements Serializable{

	private static final long serialVersionUID = 1L;

	@Inject
	IAppFacade<Object> appFacade;
	
	@Inject
	DialogBean dialogBean;
	
	@Inject
	ProgressBean progressBean;
	
	public boolean existMenus(){
		
		//verifica se a tabela MENU possui entradas de menu.
		try {
			Object entradasMenu = appFacade.recuperarNQ(
					SetupSqlRepository.QTD_RECORDS_IN_MENU_IN_SETUP.getSql());
			
			if(entradasMenu == null || Long.parseLong(entradasMenu.toString()) == 0){
				return false;  //retorna false ---> habilita o link do setup
			}
								
		} catch (DaoException e) {
			e.printStackTrace();
		}				
		return true; //retorna true ---> desabilita o link do setup
	}
		
	public void prepararSetup(){		
		progressBean.init("setupCaseBean.realizarSetup", null, null);
		RequestContext context = RequestContext.getCurrentInstance();
		context.execute("PF('progressbar').show()");
	}
		
	public void realizarSetup(){
		
		Log.setLogger("", "Inicializando objetos...", Level.INFO);		
		
		/* O codigo realiza 59 iteracoes (armazenado na variavel it).
		 * Dimensionar a progressbar com um valor um a cinco pontos menor que isto.*/
		progressBean.setpSize(58);
				
		int it = 1; //inicia um contador para a progressBar.		
		try {
			/**********************************************************
			 * Inicia pelos elementos menos acoplados (nao-dependentes)					
			 *********************************************************/			
			
			//1) Cria (ou recria) uma funcao no banco de dados "remove acento"
			atualizeProgressbar(it, "Inicializando objetos...");
			appFacade.executarNQ(SetupSqlRepository.CRIAR_FUNCAO_REMOVE_ACENTOS_IN_SETUP.getSql());
			
			//2) Menus default
			it = this.crieOuAltereMenusDefault(it);
			
			//3) Enderecos default
			it = this.crieOuAltereEnderecosDefault(it);
							
			//4) Funcionalidades default			
			it = this.crieOuAltereFuncionalidadesDefault(it);
			
			//5) perfis default			
			it = this.crieOuAlterePerfisDefault(it);
			
			//6) Associar perfis com funcionalidades
			it = this.associePerfisComFuncionalidades(it);
			
			//7) Empresa default			
			it = this.crieOuAltereEmpresaDefault(it);
			
			//8) Pessoas defaults
			it = this.crieOuAlterePessoasDefault(it);
			
			//9) Usuarios defaults
			it = this.crieOuAltereUsuariosDefault(it);
			
			//10) Associar usuarios com perfis
			it = this.associeUsuariosComPerfis(it);			
			
		} catch (DaoException e) {			
			e.printStackTrace();
		}		
	}
	
	int crieOuAltereMenusDefault(int it){		
		try{			
			/* Cria os 13 menus default, caso eles nao existam (buscar pelo ID)
			 * Inicialmente, guarda todos os menus (apenas ids) em uma lista para comparacoes */
			List<Object> idMenus = appFacade.listarNQ(
					SetupSqlRepository.GET_IDS_MENUS_DEFAULT_IN_SETUP.getSql());
		
			for(int z= 1; z<=13; z++){
				
				switch(z) {					
					case 1:
						crieOuAltereMenu(it++,z,"edit_pen.gif","mm_keyLabel_administracao",
								null, 0,"0",null,"F",null,idMenus);
						break;						
					case 2:
						crieOuAltereMenu(it++, z, "config.gif", "mm_keyLabel_ferramentas", 
								null, 0, "0", null, "F", 1L, idMenus);
						break;	
					case 3:
						crieOuAltereMenu(it++, z, "menu.gif", "mm_keyLabel_manterMenus", 
								"#{manterMenusBean.iniciarManterMenus}", 0, "1", null, "F", 2L, idMenus);
						break;	
					case 4:
						crieOuAltereMenu(it++, z, "java.gif", "mm_keyLabel_showCase", 
								"#{menuBean.iniciarShowCase}", 1, "1", null, "F", 2L, idMenus);
						break;	
					case 5:
						crieOuAltereMenu(it++, z, "peoples_dif.gif", "mm_keyLabel_recursosHumanos", 
								null, 1, "0", null, "F", 1L, idMenus);
						break;
						
						
						
						
					case 6:
						crieOuAltereMenu(it++, z, "peoples.gif", "mm_keyLabel_cadastroPessoal", 
								"#{recursosHumanosBean.iniciarManterCadPes}", 0, "1", null, "F", 5L,idMenus);
						break;	
					case 7:
						crieOuAltereMenu(it++, z, "user.gif", "mm_keyLabel_cadastroUsuarios", 
								"#{recursosHumanosBean.iniciarManterCadUs}", 1, "1", null, "F", 5L,idMenus);
						break;	
					case 8:
						crieOuAltereMenu(it++, z, "activity.gif", "mm_keyLabel_manterPerfis",
								"#{manterPerfisBean.iniciarManterPerfis}", 2, "1", null, "F", 5L, idMenus);
						break;	
					case 9:
						crieOuAltereMenu(it++, z, "download.gif", "mm_keyLabel_download",
								"#{manterArquivosBean.iniciarPaginaDownloads}", 1, 
								"1", "Download", "T", null, idMenus);
						break;	
					case 10:
						crieOuAltereMenu(it++, z, "home.gif", "mm_keyLabel_homePage",
								"#{menuBean.iniciarHomePage}", 2, "1", "Home Page", "T", null,idMenus);
						break;	
					case 11:
						crieOuAltereMenu(it++, z, "key.gif", "mm_keyLabel_login",
								"#{realizarLoginBean.iniciarRealizarLogin}", 3, "1", 
								"Realizar Login", "T", null, idMenus);
						break;	
					case 12:
						crieOuAltereMenu(it++, z, "logout.gif", "mm_keyLabel_logout", 
								"#{realizarLoginBean.iniciarRealizarLogout}", 4, "1", 
								"Sair", "T", null,idMenus);
						break;	
					case 13:
						crieOuAltereMenu(it++, z, "help.gif", "mm_keyLabel_help", 
								"#{menuBean.getHelp}", 5, "1", "Help", "T", null, idMenus);
						break;						
				}				
				atualizeProgressbar(it++, "Criando o menu " + z); 
			}
		
		}catch (DaoException e){
			e.printStackTrace();
		}		
		return it;
	}
	
	int crieOuAltereEnderecosDefault(int it) {
				
		Object obj = null;
		try{	
			List<Object> params = new ArrayList<Object>();
			params.add(55);
			
			atualizeProgressbar(it++, "Criando entradas em PAIS...");
			
			//verifica se existe o pais com id = 55 - cria ou altera
			obj = appFacade.recuperarNQ(SetupSqlRepository.GET_ID_PAIS_DEFAULT_IN_SETUP.getSql());
			if(obj == null) {
				appFacade.executarNQ(SetupSqlRepository.CRIAR_PAIS_DEFAULT_IN_SETUP.getSql());				
			}else {
				
		
				
				
				appFacade.executarNQ(SetupSqlRepository.ALTERAR_PAIS_DEFAULT_IN_SETUP.getSql());
			}//---------------------------------------------------------------------------------
			
			atualizeProgressbar(it++, "Criando entradas em UF...");
			
			//verifica se existe o uf com id = 7 - cria ou altera
			params.clear();
			params.add(7);
			obj = appFacade.recuperarNQ(SetupSqlRepository.GET_ID_UF_DEFAULT_IN_SETUP.getSql());
			if(obj == null) {
				appFacade.executarNQ(SetupSqlRepository.CRIAR_UF_DEFAULT_IN_SETUP.getSql());				
			}else {
				appFacade.executarNQ(SetupSqlRepository.ALTERAR_UF_DEFAULT_IN_SETUP.getSql());
			}//-------------------------------------------------------------------------------
			
			atualizeProgressbar(it++, "Criando entradas em CIDADE...");
			
			//verifica se existe o cidade com id = 8 - cria ou altera
			params.clear();
			params.add(8);
			obj = appFacade.recuperarNQ(SetupSqlRepository.GET_ID_CIDADE_DEFAULT_IN_SETUP.getSql());
			if(obj == null) {
				appFacade.executarNQ(SetupSqlRepository.CRIAR_CIDADE_DEFAULT_IN_SETUP.getSql());				
			}else {
				appFacade.executarNQ(SetupSqlRepository.ALTERAR_CIDADE_DEFAULT_IN_SETUP.getSql());
			}//-----------------------------------------------------------------------------------
			
			atualizeProgressbar(it++, "Criando entradas em BAIRRO...");
			
			//verifica se existe o bairro com id = 5 - cria ou altera
			params.clear();
			params.add(5);
			obj = appFacade.recuperarNQ(SetupSqlRepository.GET_ID_BAIRRO_DEFAULT_IN_SETUP.getSql());
			if(obj == null) {
				appFacade.executarNQ(SetupSqlRepository.CRIAR_BAIRRO_DEFAULT_IN_SETUP.getSql());				
			}else {
				appFacade.executarNQ(SetupSqlRepository.ALTERAR_BAIRRO_DEFAULT_IN_SETUP.getSql());
			}//-----------------------------------------------------------------------------------
			
			atualizeProgressbar(it++, "Criando entradas em LOGRADOURO..."); //it termina com 19
			
			//verifica se existe o logradouro com id = 1 - cria ou altera
			params.clear();
			params.add(1);
			obj = appFacade.recuperarNQ(SetupSqlRepository.GET_ID_LOGRADOURO_DEFAULT_IN_SETUP.getSql());
			if(obj == null) {
				appFacade.executarNQ(SetupSqlRepository.CRIAR_LOGRADOURO_DEFAULT_IN_SETUP.getSql());				
			}else {
				appFacade.executarNQ(SetupSqlRepository.ALTERAR_LOGRADOURO_DEFAULT_IN_SETUP.getSql());
			}//---------------------------------------------------------------------------------------
			
		}catch (DaoException e){
			e.printStackTrace();
		}		
		return it;
	}
	
	
	
	int crieOuAltereFuncionalidadesDefault(int it){			
		List<Object> params = new ArrayList<Object>();
		
		try{			
			/* Cria as 10 funcionalidades default, caso elas nao existam (buscar pelo ID)
			 * Inicialmente, guarda todas as funcionalidades em uma lista para comparacoes */
			List<Object> idFuncionalidades = appFacade.listarNQ(
					SetupSqlRepository.GET_IDS_FUNCIONALIDADES_DEFAULT_IN_SETUP.getSql());
			
			for(int b=1; b<=10; b++){				
				params.clear();
				params.add(b); //ID_FUNCIONALIDADE
				
				switch(b) {
					case 1:
						params.add("/mm_keyLabel_administracao/"
								+ "mm_keyLabel_ferramentas/mm_keyLabel_manterMenus");
						params.add("F");
						params.add("F");
						break;
						
					case 2:
						params.add("/mm_keyLabel_administracao/"
								+ "mm_keyLabel_ferramentas/mm_keyLabel_showCase");
						params.add("F");
						params.add("F");
						break;
						
					case 3:
						params.add("/mm_keyLabel_administracao/"
								+ "mm_keyLabel_recursosHumanos/mm_keyLabel_cadastroPessoal");
						params.add("F");
						params.add("F");
						break;
						
					case 4:
						params.add("/mm_keyLabel_administracao/"
								+ "mm_keyLabel_recursosHumanos/mm_keyLabel_cadastroUsuarios");
						params.add("F");
						params.add("F");
						break;
						
					case 5:
						params.add("/mm_keyLabel_administracao/"
								+ "mm_keyLabel_recursosHumanos/mm_keyLabel_manterPerfis");
						params.add("F");
						params.add("F");
						break;
						
					case 6:
						params.add("/mm_keyLabel_download");
						params.add("T");
						params.add("F");
						break;
						
					case 7:
						params.add("/mm_keyLabel_login");
						params.add("T");
						params.add("F");
						break;
						
					case 8:
						params.add("/mm_keyLabel_login");
						params.add("T");
						params.add("F");
						break;
						
					case 9:
						params.add("/mm_keyLabel_logout");
						params.add("T");
						params.add("F");
						break;
						
					case 10:
						params.add("/mm_keyLabel_help");
						params.add("T");
						params.add("F");
						break;
				}				
			
				//Cria ou altera a funcionalidade com id = b (se cria, incrementa a sequence)
				if(existObject(b, idFuncionalidades)) {
					appFacade.executarNQ(
							SetupSqlRepository.ALTERAR_FUNCIONALIDADES_DEFAULT_IN_SETUP.getSql(), params);	
					
				}else {
					appFacade.executarNQ(
							SetupSqlRepository.CRIAR_FUNCIONALIDADES_DEFAULT_IN_SETUP.getSql(), params);
					
					@SuppressWarnings("unused") Object seqFunc = appFacade.recuperarNQ(
							SetupSqlRepository.INCREMENTAR_SEQUENCE_FUNCIONALIDADE_DEFAULT_IN_SETUP.getSql());
				}
				
				atualizeProgressbar(it++, "Criando a Funcionalidade " + b);				
			}
			
		}catch (DaoException e){
			e.printStackTrace();
		}		
		return it;
	}
	
	int crieOuAlterePerfisDefault(int it){			
		List<Object> params = new ArrayList<Object>();
		
		try{			
			/* Cria os 5 perfis default, caso eles nao existam (buscar pelo ID)
			 * Inicialmente, guarda todos os ids em uma lista para comparacoes */
			List<Object> idPerfis = appFacade.listarNQ(
					SetupSqlRepository.GET_IDS_PERFIS_DEFAULT_IN_SETUP.getSql());
			
			for(int a=1; a<=5; a++){				
				params.clear();
				params.add(Long.parseLong(String.valueOf(a))); //ID_PERFIL
				
				switch(a) {					
					case 1:
						params.add("DESENVOLVEDOR");
						params.add("Carrega todas as funcionalidades do sistema.");
						params.add("DEV");
						break;
						
					case 2:
						params.add("ADMINISTRADOR");
						params.add("Carrega todas as funcionalidades, menos as Ferramentas do Desenvolvedor.");	
						params.add("ADM");
						break;
					case 3:
						params.add("OPERADOR MASTER");					
						params.add("Carrega todas as funcionalidades, menos as Ferramentas "
								+ "do Desenvolvedor e Manter Perfis.");
						params.add("OPM");
						break;
					case 4:
						params.add("OPERADOR SENIOR");					
						params.add("Carrega todas as funcionalidades, menos as Ferramentas "
								+ "do Desenvolvedor, Manter Perfis e Cadastro de Usuarios.");
						params.add("OPS");
						break;
					case 5:		
						params.add("VISITANTE");
						params.add("Nao carrega as funcionalidades administrativas.");
						params.add("VIS");
						break;
				}
				
				//Cria ou altera o perfil com id = a
				if(existObject(a, idPerfis)) {
					appFacade.executarNQ(SetupSqlRepository.ALTERAR_PERFIS_DEFAULT_IN_SETUP.getSql(), params);					
				}else {
					appFacade.executarNQ(SetupSqlRepository.CRIAR_PERFIS_DEFAULT_IN_SETUP.getSql(), params);
					@SuppressWarnings("unused") Object seqFunc = appFacade.recuperarNQ(
							SetupSqlRepository.INCREMENTAR_SEQUENCE_PERFIL_DEFAULT_IN_SETUP.getSql());
				}				
				atualizeProgressbar(it++, "Criando o perfil " + a); 				
			}			
		} catch (DaoException e) {
			e.printStackTrace();
		}		
		return it;
	}
		
	int crieOuAltereMenu(int it, int idPerfil, String icon, String label, String metodo, int ordem, String tipo, 
		String title, String visibility, Long id_menu_fk, List<Object> idMenus){	
		try{				
			List<Object> params = new ArrayList<Object>();
			params.add(Long.parseLong(String.valueOf(idPerfil)));  //.......0 - ID
			params.add(icon); //............................................1 - ICON
			params.add(label); //...........................................2 - LABEL
			params.add(metodo); //..........................................3 - METODO
			params.add(ordem); //...........................................4 - ORDEM
			params.add(tipo); //............................................5 - TIPO (1-Item, 0-Grupo)
			params.add(title); //...........................................6 - TITLE
			params.add(visibility); //......................................7 - VISIBILITY
			
			//Cria ou altera o perfil com id = z
			if(existObject(idPerfil, idMenus)) {
				if(id_menu_fk == null){									
					appFacade.executarNQ(
							SetupSqlRepository.ALTERAR_MENUS_RAIZ_DEFAULT_IN_SETUP.getSql(), params);
			
				}else{
					
					params.add(id_menu_fk); //8- ID_MENU_FK				
					appFacade.executarNQ(
							SetupSqlRepository.ALTERAR_MENUS_NAO_RAIZ_DEFAULT_IN_SETUP.getSql(), params);
				}								
				
			}else {
				//Se o menu nao existe, cria o menu e incrementa a sequence.
				if(id_menu_fk == null){									
					appFacade.executarNQ(
							SetupSqlRepository.CRIAR_MENUS_RAIZ_DEFAULT_IN_SETUP.getSql(), params);					
			
				}else{
					params.add(id_menu_fk); //8- ID_MENU_FK				
					appFacade.executarNQ(
							SetupSqlRepository.CRIAR_MENUS_NAO_RAIZ_DEFAULT_IN_SETUP.getSql(), params);
				}				
				@SuppressWarnings("unused") Object seqFunc = appFacade.recuperarNQ(
						SetupSqlRepository.INCREMENTAR_SEQUENCE_MENU_DEFAULT_IN_SETUP.getSql());				
			}	
			
						
		}catch(DaoException e){
			e.printStackTrace();
		}			
		return it;
	}
	
	int associePerfisComFuncionalidades(int it){			
		atualizeProgressbar(it++, "Associando funcionalidades...");
		
		/* DEV: TODAS (nao precisa associar, pois jah possui por default em MenuBean)
		 * ADM: 3,4,5
		 * OP MASTER: 3,4
		 * OP SENIOR: 3
		 * OP VIS: nao precisa - jah possui todas as funcionalidades publicas*/
		try {
			
			List<Object> params = new ArrayList<Object>();			
			for(Long a=1L; a<=6; a++){
				params.clear();
				if(a == 1) {params.add(2); params.add(3);}
				if(a == 2) {params.add(2); params.add(4);}
				if(a == 3) {params.add(2); params.add(5);}
				if(a == 4) {params.add(3); params.add(3);}
				if(a == 5) {params.add(3); params.add(4);}
				if(a == 6) {params.add(4); params.add(3);}
				
				appFacade.executarNQ(SetupSqlRepository.
						DELETAR_PERFIS_FUNCIONALIDADES_DEFAULT_IN_SETUP.getSql(), params);
				
				appFacade.executarNQ(SetupSqlRepository.
						ASSOCIAR_PERFIS_COM_FUNCIONALIDADES_DEFAULT_IN_SETUP.getSql(), params);
			}		
						
		} catch (DaoException e) {			
			e.printStackTrace();
		}		
		return it;
	}
	
	
	int crieOuAltereEmpresaDefault(int it) {				
		atualizeProgressbar(it++, "Criando entradas em EMPRESA...");
		
		try {
			Object idEmpresa = appFacade.recuperarNQ(
					SetupSqlRepository.GET_ID_EMPRESA_DEFAULT_IN_SETUP.getSql());
			
			if(idEmpresa == null) {
				appFacade.executarNQ(SetupSqlRepository.CRIAR_EMPRESA_DEFAULT_IN_SETUP.getSql());
				
				@SuppressWarnings("unused") Object seqFunc = appFacade.recuperarNQ(
						SetupSqlRepository.INCREMENTAR_SEQUENCE_EMPRESA_DEFAULT_IN_SETUP.getSql());
			}else {
				appFacade.executarNQ(SetupSqlRepository.ALTERAR_EMPRESA_DEFAULT_IN_SETUP.getSql());				
			}
			
		} catch (DaoException e) {			
			e.printStackTrace();
		}
		return it;
	}
	
	int crieOuAlterePessoasDefault(int it) {				
		try{			
			/* Cria as 5 pessoas default, caso elas nao existam (buscar pelo ID)
			 * Inicialmente, guarda todos os ids em uma lista para comparacoes */
			List<Object> idPessoas = appFacade.listarNQ(
					SetupSqlRepository.GET_IDS_PESSOAS_DEFAULT_IN_SETUP.getSql());
			
			List<Object> params = new ArrayList<Object>();
			
			for(int a=1; a<=5; a++){									
				switch(a) {					
					case 1: params = getParametros(params, "Pessoa", "Pessoa Desenvolvedor", a); break;
					case 2: params = getParametros(params, "Pessoa", "Pessoa Administrador", a); break;
					case 3: params = getParametros(params, "Pessoa", "Pessoa Op Master", a); break;
					case 4: params = getParametros(params, "Pessoa", "Pessoa Op Senior", a); break;
					case 5:	params = getParametros(params, "Pessoa", "Pessoa Visitante", a); break;
				}								
								
				//Cria ou altera o perfil com id = a
				if(existObject(a, idPessoas)) {
					appFacade.executarNQ(SetupSqlRepository.
							ALTERAR_PESSOAS_DEFAULT_IN_SETUP.getSql(), params);	
					
				}else {
					
					String sql = SetupSqlRepository.
							CRIAR_PESSOAS_DEFAULT_IN_SETUP.getSql();
					
					appFacade.executarNQ(sql, params);
					
					@SuppressWarnings("unused") Object seqFunc = appFacade.recuperarNQ(
							SetupSqlRepository.INCREMENTAR_SEQUENCE_PESSOA_DEFAULT_IN_SETUP.getSql());
				}					
				atualizeProgressbar(it++, "Criando o menu de acesso " + a); 				
			}
			
		} catch (DaoException e) {			
			e.printStackTrace();
		}	
		
		return it;		
	}
	
	int crieOuAltereUsuariosDefault(int it) {							
		try{			
			/* Cria as 5 usuarios default, caso elas nao existam (buscar pelo ID)
			 * Inicialmente, guarda todos os ids em uma lista para comparacoes */
			List<Object> idUsuarios = appFacade.listarNQ(
					SetupSqlRepository.GET_IDS_USUARIOS_DEFAULT_IN_SETUP.getSql());
			
			List<Object> params = new ArrayList<Object>();
			
			for(int a=1; a<=5; a++){									
				switch(a) {					
					case 1: params = getParametros(params, "Usuario", "dev", a); break;
					case 2: params = getParametros(params, "Usuario", "admin", a); break;
					case 3: params = getParametros(params, "Usuario", "master", a);	break;
					case 4: params = getParametros(params, "Usuario", "senior", a);	break;
					case 5: params = getParametros(params, "Usuario", "vis", a); break;
				}								
								
				//Cria ou altera o perfil com id = a
				if(existObject(a, idUsuarios)) {
					appFacade.executarNQ(SetupSqlRepository.
							ALTERAR_USUARIOS_DEFAULT_IN_SETUP.getSql(), params);	
					
				}else {
					appFacade.executarNQ(SetupSqlRepository.
							CRIAR_USUARIOS_DEFAULT_IN_SETUP.getSql(), params);					
				}				
				atualizeProgressbar(it++, "Criando usuario " + a);				
			}
			
		} catch (DaoException e) {			
			e.printStackTrace();
		}		
		return it;		
	}
	
	int associeUsuariosComPerfis(int it){				
		atualizeProgressbar(it++, "Associando usuarios e perfis...");		
		
		/* dev: TODOS (nao precisa associar, pois jah possui por default em MenuBean)
		 * adm: 2,3,4,5
		 * master: 3,4,5
		 * senior: 4,5
		 * vis: 5*/
		try {
			
			List<Object> params = new ArrayList<Object>();
			Long i = 2L;
			Long z = 3L;
			Long y = 4L;
			for(Long a=1L; a<=15; a++){
				params.clear();
				if(a <= 5) {params.add(1); params.add(a);}
				if(a >= 6 && a <= 9) {params.add(2); params.add(i++);}
				if(a >= 10 && a <= 12) {params.add(3); params.add(z++);}
				if(a >= 13 && a <= 14) {params.add(4); params.add(y++);}
				if(a == 15) {params.add(5); params.add(5);}	
			
				
				
				appFacade.executarNQ(SetupSqlRepository.
						DELETAR_PERFIS_USUARIOS_DEFAULT_IN_SETUP.getSql(), params);
				
				appFacade.executarNQ(SetupSqlRepository.
						ASSOCIAR_USUARIOS_COM_PERFIS_DEFAULT_IN_SETUP.getSql(), params);
			}			
			
		} catch (DaoException e) {			
			e.printStackTrace();
		}
		return it;
	}
		
	List<Object> getParametros(List<Object> params, String entidade, String nome, int id){
		params.clear(); //objeto jah vem inicializado
		params.add(Long.parseLong(String.valueOf(id))); //....[0] ID
		
		if(entidade.equals("Pessoa")) {
			params.add("99.999.999.99");//....................[1] CPF
			params.add(DateUtil.getDate("01/01/2001"));//.....[2] DATA_NASCIMENTO
			params.add("9999-SSP");//.........................[3] IDT
			params.add(nome);//...............................[4] NOME
			params.add("70730510"); //......................[5] CEP
			params.add(1L);//.................................[6] ID_EMPRESA
			
		}else {
			//Se entidade = Usuario...			
			params.add("F"); //...............................[1] BLOQUEADO
			params.add(new Date()); //........................[2] DATA_PRIMEIRO_ACESSO
			params.add(nome);//...............................[3] NOME_USUARIO
			params.add("T");//................................[4] PRIMEIRO_ACESSO
			params.add(Crypt.getHash("123456")); //...........[5] SENHA
		}
		return params;
	}
	
	boolean existObject(int idObject, List<Object> objects) {		
		for(Object obj: objects) {
			int id = Integer.valueOf(obj.toString());
			if( idObject == id)  return true;
		}
		return false;
	}
	
	void atualizeProgressbar(int value, String status){		
		progressBean.setStatus(status);
		progressBean.setValue(value);
		
		try {
			Thread.sleep(250); //a cada iteracao, pause 250 milissegundos.
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}			
	
}		
	

					
