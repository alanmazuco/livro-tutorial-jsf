package br.eti.amazu.blankapp.domain.infra;

import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;
import org.hibernate.annotations.Cascade;
import br.eti.amazu.component.pworld.domain.AbstractEntity;

@Entity (name="Perfil")
@Table(schema = "PWORLD", name = "PERFIL",  
	uniqueConstraints={@UniqueConstraint(name="PERFIL_NOME_UK", columnNames={"NOME"}),
								@UniqueConstraint(name="PERFIL_COD_PERFIL_UK", 
									 columnNames={"COD_PERFIL"})}
)

@NamedQueries({	
	@NamedQuery(
		name="Perfil.all",
	    query="select a from Perfil a order by a.codPerfil"
	),
	
	@NamedQuery(
		name="Perfil.defaults",
	    query="select a from Perfil a where a.codPerfil = '1' or a.codPerfil = '2' or "+
	    		"a.codPerfil = '3' or a.codPerfil='4' order by a.codPerfil"
	),
	
	@NamedQuery(
		name="Perfil.peloNome",
	    query="select a from Perfil a where a.nome=:param0"
	),
	
	@NamedQuery(
		name="Perfil.peloCod",
	    query="select a from Perfil a where a.codPerfil=:param0"
	)	
})
public class Perfil extends AbstractEntity<Long> {

	/* Cada usuario pode possuir varios perfis.
	 * 
	 * 1 - DESENVOLVEDOR
	 *    	 Carrega todas as funcionalidades do sistema.
	 * 
	 * 2 - ADMINISTRADOR:
	 *    	 Carrega todas as funcionalidades, menos:
	 *     ------> ferramentas do desenvolvedor.
	 *     
	 * 3 - OPERADOR MASTER
	 *    	 Carrega todas as funcionalidades, menos:
	 *     ------> ferramentas do desenvolvedor;
	 *     ------> configuracoes do sistema e
	 *     ------> criacao de perfis.
	 *     
	 * 4 - OPERADOR SENIOR
	 *    	Carrega todas as funcionalidades, menos:
	 *     ------> ferramentas do desenvolvedor;
	 *     ------> configuracoes do sistema;
	 *     ------> criacao de perfis;
	 *     ------> cadastro de pessoal e 
	 *     ------> cadastro de usuarios.
	 *    
	 * 5 - VISITANTE
	 *    	------> Nao carrega as funcionalidades administrativas     
	 * Alem desses perfis, podem ser criados outros.
	 * o administrador pode atribuir aos novos perfis as funcionalidades que desejar, 
	 * com algumas limitacoes: 
	 * -- Ele nao enxerga a pessoa que eh o desenvolvedor na lista de pessoas;
	 * -- Ele nao enxerga o usuario desenvolvedor na lista de usuarios;
	 * -- Ele nao enxerga um perfil chamado DESENVOLVEDOR na lista de perfis;
	 * -- Ele nao enxerga as ferramentas administrativas (que sao as funcionalidades 
	 *    exclusivas do desenvolvedor).
	 *    
	 * Outras limitacoes podem existir, a criterio do desenvolvedor. Por exemplo:
	 * ------> Nao eh possivel visualizar o usuario DESENVOLVEDOR no modulo Manter Perfis de
	 *          usuarios (apenas o proprio usuario DEV pode visualizar).
	 * ------> Usuarios do tipo ADMINISTRADOR possuem acesso total, mas nao das ferramentas
	 *          do desenvolvedor (nem conseguirao visualiza-las). */	
	
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(schema="PWORLD", allocationSize=1, initialValue = 1, name = "PERFIL_SEQ", 
		sequenceName = "PERFIL_SEQ")	
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "PERFIL_SEQ")
	@Column(name = "ID_PERFIL")
	private Long id;
		
	@Column (name = "NOME", columnDefinition="CHARACTER VARYING(25)")
	private String nome;
	
	@Column (name = "CARACTERISTICAS", columnDefinition="CHARACTER VARYING(250)")
	private String caracteristicas;
	
	@Column (name = "COD_PERFIL", columnDefinition="INTEGER") 
	private Integer codPerfil; 	
	
	/* Associacao *:* com funcionalidade: 
	 * ---------------------------------------------------
	 * 	LEITURA BIDIRECIONAL: 
	 *		   			|-------(LAZY)------->	| 
	 * 		perfil 		|                      	|  usuario
	 *  				|<-------(LAZY)-------	|  
	 *----------------------------------------------------
	 *		ESCRITA BIDIRECIONAL:
	 *		perfil |<--------(write)------->|  usuario
	 *-------------------------------------------------- */
	@ManyToMany(fetch=FetchType.LAZY)	
	@Cascade(org.hibernate.annotations.CascadeType.ALL)		
	@JoinTable(
		name = "USUARIO_PERFIL", schema="PWORLD",
		joinColumns = @JoinColumn(name = "ID_PERFIL", 
		foreignKey = @ForeignKey(name = "perf_usu_fk")),		
		inverseJoinColumns = @JoinColumn(name = "ID_USUARIO"),		
		uniqueConstraints = {
			@UniqueConstraint(
				name="UK_perfil_usuario",
				columnNames={"id_usuario","id_perfil"}
			)
		}			
	)
	private Set<Usuario> usuarios;
	
	/* Associacao *:* com funcionalidade: 
	 * ------------------------------------------------------
	 * 	LEITURA BIDIRECIONAL: 
	 *		   		|-------(EAGER)------->	| 
	 * 	perfil 		|                      	|  funcionalidade
	 *  			|<-------(LAZY)-------	|  
	 *-------------------------------------------------------
	 *		ESCRITA BIDIRECIONAL:
	 *		perfil |<--------(write)------->|  funcionalidade
	 *---------------------------------------------------- */
	@ManyToMany(fetch=FetchType.EAGER)	
	@Cascade(org.hibernate.annotations.CascadeType.ALL)		
	@JoinTable(
		name = "PERFIL_FUNCIONALIDADE", schema="PWORLD",
		joinColumns = @JoinColumn(name = "ID_PERFIL", 
		foreignKey = @ForeignKey(name = "perf_func_fk")), 	
		inverseJoinColumns = @JoinColumn(name = "ID_FUNCIONALIDADE"),		
		uniqueConstraints = {
			@UniqueConstraint(
				name="UK_perfil_funcionalidade",
				columnNames={"id_perfil","id_funcionalidade"}
			)
		}			
	)
	private Set<Funcionalidade> funcionalidades;
		
	@Version
	@Column (name="VERSAO",columnDefinition="INTEGER DEFAULT 0")
	private Integer version;

	/*--------
	 * get/set
	 ---------*/
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCaracteristicas() {
		return caracteristicas;
	}
	public void setCaracteristicas(String caracteristicas) {
		this.caracteristicas = caracteristicas;
	}
	public Integer getCodPerfil() {
		return codPerfil;
	}
	public void setCodPerfil(Integer codPerfil) {
		this.codPerfil = codPerfil;
	}
	public Set<Usuario> getUsuarios() {
		return usuarios;
	}
	public void setUsuarios(Set<Usuario> usuarios) {
		this.usuarios = usuarios;
	}
	public Set<Funcionalidade> getFuncionalidades() {
		return funcionalidades;
	}
	public void setFuncionalidades(Set<Funcionalidade> funcionalidades) {
		this.funcionalidades = funcionalidades;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	
}

