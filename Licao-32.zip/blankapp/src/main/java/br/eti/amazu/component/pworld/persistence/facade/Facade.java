package br.eti.amazu.component.pworld.persistence.facade;

import java.util.List;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import javax.persistence.LockModeType;
import br.eti.amazu.component.pworld.persistence.dao.IDao;
import br.eti.amazu.component.pworld.persistence.exception.DaoException;

public abstract class Facade<T> implements IFacade<T>{
	
	@Inject
	private IDao<T> dao;
	
		
	
	/**********
	 * NO QUERY
	 *********/
	
	/*----------------------------
	 * Inserir - Alterar - Excluir
	 * --------------------------*/
	@Override
	@TransactionAttribute ( TransactionAttributeType.REQUIRED )
	public void incluir(T obj) throws DaoException{
		dao.insert(obj);
		dao.flush();
	}		
	
	@Override
	@TransactionAttribute ( TransactionAttributeType.REQUIRED )
	public void excluir(T obj) throws DaoException{
		dao.delete(obj);	
		dao.flush();
	}
	
	@Override
	@TransactionAttribute ( TransactionAttributeType.REQUIRED )
	public void alterar(T obj) throws DaoException{
		dao.update(obj);
		dao.flush();
	}
		
	@Override
	@SuppressWarnings("unchecked")
	@TransactionAttribute ( TransactionAttributeType.REQUIRED )
	public Object alterarAtualizar(T obj) throws DaoException{
		dao.update(obj); //Realiza a persistencia.
		dao.flush(); //Sincroniza o banco de dados com os objetos gerenciados em entityManager.
		
		try {
			
			/* O metodo abaixo sincroniza o objeto que veio da view com o que estah gerenciado.
			 * O resultado eh que o metodo devolve o objeto sincronizado com banco de dados e entityManager,
			 * e tambem sincronizado com o objeto da view, bastando apenas, na view, igualar o objeto. */
			if(obj.getClass().getMethod("getId").invoke(obj)!=null){
				Class<?> partTypesGet[] = new Class[2]; 
				partTypesGet[0] = Class.class;  
				partTypesGet[1] = Object.class;             
				Object argListGet[] = new Object[2];
				argListGet[0] = obj.getClass();
				argListGet[1] = obj.getClass().getMethod("getId").invoke(obj);
								
				Object object = dao.get((Class<T>) obj.getClass(),
							obj.getClass().getMethod("getId").invoke(obj));	
				
				dao.refresh(object); //Atualiza o objeto.
				return object; //Retorna o objeto sincronizado e atualizado.				
			
			}else{
				return obj;
			}			
		
		} catch (Exception e) {			
			new DaoException(e.getMessage());
		} 
		
		return null;	
	}
	//-----------------------------------------------------------
	
	
	/*-----------------------------------------------------------
	 * Consulta de um unico resultado passando uma chave primaria
	 * pk somente do tipo Long, Integer e String
	 * ---------------------------------------------------------*/
	@Override
	public T recuperar(Class<T> t, Long pk) throws DaoException{
		return dao.find(t, pk);
	}
	
	@Override
	public T recuperar(Class<T> t, Integer pk) throws DaoException{
		return dao.find(t, pk);
	}
	
	@Override
	public T recuperar(Class<T> t, String pk) throws DaoException {
		return dao.find(t, pk);
	}
   //--------------------------------------------------------------	
	
	
	
	
	/*************
	 * NAMEDQUERY
	 *************/
	
	/*--------------------------------------
	 * Retorna uma lista de objetos.
	 * Lista tudo sem precisar de parametros.
	 * - Utilizando hql e namedQuery.
	 --------------------------------------*/
	@Override
	public List<T> listar(String namedQuery) throws DaoException{
		return dao.list(namedQuery);
	}
	
	/*-------------------------------------------------------
	 * Retorna uma lista de objetos.
	 * Lista tudo (ou uma lista limitada)  usando parametros.
	 * - Utilizando hql e namedQuery.
	 ------------------------------------------------------*/
	@Override
	public List<T> listar(String namedQuery, List<Object> params) throws DaoException{
		return dao.list(namedQuery, params);
	}
		
	/*--------------------------------------------
	 * Consulta paginada com namedQuery- resultset	
	 * ------------------------------------------*/
	@Override	
	public List<T> listartPaginado(String namedQuery, List<Object> params, int first, int pageSize)
				throws DaoException{
		return dao.listPagination(namedQuery, params, first, pageSize);
	}
	
	/*------------------------------------------------------------------
	 * Retorna um unico objeto
	 * - Utilizando hql e namedQuery.
	 * - O parametro da busca deverah ser feito por uma chave unica, 
	 *   ou na certeza de haver no banco um unico valor para o campo, se
	 *   isto nao for observado serah causado uma exception.
	 * - Utilizando hql e namedQuery.
	 ------------------------------------------------------------------*/
	@Override
	public T recuperar(String namedQuery, List<Object> params) throws DaoException{
		return dao.singleResult(namedQuery, params);
	}
	
	/*---------------------------------------------------------------------------
	 * Traz o maximo de registros baseado em uma consulta.
	 * Pode ser usado em uma consulta paginada com namedQuery- total da paginacao	
	 * -------------------------------------------------------------------------*/
	@Override
	public int recuperarMaxResult(String namedQuery, List<Object> params) throws DaoException{
		return dao.maxResult(namedQuery, params);
	}
	
	/*------------------------------
	 * Execute com hql e namedQuery.
	 -----------------------------*/
	@Override
	@TransactionAttribute ( TransactionAttributeType.REQUIRED )
	public boolean executar(String namedQuery, List<Object> params) throws DaoException{
		boolean b = dao.execute(namedQuery, params);
		dao.flush();
		return b;
	}
	
	/*----------------------------------------------------------------
	 * Retorna um objeto unico de uma expressao HQL
	 * - quando queremos o ultimo registro baseado na expressao.
	 * - exemplo de uma namedQuery:
	 *   "from Pessoa p where p.bairro =:param0 order by p.nome DESC".
	 *   isto irah retornar a ultima pessoa de uma lista ordeada pelo
	 *   nome, que mora em um bairro passado no parametro.
	 ----------------------------------------------------------------*/	
	
	@Override
	public T recuperarMinMax(String namedQuery, List<Object> params) throws DaoException{
		return dao.minMaxFromExpression(namedQuery, params);
	}
			
	
	

	/*************
	 * NATIVEQUERY
	 *************/
		
	/*-------------------------------------------------------------------
	 * Retorna uma lista de objetos. Utilizando sql nativa (nativeQuery).
	 * Lista tudo sem usar parametros - passando o Tipo
	 -------------------------------------------------------------------*/
	@Override
	public List<T> listarNQ(T t, String nativeQuery) throws DaoException{
		return dao.listNQ(t, nativeQuery);
	}
	
	/*-------------------------------------------------------------------
	 * Retorna uma lista de objetos.  Utilizando sql nativa (nativeQuery).
	 * Usando parametros - passando o Tipo
	 -------------------------------------------------------------------*/
	@Override
	public List<T> listarNQ(T t, String nativeQuery, List<Object> params) throws DaoException{
		return dao.listNQ(t, nativeQuery, params);
	}
	
	/*--------------------------------------------------------------
	 * Retorna uma lista de objetos. Lista tudo sem usar parametros.
	 * Utilizando sql nativa (nativeQuery)
	 --------------------------------------------------------------*/
	@Override
	public List<T> listarNQ(String nativeQuery) throws DaoException{
		return dao.listNQ(nativeQuery);
	}
	
	/*---------------------------------------------------------------
	 * Retorna uma lista de objetos da classe passada como parametro.
	 * Utilizando sql nativa (nativeQuery).
	 ---------------------------------------------------------------*/
	@Override
	public List<T> listarNQ(String nativeQuery, List<Object> params) throws DaoException{
		return dao.listNQ(nativeQuery, params);
	}
	
	/* --------------------------------------------- 
	 * Consulta paginada com nativeQuery - resultset 
	 * -------------------------------------------*/
	@Override	
	public List<T> listarPaginadorNQ(T t, String nativeQuery, List<Object> params, int first, int pageSize) 
				throws DaoException{
		return dao.listPaginationNQ(t, nativeQuery, params, first, pageSize);
	}
	
	/* -----------------------------------------------------
	 * Retorna uma lista de objetos. Utilizando nativeQuery.	
	 * ---------------------------------------------------*/
	public List<Object[]> listarObjetosNQ(String nativeQuery, List<Object> params) 	throws DaoException{
		return dao.listObjectNQ(nativeQuery, params);
	}
	
	/*---------------------------------------------------------------------------------------
	 * Consulta de unico resultado - retorna um objeto.  Utilizando sql nativa (nativeQuery).
	 * Passando o Tipo como parametro.
	 --------------------------------------------------------------------------------------*/
	@Override	
	public T recuperarNQ(T t, String nativeQuery, List<Object> params) throws DaoException{
		return dao.singleResultNQ(t, nativeQuery, params);
	}
	
	/*-------------------------------------------------------------------------------------
	 * Consulta de unico resultado - retorna um objeto.	Utilizando sql nativa (nativeQuery).
	 * Sem utilizacao de parametros.
	 -------------------------------------------------------------------------------------*/
	@Override
	public T recuperarNQ(String nativeQuery) throws DaoException{
		return dao.singleResultNQ(nativeQuery);
	}
	
	/*--------------------------------------------------------------------------------------
	 * Consulta de unico resultado - retorna um objeto.	Utilizando sql nativa (nativeQuery).
	 * Utilizando parametros para a consulta.
	 -------------------------------------------------------------------------------------*/
	@Override
	public T recuperarNQ(String nativeQuery, List<Object> params) throws DaoException{
		return dao.singleResultNQ(nativeQuery, params);
	}
	
	/*-----------------------------------------------------
	 * Simples execute. Utilizando sql nativa (nativeQuery).	
	 -----------------------------------------------------*/
	@Override
	@TransactionAttribute ( TransactionAttributeType.REQUIRED )
	public boolean executarNQ(String nativeQuery) throws DaoException{
		boolean b = dao.executeNQ(nativeQuery);
		dao.flush();
		return b;
	}
	
	/*------------------------------------------------------------------
	 * Inserir - Alterar - Excluir. Utilizando sql nativa (nativeQuery).	
	 ------------------------------------------------------------------*/
	@Override
	@TransactionAttribute ( TransactionAttributeType.REQUIRED )
	public boolean executarNQ(String nativeQuery, List<Object> params) throws DaoException{
		boolean b = dao.executeNQ(nativeQuery, params);
		dao.flush();
		return b;
	}
		
	/*-----------------------------------------------------
	 * Maximo de uma expressao: nativeQuery sem parametros. 
	 ----------------------------------------------------*/
	@Override
	public int recuperarMaxResultNQ(String nativeQuery) throws DaoException{
		return dao.maxResultNQ(nativeQuery);
	}

	/*-----------------------------------------------------
	 * Maximo de uma expressao: nativeQuery com parametros. 
	 ----------------------------------------------------*/
	@Override
	public int recuperarMaxResultNQ(String nativeQuery, List<Object> params) throws DaoException{
		return dao.maxResultNQ(nativeQuery, params);
	}
	
	/*-----------------------------------
	 * Obtem a ultima sequence da tabela. 
	 ----------------------------------*/
	@Override	
	public Long recuperarSequenceNQ(String sequenceName) throws DaoException{
		return dao.getSequenceNQ(sequenceName);
	}
			
	
	
	/**************************************************************
	 * MANIPULA��O DO ENTITY MANAGER - Apenas objetos persistentes.
	 *************************************************************/	
	
	/*----------------------------------------------------------------
	 * Apagar todos os objetos que estao gerenciados no EntityManager.
	 * -------------------------------------------------------------*/
	@Override
	public void clear(){
		dao.clear();		
	}
	
	/*--------------------------
	 * Atualizar o EntityManager
	 * -----------------------*/
	@Override
	public void refresh(Object obj){
		dao.refresh(obj);
	}
	
	/*-----------------------------------------------------------
	 * Atualizar o EntityManager com lockModeType como parametro.
	 * --------------------------------------------------------*/
	@Override
	public void refresh(Object obj, LockModeType lockModeType){
		dao.refresh(obj, lockModeType);
	}
	
	/*-----------------------------------------------------
	 * Verificar se um determinado objeto estah gerenciado.
	 * --------------------------------------------------*/
	@Override
	public boolean isManaged(Object obj){
		return dao.isManaged(obj);
	}
	
	/*-------------------------------------------
	 * Bloquear/desbloquear um objeto para edicao
	 * ----------------------------------------*/
	@Override
	public void lock(Object obj, LockModeType loModeType){
		dao.lock(obj, loModeType);
	}
	
	/*------------------------------------------------------
	 * Sincroniza objetos persistentes com o banco de dados.
	 * ---------------------------------------------------*/
	@Override
	public void flush(){
		dao.flush();		
	}
	
	/*--------------------------------------
	 * Desassocia o objeto do entityManager.
	 * -----------------------------------*/
	@Override
	public void detach(Object obj){
		dao.detach(obj);
	}
	
	/*------------------------
	 * Obtem um objeto managed.
	 * ----------------------*/
	@Override
	public Object get(Class<T> t, Object obj) {
		return dao.get(t, obj);
	}
	
	/*-----------------------------
	 * Obtem uma referencia do Dao.
	 * --------------------------*/
	@Override
	public IDao<T> getDao() {
		return dao;
	}

	/*--------------
	 * Define o Dao.
	 * -----------*/
	@Override
	public void setDao(IDao<T> dao) {
		this.dao = dao;
	}
	
}

